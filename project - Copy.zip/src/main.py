import os

def create_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content.strip())
    print(f"[+] Generated: {path}")

def build_extension():
    print(">>> BUILDING SPARK EXTENSION MIDDLEMAN...\n")
    base_dir = "spark_middleman_ext"

    # ==========================================
    # 1. MANIFEST (MV3)
    # ==========================================
    create_file(f"{base_dir}/manifest.json", """
{
  "manifest_version": 3,
  "name": "Spark Vault Middleman",
  "version": "1.0",
  "description": "Uses Spark 2 UID to seamlessly decrypt and autofill credentials.",
  "permissions": ["activeTab", "scripting", "storage"],
  "host_permissions": ["<all_urls>"],
  "background": {
    "service_worker": "background.js"
  },
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"],
      "run_at": "document_idle"
    }
  ],
  "action": {
    "default_popup": "popup.html"
  }
}
    """)

    # ==========================================
    # 2. BACKGROUND WORKER (The Crypto Brain)
    # ==========================================
    create_file(f"{base_dir}/background.js", """
const SALT = "SPARK_MIDDLEMAN_STATIC_SALT_V1";

function buf2b64(buf) { return btoa(String.fromCharCode(...new Uint8Array(buf))); }
function b642buf(b64) { return new Uint8Array(atob(b64).split('').map(c => c.charCodeAt(0))); }

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "unlock_and_fill") {
        unlockVault(request.uid).then(success => {
            sendResponse({status: success ? "success" : "failed"});
        });
        return true; 
    }
    if (request.action === "save_vault") {
        saveVault(request.uid, request.data).then(() => {
            sendResponse({status: "saved"});
        });
        return true;
    }
});

async function getVaultKey(uid) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(uid), "PBKDF2", false, ["deriveKey"]);
    return await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt: enc.encode(SALT), iterations: 200000, hash: "SHA-256" },
        keyMaterial, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]
    );
}

async function unlockVault(uid) {
    try {
        const result = await chrome.storage.local.get(['spark_vault']);
        if (!result.spark_vault) return false; 

        const key = await getVaultKey(uid);
        const vault = result.spark_vault;
        
        const decryptedBuf = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: b642buf(vault.iv) },
            key, b642buf(vault.ciphertext)
        );
        
        const credentialsText = new TextDecoder().decode(decryptedBuf);
        
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
            chrome.tabs.sendMessage(tab.id, { action: "autofill", data: credentialsText });
        }
        return true;
    } catch (e) {
        console.error("Decryption failed. Wrong UID?", e);
        return false;
    }
}

async function saveVault(uid, rawData) {
    const key = await getVaultKey(uid);
    const enc = new TextEncoder();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    const encryptedBuf = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv }, key, enc.encode(rawData)
    );
    
    await chrome.storage.local.set({
        spark_vault: { iv: buf2b64(iv), ciphertext: buf2b64(encryptedBuf) }
    });
}
    """)

    # ==========================================
    # 3. CONTENT SCRIPT (The Injector)
    # ==========================================
    create_file(f"{base_dir}/content.js", """
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "autofill") {
        console.log("Spark Middleman: Injecting credentials...");
        
        const decryptedString = request.data;
        let passField = document.querySelector('input[type="password"]');
        
        if (passField) {
            passField.value = decryptedString; 
            passField.dispatchEvent(new Event('input', { bubbles: true })); 
            passField.style.border = "2px solid #ff0055";
            passField.style.boxShadow = "0 0 10px #ff0055";
            sendResponse({status: "success"});
        } else {
            console.log("Spark Middleman: No password fields found.");
            sendResponse({status: "failed"});
        }
    }
});
    """)

    # ==========================================
    # 4. POPUP UI (The Dashboard)
    # ==========================================
    create_file(f"{base_dir}/popup.html", """
<!DOCTYPE html>
<html>
<head>
    <style>
        body { width: 300px; background: #050005; color: #ff0055; font-family: 'Courier New', monospace; padding: 15px; margin: 0; }
        h3 { text-align: center; border-bottom: 1px solid #ff0055; padding-bottom: 10px; margin-top: 0; text-transform: uppercase; }
        
        #uid-input { width: 100%; box-sizing: border-box; background: rgba(255,0,85,0.05); border: 2px dashed #ff0055; color: #fff; padding: 12px; margin-bottom: 15px; text-align: center; font-weight: bold; outline: none; }
        #uid-input:focus { border-style: solid; box-shadow: 0 0 10px #550022; }
        
        textarea { width: 100%; box-sizing: border-box; background: #000; border: 1px solid #ff0055; color: #fff; padding: 10px; margin-bottom: 10px; height: 60px; resize: none; outline: none;}
        
        button { width: 100%; background: #ff0055; color: #000; border: none; padding: 12px; font-weight: bold; cursor: pointer; text-transform: uppercase; margin-bottom: 10px; }
        button:hover { background: #fff; }
        
        #status { font-size: 11px; text-align: center; color: #fff; min-height: 15px; }
        .hidden { display: none; }
        .manager-link { text-align: center; font-size: 10px; margin-top: 10px; cursor: pointer; text-decoration: underline; }
    </style>
</head>
<body>
    <h3>SPARK_2 UPLINK</h3>
    
    <p style="font-size: 10px; text-align: center; margin-top: 0; color: #aaa;">Click box below & tap KBR1 Reader</p>
    <input type="password" id="uid-input" placeholder="[ AWAITING UID INPUT ]" autofocus>
    
    <div id="status">Awaiting hardware...</div>

    <div id="setup-area" class="hidden" style="margin-top: 15px; border-top: 1px dashed #ff0055; padding-top: 15px;">
        <p style="font-size: 10px; margin: 0 0 5px 0;">SAVE NEW PASSWORD TO VAULT:</p>
        <textarea id="new-data" placeholder="Type password to save..."></textarea>
        <button id="saveBtn" style="background: transparent; border: 1px solid #ff0055; color: #ff0055;">ENCRYPT & SAVE</button>
    </div>
    
    <div class="manager-link" id="toggle-setup">Toggle Vault Manager</div>

    <script>
        const statusDiv = document.getElementById('status');
        const uidInput = document.getElementById('uid-input');

        uidInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const uid = this.value;
                if(!uid) return;
                
                statusDiv.innerText = "DECRYPTING & INJECTING...";
                
                chrome.runtime.sendMessage({ action: "unlock_and_fill", uid: uid }, (response) => {
                    if (response && response.status === "success") {
                        statusDiv.style.color = "#0f0";
                        statusDiv.innerText = "VAULT UNLOCKED. DATA INJECTED.";
                        setTimeout(() => window.close(), 1500); 
                    } else {
                        statusDiv.style.color = "red";
                        statusDiv.innerText = "ERR: Wrong UID or Empty Vault.";
                    }
                    uidInput.value = ""; 
                });
            }
        });

        document.getElementById('toggle-setup').addEventListener('click', () => {
            document.getElementById('setup-area').classList.toggle('hidden');
        });

        document.getElementById('saveBtn').addEventListener('click', () => {
            const uid = uidInput.value;
            const data = document.getElementById('new-data').value;
            
            if(!uid || !data) {
                statusDiv.style.color = "yellow";
                statusDiv.innerText = "ERR: Need UID and Data to save.";
                return;
            }
            
            statusDiv.innerText = "ENCRYPTING VAULT...";
            chrome.runtime.sendMessage({ action: "save_vault", uid: uid, data: data }, (response) => {
                if (response && response.status === "saved") {
                    statusDiv.style.color = "#0f0";
                    statusDiv.innerText = "SAVED TO LOCAL STORAGE.";
                    document.getElementById('new-data').value = "";
                }
            });
        });
    </script>
</body>
</html>
    """)

    print("\n>>> MIDDLEMAN GENERATED: FOLDER 'spark_middleman_ext' CREATED.")

if __name__ == "__main__":
    build_extension()