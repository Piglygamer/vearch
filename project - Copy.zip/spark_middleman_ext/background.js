const SALT = "SPARK_MIDDLEMAN_STATIC_SALT_V1";

function buf2b64(buf) { return btoa(String.fromCharCode(...new Uint8Array(buf))); }
function b642buf(b64) { return new Uint8Array(atob(b64).split('').map(c => c.charCodeAt(0))); }

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "unlock_and_fill") {
        unlockVault(request.uid).then(success => {
            sendResponse({status: success ? "success" : "failed"});
        });
        return true; 
    }
    if (request.action === "save_vault") {
        saveVault(request.uid, request.data).then(() => {
            sendResponse({status: "saved"});
        });
        return true;
    }
});

async function getVaultKey(uid) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(uid), "PBKDF2", false, ["deriveKey"]);
    return await crypto.subtle.deriveKey(
        { name: "PBKDF2", salt: enc.encode(SALT), iterations: 200000, hash: "SHA-256" },
        keyMaterial, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]
    );
}

async function unlockVault(uid) {
    try {
        const result = await chrome.storage.local.get(['spark_vault']);
        if (!result.spark_vault) return false; 

        const key = await getVaultKey(uid);
        const vault = result.spark_vault;
        
        const decryptedBuf = await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: b642buf(vault.iv) },
            key, b642buf(vault.ciphertext)
        );
        
        const credentialsText = new TextDecoder().decode(decryptedBuf);
        
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
            chrome.tabs.sendMessage(tab.id, { action: "autofill", data: credentialsText });
        }
        return true;
    } catch (e) {
        console.error("Decryption failed. Wrong UID?", e);
        return false;
    }
}

async function saveVault(uid, rawData) {
    const key = await getVaultKey(uid);
    const enc = new TextEncoder();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    const encryptedBuf = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv: iv }, key, enc.encode(rawData)
    );
    
    await chrome.storage.local.set({
        spark_vault: { iv: buf2b64(iv), ciphertext: buf2b64(encryptedBuf) }
    });
}