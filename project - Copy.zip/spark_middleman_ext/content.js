chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "autofill") {
        console.log("Spark Middleman: Injecting credentials...");
        
        const decryptedString = request.data;
        let passField = document.querySelector('input[type="password"]');
        
        if (passField) {
            passField.value = decryptedString; 
            passField.dispatchEvent(new Event('input', { bubbles: true })); 
            passField.style.border = "2px solid #ff0055";
            passField.style.boxShadow = "0 0 10px #ff0055";
            sendResponse({status: "success"});
        } else {
            console.log("Spark Middleman: No password fields found.");
            sendResponse({status: "failed"});
        }
    }
});