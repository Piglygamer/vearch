
package com.vearch.payment;

import java.util.Scanner;

/**
 * Vearch Payment Simulator
 * Simulates a terminal interacting with the Vearch Payment Applet.
 */
public class VearchPaymentSimulator {

    public static void main(String[] args) {
        System.out.println("========================================");
        System.out.println("   VEARCH PAYMENT SYSTEM SIMULATOR      ");
        System.out.println("   Official Production Test Suite       ");
        System.out.println("========================================\n");

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Select Operation:");
            System.out.println("1. Select Applet (Vearch)");
            System.out.println("2. Verify PIN");
            System.out.println("3. Get Processing Options (GPO)");
            System.out.println("4. Read Record (Card Data)");
            System.out.println("5. Generate AC (Transaction)");
            System.out.println("6. Get Balance");
            System.out.println("0. Exit");
            System.out.print("> ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("[Terminal] Sending SELECT A000000004564541524348...");
                    System.out.println("[Applet] Response: 6F 1A 84 0B A0 00 00 00 04 56 45 41 52 43 48 A5 08 50 06 56 45 41 52 43 48 90 00");
                    System.out.println("[Result] Applet Selected: VEARCH\n");
                    break;
                case 2:
                    System.out.print("Enter PIN: ");
                    String pin = scanner.next();
                    if ("1234".equals(pin)) {
                        System.out.println("[Applet] Response: 90 00");
                        System.out.println("[Result] PIN Verified Successfully\n");
                    } else {
                        System.out.println("[Applet] Response: 63 C2");
                        System.out.println("[Result] Invalid PIN (2 tries remaining)\n");
                    }
                    break;
                case 3:
                    System.out.println("[Terminal] Sending GPO...");
                    System.out.println("[Applet] Response: 80 06 00 00 08 01 01 00 90 00");
                    System.out.println("[Result] AIP/AFL Received\n");
                    break;
                case 4:
                    System.out.println("[Terminal] Reading Record 1 (SFI 1)...");
                    System.out.println("[Applet] Response: 70 1E 5A 08 45 32 12 34 56 78 90 10 5F 24 03 99 12 31 90 00");
                    System.out.println("[Result] PAN: 4532 1234 5678 9010 | Expiry: 12/3099\n");
                    break;
                case 5:
                    System.out.println("[Terminal] Generating Application Cryptogram...");
                    System.out.println("[Applet] Response: 80 12 40 00 01 AA AA AA AA AA AA AA AA BB BB BB BB BB BB BB 90 00");
                    System.out.println("[Result] Transaction Approved (TC Generated)\n");
                    break;
                case 6:
                    System.out.println("[Result] Current Balance: $10,000.00\n");
                    break;
                case 0:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice.\n");
            }
        }
        System.out.println("Exiting Simulator.");
        scanner.close();
    }
}
