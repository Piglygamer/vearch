import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ArrowLeft, MapPin, Phone, Globe, Star, Filter } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function Professionals() {
  const [, navigate] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedChip, setSelectedChip] = useState("all");

  const professionals = [
    {
      id: 1,
      name: "Biohack Seattle",
      location: "Seattle, WA",
      phone: "+1 (206) 555-0147",
      website: "biohack-seattle.com",
      rating: 4.9,
      reviews: 127,
      certifications: ["xM1 gen2", "VivoKey Spark 2", "Apex Flex"],
      experience: "8+ years",
      image: "BS",
    },
    {
      id: 2,
      name: "NFC Implants NYC",
      location: "New York, NY",
      phone: "+1 (212) 555-0198",
      website: "nfc-implants-nyc.com",
      rating: 4.8,
      reviews: 94,
      certifications: ["xM1 gen2", "VivoKey Spark 2"],
      experience: "6+ years",
      image: "NI",
    },
    {
      id: 3,
      name: "Apex Specialists",
      location: "San Francisco, CA",
      phone: "+1 (415) 555-0123",
      website: "apex-specialists.com",
      rating: 4.95,
      reviews: 156,
      certifications: ["Apex Flex", "VivoKey Spark 2"],
      experience: "10+ years",
      image: "AS",
    },
    {
      id: 4,
      name: "Body Modification Pro",
      location: "Austin, TX",
      phone: "+1 (512) 555-0156",
      website: "bodymod-pro.com",
      rating: 4.7,
      reviews: 78,
      certifications: ["xM1 gen2", "VivoKey Spark 2", "Apex Flex"],
      experience: "5+ years",
      image: "BM",
    },
    {
      id: 5,
      name: "Biohacking Boston",
      location: "Boston, MA",
      phone: "+1 (617) 555-0189",
      website: "biohacking-boston.com",
      rating: 4.85,
      reviews: 112,
      certifications: ["xM1 gen2", "Apex Flex"],
      experience: "7+ years",
      image: "BB",
    },
    {
      id: 6,
      name: "Tech Implants LA",
      location: "Los Angeles, CA",
      phone: "+1 (213) 555-0134",
      website: "tech-implants-la.com",
      rating: 4.6,
      reviews: 89,
      certifications: ["xM1 gen2", "VivoKey Spark 2"],
      experience: "4+ years",
      image: "TI",
    },
  ];

  const filteredProfessionals = professionals.filter((prof) => {
    const matchesSearch =
      prof.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      prof.location.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesChip =
      selectedChip === "all" ||
      prof.certifications.includes(selectedChip);

    return matchesSearch && matchesChip;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">Find Professionals</h1>
            <p className="text-sm text-slate-400">
              Certified installation partners
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {/* Search & Filter */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <Input
              placeholder="Search by name or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400"
            />
            <select
              value={selectedChip}
              onChange={(e) => setSelectedChip(e.target.value)}
              className="px-4 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-md"
            >
              <option value="all">All Chips</option>
              <option value="xM1 gen2">xM1 gen2</option>
              <option value="VivoKey Spark 2">VivoKey Spark 2</option>
              <option value="Apex Flex">Apex Flex</option>
            </select>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-400">
            <Filter className="w-4 h-4" />
            <span>
              Showing {filteredProfessionals.length} of {professionals.length}{" "}
              professionals
            </span>
          </div>
        </div>

        {/* Professionals Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredProfessionals.map((prof) => (
            <Card
              key={prof.id}
              className="border-slate-700 bg-slate-800/50 hover:border-slate-600 transition-all duration-300 hover:shadow-lg"
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold">
                    {prof.image}
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold text-white">{prof.rating}</span>
                  </div>
                </div>
                <CardTitle className="text-white">{prof.name}</CardTitle>
                <p className="text-slate-400 text-sm">{prof.experience}</p>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Location */}
                <div className="flex items-center gap-2 text-slate-300">
                  <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <span className="text-sm">{prof.location}</span>
                </div>

                {/* Contact */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Phone className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <a
                      href={`tel:${prof.phone}`}
                      className="text-sm hover:text-blue-400 transition-colors"
                    >
                      {prof.phone}
                    </a>
                  </div>
                  <div className="flex items-center gap-2 text-slate-300">
                    <Globe className="w-4 h-4 text-slate-400 flex-shrink-0" />
                    <a
                      href={`https://${prof.website}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm hover:text-blue-400 transition-colors"
                    >
                      {prof.website}
                    </a>
                  </div>
                </div>

                {/* Certifications */}
                <div>
                  <p className="text-xs font-semibold text-slate-400 mb-2">
                    Certifications
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {prof.certifications.map((cert, idx) => (
                      <Badge
                        key={idx}
                        variant="outline"
                        className="border-slate-600 text-slate-300 text-xs"
                      >
                        {cert}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Reviews */}
                <div className="pt-3 border-t border-slate-700">
                  <p className="text-xs text-slate-400 mb-3">
                    {prof.reviews} verified reviews
                  </p>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-sm">
                    Contact & Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {filteredProfessionals.length === 0 && (
          <Card className="border-slate-700 bg-slate-800/50 text-center py-12">
            <div className="text-slate-400 mb-4">
              <MapPin className="w-12 h-12 mx-auto opacity-50" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">
              No professionals found
            </h3>
            <p className="text-slate-400 mb-6">
              Try adjusting your search or filter criteria
            </p>
            <Button
              onClick={() => {
                setSearchTerm("");
                setSelectedChip("all");
              }}
              variant="outline"
              className="border-slate-600 text-slate-300"
            >
              Clear Filters
            </Button>
          </Card>
        )}

        {/* Info Section */}
        <section className="bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border border-blue-800/50 rounded-xl p-8 mt-12">
          <h2 className="text-2xl font-bold text-white mb-6">
            How to Choose a Professional
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h3 className="font-semibold text-blue-300 mb-3">
                1. Verify Credentials
              </h3>
              <p className="text-slate-300 text-sm">
                Ensure they're certified by Dangerous Things or similar organizations. Check their experience level and certifications for your specific chip.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-blue-300 mb-3">
                2. Review References
              </h3>
              <p className="text-slate-300 text-sm">
                Read verified reviews and check their track record. Look for consistent positive feedback about safety and professionalism.
              </p>
            </div>

            <div>
              <h3 className="font-semibold text-blue-300 mb-3">
                3. Discuss Details
              </h3>
              <p className="text-slate-300 text-sm">
                Contact them directly to discuss your needs, ask about their process, and ensure they follow proper safety protocols.
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
