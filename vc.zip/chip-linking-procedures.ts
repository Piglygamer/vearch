import { router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { implants, operationLogs } from "../drizzle/complete-schema";
import { eq, and } from "drizzle-orm";

/**
 * Real Chip Linking Procedures
 * Handles persistent user-implant relationships
 * 
 * Flow:
 * 1. User reads chip UID via NFC
 * 2. User names the implant
 * 3. System links UID to user account
 * 4. User can now manage, upgrade, and use the chip
 */

export const chipLinkingProcedures = router({
  /**
   * Link new implant to user account
   */
  linkImplant: protectedProcedure
    .input(
      z.object({
        uid: z.string(),
        name: z.string(),
        type: z.enum(["spark2", "magic", "apex", "zinc", "next", "titan", "other"]),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        // Check if UID already linked to another user
        const existing = await db
          .select()
          .from(implants)
          .where(eq(implants.uid, input.uid))
          .limit(1);

        if (existing[0] && existing[0].userId !== ctx.user.id) {
          throw new Error("This chip is already linked to another user");
        }

        // Link implant
        const result = await db.insert(implants).values({
          userId: ctx.user.id,
          uid: input.uid,
          type: input.type,
          name: input.name,
          description: input.description,
          status: "active",
        });

        const implantId = result.insertId as number;

        // Log operation
        await db.insert(operationLogs).values({
          userId: ctx.user.id,
          implantId,
          operationType: "link_implant",
          status: "success",
          details: JSON.stringify({
            uid: input.uid,
            type: input.type,
            name: input.name,
          }),
        });

        console.log(`[ChipLinking] Implant linked: user=${ctx.user.id}, uid=${input.uid}`);

        return {
          success: true,
          implantId,
          message: `${input.name} linked successfully`,
        };
      } catch (error) {
        console.error("[ChipLinking] Link failed:", error);
        throw error;
      }
    }),

  /**
   * Get user's linked implants
   */
  getMyImplants: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    try {
      const userImplants = await db
        .select()
        .from(implants)
        .where(eq(implants.userId, ctx.user.id));

      return userImplants.map((implant) => ({
        id: implant.id,
        uid: implant.uid,
        name: implant.name,
        type: implant.type,
        description: implant.description,
        status: implant.status,
        linkedAt: implant.createdAt,
      }));
    } catch (error) {
      console.error("[ChipLinking] Failed to get implants:", error);
      return [];
    }
  }),

  /**
   * Update implant details
   */
  updateImplant: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        status: z.enum(["active", "inactive", "archived"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        // Verify ownership
        const implant = await db
          .select()
          .from(implants)
          .where(
            and(eq(implants.id, input.implantId), eq(implants.userId, ctx.user.id))
          )
          .limit(1);

        if (!implant[0]) {
          throw new Error("Implant not found or not authorized");
        }

        const updateData: any = {};
        if (input.name) updateData.name = input.name;
        if (input.description) updateData.description = input.description;
        if (input.status) updateData.status = input.status;

        await db
          .update(implants)
          .set(updateData)
          .where(eq(implants.id, input.implantId));

        console.log(`[ChipLinking] Implant updated: ${input.implantId}`);

        return {
          success: true,
          message: "Implant updated successfully",
        };
      } catch (error) {
        console.error("[ChipLinking] Update failed:", error);
        throw error;
      }
    }),

  /**
   * Unlink implant from user account
   */
  unlinkImplant: protectedProcedure
    .input(z.object({ implantId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        // Verify ownership
        const implant = await db
          .select()
          .from(implants)
          .where(
            and(eq(implants.id, input.implantId), eq(implants.userId, ctx.user.id))
          )
          .limit(1);

        if (!implant[0]) {
          throw new Error("Implant not found or not authorized");
        }

        // Delete implant
        await db.delete(implants).where(eq(implants.id, input.implantId));

        // Log operation
        await db.insert(operationLogs).values({
          userId: ctx.user.id,
          implantId: input.implantId,
          operationType: "unlink_implant",
          status: "success",
          details: JSON.stringify({ uid: implant[0].uid }),
        });

        console.log(`[ChipLinking] Implant unlinked: ${input.implantId}`);

        return {
          success: true,
          message: "Implant unlinked successfully",
        };
      } catch (error) {
        console.error("[ChipLinking] Unlink failed:", error);
        throw error;
      }
    }),

  /**
   * Get implant details
   */
  getImplant: protectedProcedure
    .input(z.object({ implantId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        const implant = await db
          .select()
          .from(implants)
          .where(
            and(eq(implants.id, input.implantId), eq(implants.userId, ctx.user.id))
          )
          .limit(1);

        if (!implant[0]) {
          throw new Error("Implant not found or not authorized");
        }

        return {
          id: implant[0].id,
          uid: implant[0].uid,
          name: implant[0].name,
          type: implant[0].type,
          description: implant[0].description,
          status: implant[0].status,
          linkedAt: implant[0].createdAt,
        };
      } catch (error) {
        console.error("[ChipLinking] Failed to get implant:", error);
        throw error;
      }
    }),

  /**
   * Get implant operation history
   */
  getImplantHistory: protectedProcedure
    .input(z.object({ implantId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      try {
        // Verify ownership first
        const implant = await db
          .select()
          .from(implants)
          .where(
            and(eq(implants.id, input.implantId), eq(implants.userId, ctx.user.id))
          )
          .limit(1);

        if (!implant[0]) {
          throw new Error("Implant not found or not authorized");
        }

        // Get operation logs
        const logs = await db
          .select()
          .from(operationLogs)
          .where(eq(operationLogs.implantId, input.implantId));

        return logs.map((log) => ({
          id: log.id,
          operationType: log.operationType,
          status: log.status,
          timestamp: log.createdAt,
          details: log.details ? JSON.parse(log.details) : {},
        }));
      } catch (error) {
        console.error("[ChipLinking] Failed to get history:", error);
        return [];
      }
    }),
});

export type ChipLinkingProcedures = typeof chipLinkingProcedures;
