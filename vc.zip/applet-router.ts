import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  publishApplet,
  getAppletByName,
  getAppletById,
  listPublicApplets,
  searchApplets,
  updateAppletDownloadCount,
  registerUserChip,
  getUserChips,
  getChipByUid,
  installApplet,
  getInstalledApplets,
  recordDeployment,
  getChipDeploymentHistory,
  updateDeploymentStatus,
  logAppletExecution,
  getAppletExecutionLogs,
  getDeveloperByUserId,
  createDeveloperProfile,
  getAppletReviews,
  addAppletReview,
} from "./applet-db";

export const appletRouter = router({
  /**
   * PUBLIC APPLET BROWSING
   */
  listPublic: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(50),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ input }) => {
      return listPublicApplets(input.limit, input.offset);
    }),

  search: publicProcedure
    .input(z.object({ query: z.string().min(1).max(100) }))
    .query(async ({ input }) => {
      return searchApplets(input.query);
    }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return getAppletById(input.id);
    }),

  getByName: publicProcedure
    .input(z.object({ name: z.string() }))
    .query(async ({ input }) => {
      return getAppletByName(input.name);
    }),

  getReviews: publicProcedure
    .input(z.object({ appletId: z.number(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      return getAppletReviews(input.appletId, input.limit);
    }),

  /**
   * PROTECTED: DEVELOPER OPERATIONS
   */
  publishApplet: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(128),
        version: z.string().regex(/^\d+\.\d+\.\d+$/), // Semantic versioning
        description: z.string().optional(),
        aid: z.string(), // Application Identifier
        type: z.enum([
          "payment",
          "authentication",
          "identity",
          "access_control",
          "storage",
          "utility",
          "custom",
        ]),
        bytecode: z.instanceof(Buffer),
        manifest: z.object({
          permissions: z.array(z.string()),
          resources: z.object({
            memory: z.number(),
            eeprom: z.number(),
          }),
        }),
        checksumHash: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Ensure developer profile exists
      let developer = await getDeveloperByUserId(ctx.user.id);
      if (!developer) {
        developer = await createDeveloperProfile(ctx.user.id, ctx.user.name || "Developer");
      }

      const applet = await publishApplet({
        name: input.name,
        version: input.version,
        author: ctx.user.name || "Unknown",
        description: input.description,
        aid: input.aid,
        type: input.type,
        bytecode: input.bytecode,
        manifest: input.manifest,
        checksumHash: input.checksumHash,
        status: "published",
        isPublic: true,
        publishedAt: new Date(),
      });

      return applet;
    }),

  /**
   * PROTECTED: CHIP MANAGEMENT
   */
  registerChip: protectedProcedure
    .input(
      z.object({
        chipUid: z.string(),
        chipType: z.enum(["apex_flex", "spark2", "xm1_gen2"]),
        nickname: z.string().optional(),
        location: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return registerUserChip({
        userId: ctx.user.id,
        chipUid: input.chipUid,
        chipType: input.chipType,
        nickname: input.nickname,
        location: input.location,
        installDate: new Date(),
      });
    }),

  getMyChips: protectedProcedure.query(async ({ ctx }) => {
    return getUserChips(ctx.user.id);
  }),

  /**
   * PROTECTED: APPLET INSTALLATION
   */
  deployApplet: protectedProcedure
    .input(
      z.object({
        appletId: z.number(),
        chipUid: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Verify user owns the chip
      const chip = await getChipByUid(input.chipUid);
      if (!chip || chip.userId !== ctx.user.id) {
        throw new Error("Chip not found or not owned by user");
      }

      const applet = await getAppletById(input.appletId);
      if (!applet) {
        throw new Error("Applet not found");
      }

      // Record deployment
      const deployment = await recordDeployment({
        chipId: chip.id,
        appletId: input.appletId,
        action: "install",
        toVersion: applet.version,
        status: "in_progress",
      });

      if (!deployment) {
        throw new Error("Failed to record deployment");
      }

      // In production, this would trigger NFC communication to deploy applet to chip
      // For now, we'll simulate the deployment
      setTimeout(async () => {
        await updateDeploymentStatus(deployment.id, "success");
        await installApplet({
          chipId: chip.id,
          appletId: input.appletId,
          version: applet.version,
          status: "active",
          grantedPermissions: applet.manifest?.permissions || [],
        });
      }, 1000);

      // Track download
      await updateAppletDownloadCount(input.appletId);

      return deployment;
    }),

  getInstalledApplets: protectedProcedure
    .input(z.object({ chipUid: z.string() }))
    .query(async ({ input, ctx }) => {
      const chip = await getChipByUid(input.chipUid);
      if (!chip || chip.userId !== ctx.user.id) {
        throw new Error("Chip not found or not owned by user");
      }

      return getInstalledApplets(chip.id);
    }),

  getDeploymentHistory: protectedProcedure
    .input(z.object({ chipUid: z.string(), limit: z.number().default(50) }))
    .query(async ({ input, ctx }) => {
      const chip = await getChipByUid(input.chipUid);
      if (!chip || chip.userId !== ctx.user.id) {
        throw new Error("Chip not found or not owned by user");
      }

      return getChipDeploymentHistory(chip.id, input.limit);
    }),

  /**
   * PROTECTED: APPLET EXECUTION
   */
  executeApplet: protectedProcedure
    .input(
      z.object({
        chipUid: z.string(),
        appletId: z.number(),
        command: z.string(),
        commandData: z.instanceof(Buffer).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const chip = await getChipByUid(input.chipUid);
      if (!chip || chip.userId !== ctx.user.id) {
        throw new Error("Chip not found or not owned by user");
      }

      // In production, this would send command to chip via NFC
      // For now, we'll log the execution
      const startTime = Date.now();
      
      await logAppletExecution({
        chipId: chip.id,
        appletId: input.appletId,
        command: input.command,
        commandData: input.commandData,
        responseData: Buffer.from("OK"), // Simulated response
        statusWord: "9000", // Success status word
        executionTime: Date.now() - startTime,
        success: true,
      });

      return { success: true, statusWord: "9000" };
    }),

  getExecutionLogs: protectedProcedure
    .input(
      z.object({
        chipUid: z.string(),
        appletId: z.number(),
        limit: z.number().default(100),
      })
    )
    .query(async ({ input, ctx }) => {
      const chip = await getChipByUid(input.chipUid);
      if (!chip || chip.userId !== ctx.user.id) {
        throw new Error("Chip not found or not owned by user");
      }

      return getAppletExecutionLogs(chip.id, input.appletId, input.limit);
    }),

  /**
   * PROTECTED: REVIEWS
   */
  addReview: protectedProcedure
    .input(
      z.object({
        appletId: z.number(),
        rating: z.number().min(1).max(5),
        title: z.string().optional(),
        content: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return addAppletReview(
        input.appletId,
        ctx.user.id,
        input.rating,
        input.title || "",
        input.content || ""
      );
    }),
});

export type AppletRouter = typeof appletRouter;
