import Stripe from "stripe";
import { eq } from "drizzle-orm";
import {
  userWallets,
  walletBalances,
  transactions,
} from "../drizzle/payment-schema";
import { userChips } from "../drizzle/applet-schema";
import { getDb } from "./db";
import { nfcHandler } from "./nfc-communication";
import { ENV } from "./_core/env";

const stripe = new Stripe(ENV.stripeSecretKey || "", {
  apiVersion: "2024-04-10",
});

/**
 * End-to-End Payment Flow
 * User taps chip → Biometric verification → Payment processing → Wallet update
 */

export interface PaymentFlowRequest {
  chipUid: string;
  amount: number;
  currency: string;
  merchantId: string;
  biometricData: Buffer; // Fingerprint/face data
  description?: string;
}

export interface PaymentFlowResponse {
  success: boolean;
  transactionId?: number;
  stripePaymentIntentId?: string;
  message: string;
  timestamp: Date;
}

/**
 * Execute complete payment flow
 */
export async function executePaymentFlow(
  request: PaymentFlowRequest
): Promise<PaymentFlowResponse> {
  const startTime = Date.now();
  const db = await getDb();

  if (!db) {
    return {
      success: false,
      message: "Database connection failed",
      timestamp: new Date(),
    };
  }

  try {
    console.log(`[PAYMENT] Starting payment flow for chip ${request.chipUid}`);

    // STEP 1: Verify chip and get user
    console.log("[PAYMENT] Step 1: Verifying chip...");
    const chip = await db.query.userChips.findFirst({
      where: eq(userChips.chipUid, request.chipUid),
    });

    if (!chip) {
      return {
        success: false,
        message: "Chip not found",
        timestamp: new Date(),
      };
    }

    console.log(`[PAYMENT] Chip verified: ${chip.chipUid}`);

    // STEP 2: Initialize NFC connection
    console.log("[PAYMENT] Step 2: Initializing NFC connection...");
    const nfcConnected = await nfcHandler.initializeConnection(request.chipUid);

    if (!nfcConnected) {
      return {
        success: false,
        message: "Failed to connect to chip via NFC",
        timestamp: new Date(),
      };
    }

    console.log("[PAYMENT] NFC connection established");

    // STEP 3: Verify biometric on chip
    console.log("[PAYMENT] Step 3: Verifying biometric...");
    const biometricVerified = await nfcHandler.verifyBiometric(request.biometricData);

    if (!biometricVerified) {
      return {
        success: false,
        message: "Biometric verification failed",
        timestamp: new Date(),
      };
    }

    console.log("[PAYMENT] Biometric verified");

    // STEP 4: Get user wallet
    console.log("[PAYMENT] Step 4: Retrieving wallet...");
    const wallet = await db.query.userWallets.findFirst({
      where: eq(userWallets.chipId, chip.id),
    });

    if (!wallet) {
      return {
        success: false,
        message: "No wallet found for this chip",
        timestamp: new Date(),
      };
    }

    console.log(`[PAYMENT] Wallet found: ${wallet.id}`);

    // STEP 5: Create Stripe payment intent
    console.log("[PAYMENT] Step 5: Creating Stripe payment intent...");
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(request.amount * 100), // Convert to cents
      currency: request.currency.toLowerCase(),
      customer: wallet.stripeCustomerId || undefined,
      metadata: {
        chipUid: request.chipUid,
        walletId: wallet.id.toString(),
        userId: wallet.userId.toString(),
        merchantId: request.merchantId,
        biometricVerified: "true",
      },
      description: request.description || `Payment via ${request.chipUid}`,
    });

    console.log(`[PAYMENT] Payment intent created: ${paymentIntent.id}`);

    // STEP 6: Record transaction in database
    console.log("[PAYMENT] Step 6: Recording transaction...");
    const transactionResult = await db.insert(transactions).values({
      walletId: wallet.id,
      transactionType: "payment",
      amount: request.amount.toString(),
      currency: request.currency,
      status: "processing",
      stripePaymentIntentId: paymentIntent.id,
      description: request.description,
    });

    const transactionId = Number(transactionResult[0].insertId);
    console.log(`[PAYMENT] Transaction recorded: ${transactionId}`);

    // STEP 7: Execute payment command on chip
    console.log("[PAYMENT] Step 7: Executing payment command on chip...");
    const paymentCommand = buildPaymentCommand(request.amount, request.currency);

    const commandResult = await nfcHandler.executeAppletCommand(
      "A0000000045645415243482001", // Vearch Payment Applet AID
      "PROCESS_PAYMENT",
      paymentCommand
    );

    if (!commandResult.success) {
      // Update transaction status to failed
      await db
        .update(transactions)
        .set({
          status: "failed",
          errorMessage: "Chip payment command failed",
          completedAt: new Date(),
        })
        .where(eq(transactions.id, transactionId));

      return {
        success: false,
        transactionId,
        message: "Payment command failed on chip",
        timestamp: new Date(),
      };
    }

    console.log("[PAYMENT] Payment command executed on chip");

    // STEP 8: Confirm payment with Stripe
    console.log("[PAYMENT] Step 8: Confirming payment with Stripe...");

    // In production, you would use a saved payment method or tokenized card
    // For this flow, we're using the payment intent directly
    const confirmedPayment = await stripe.paymentIntents.confirm(
      paymentIntent.id,
      {
        payment_method: "pm_card_visa", // This would be the actual payment method
      }
    );

    console.log(`[PAYMENT] Payment confirmed: ${confirmedPayment.status}`);

    // STEP 9: Update transaction status based on payment result
    console.log("[PAYMENT] Step 9: Updating transaction status...");

    const transactionStatus =
      confirmedPayment.status === "succeeded" ? "completed" : "failed";

    await db
      .update(transactions)
      .set({
        status: transactionStatus,
        stripeChargeId: confirmedPayment.charges.data[0]?.id,
        completedAt: new Date(),
      })
      .where(eq(transactions.id, transactionId));

    // STEP 10: Update wallet balance
    if (transactionStatus === "completed") {
      console.log("[PAYMENT] Step 10: Updating wallet balance...");

      const currentBalance = await db.query.walletBalances.findFirst({
        where: eq(walletBalances.walletId, wallet.id),
      });

      if (currentBalance) {
        const newBalance = Number(currentBalance.balance) - request.amount;

        await db
          .update(walletBalances)
          .set({ balance: newBalance.toString() })
          .where(eq(walletBalances.walletId, wallet.id));

        console.log(`[PAYMENT] Wallet balance updated: ${newBalance}`);
      }
    }

    const duration = Date.now() - startTime;
    console.log(`[PAYMENT] Payment flow completed in ${duration}ms`);

    return {
      success: transactionStatus === "completed",
      transactionId,
      stripePaymentIntentId: paymentIntent.id,
      message:
        transactionStatus === "completed"
          ? "Payment successful"
          : "Payment failed",
      timestamp: new Date(),
    };
  } catch (error) {
    console.error("[PAYMENT] Payment flow error:", error);

    return {
      success: false,
      message: error instanceof Error ? error.message : "Unknown error",
      timestamp: new Date(),
    };
  }
}

/**
 * Build payment command for chip
 */
function buildPaymentCommand(amount: number, currency: string): Buffer {
  // Format: [Amount (4 bytes)] [Currency (3 bytes)] [Timestamp (4 bytes)]
  const amountBuffer = Buffer.alloc(4);
  amountBuffer.writeUInt32BE(Math.round(amount * 100), 0); // Amount in cents

  const currencyBuffer = Buffer.alloc(3);
  currencyBuffer.write(currency.padEnd(3, " "), 0, "utf8");

  const timestampBuffer = Buffer.alloc(4);
  timestampBuffer.writeUInt32BE(Math.floor(Date.now() / 1000), 0);

  return Buffer.concat([amountBuffer, currencyBuffer, timestampBuffer]);
}

/**
 * Handle payment webhook from Stripe
 */
export async function handlePaymentWebhook(event: Stripe.Event) {
  const db = await getDb();
  if (!db) return;

  switch (event.type) {
    case "payment_intent.succeeded": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;

      // Update transaction status
      await db
        .update(transactions)
        .set({
          status: "completed",
          completedAt: new Date(),
        })
        .where(eq(transactions.stripePaymentIntentId, paymentIntent.id));

      console.log(`[PAYMENT] Webhook: Payment succeeded ${paymentIntent.id}`);
      break;
    }

    case "payment_intent.payment_failed": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;

      // Update transaction status
      await db
        .update(transactions)
        .set({
          status: "failed",
          errorMessage: paymentIntent.last_payment_error?.message,
          completedAt: new Date(),
        })
        .where(eq(transactions.stripePaymentIntentId, paymentIntent.id));

      console.log(`[PAYMENT] Webhook: Payment failed ${paymentIntent.id}`);
      break;
    }

    case "charge.refunded": {
      const charge = event.data.object as Stripe.Charge;

      if (charge.payment_intent) {
        // Find and update the original transaction
        const originalTx = await db.query.transactions.findFirst({
          where: eq(
            transactions.stripePaymentIntentId,
            charge.payment_intent as string
          ),
        });

        if (originalTx) {
          // Create refund transaction
          const refundAmount = charge.amount_refunded / 100;

          await db.insert(transactions).values({
            walletId: originalTx.walletId,
            transactionType: "refund",
            amount: refundAmount.toString(),
            currency: originalTx.currency,
            status: "completed",
            description: `Refund for payment ${charge.id}`,
            completedAt: new Date(),
          });

          // Update wallet balance
          const balance = await db.query.walletBalances.findFirst({
            where: eq(walletBalances.walletId, originalTx.walletId),
          });

          if (balance) {
            const newBalance = Number(balance.balance) + refundAmount;

            await db
              .update(walletBalances)
              .set({ balance: newBalance.toString() })
              .where(eq(walletBalances.walletId, originalTx.walletId));
          }

          console.log(`[PAYMENT] Webhook: Refund processed ${charge.id}`);
        }
      }
      break;
    }
  }
}

/**
 * Get payment status
 */
export async function getPaymentStatus(
  transactionId: number
): Promise<{
  status: string;
  amount: string;
  currency: string;
  timestamp: Date;
}> {
  const db = await getDb();

  if (!db) {
    return {
      status: "error",
      amount: "0",
      currency: "USD",
      timestamp: new Date(),
    };
  }

  const transaction = await db.query.transactions.findFirst({
    where: eq(transactions.id, transactionId),
  });

  if (!transaction) {
    return {
      status: "not_found",
      amount: "0",
      currency: "USD",
      timestamp: new Date(),
    };
  }

  return {
    status: transaction.status,
    amount: transaction.amount,
    currency: transaction.currency,
    timestamp: transaction.initiatedAt,
  };
}
