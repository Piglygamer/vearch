import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Cpu, Shield, Zap, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Comparison() {
  const [, navigate] = useLocation();

  const chips = [
    {
      id: "xm1",
      name: "xM1 gen2",
      price: "$89.00",
      icon: <Cpu className="w-8 h-8" />,
      color: "from-blue-500 to-blue-600",
      formFactor: "3×13mm cylindrical bioglass",
      protocol: "13.56MHz ISO14443-A",
      memory: "768 bytes user-programmable",
      encryption: "Crypto1 (legacy)",
      specs: {
        "Chip Type": "Mifare S50 1k Emulator",
        "UID": "4-byte NUID (writable)",
        "Sector 0": "Fully writable",
        "Versions": "gen1a (backdoor) / gen2 (direct write)",
        "Detection": "gen2 harder to detect",
        "Programming": "Android MCT app support",
        "Installation": "Professional required",
        "Read Range": "Extremely short (x-series)",
      },
      features: [
        "Writable 4-byte ID",
        "All sector 0 writable",
        "Cloning support",
        "Access control compatible",
        "NFC smartphone readable",
        "Event triggering",
        "Backdoor command (gen1a)",
        "Field programmable (gen2)",
      ],
      useCases: [
        "Copy HF chip IDs",
        "Access control systems",
        "Computer login",
        "NFC data sharing",
        "Event triggers",
        "Door locks",
        "Attendance systems",
      ],
      limitations: [
        "No payment capability",
        "4-byte UID only (not 7-byte)",
        "Mifare Classic protocol",
        "Shorter read range",
        "Legacy encryption",
      ],
    },
    {
      id: "spark2",
      name: "VivoKey Spark 2",
      price: "$50.00",
      icon: <Shield className="w-8 h-8" />,
      color: "from-emerald-500 to-emerald-600",
      formFactor: "2.1×14mm cylindrical bioglass",
      protocol: "13.56MHz ISO14443A / NFC Type 4",
      memory: "Fixed capacity",
      encryption: "AES128 (FIPS 197)",
      specs: {
        "Cryptography": "AES128 (FIPS PUB 197)",
        "CMAC": "NIST SP 800-38B",
        "Payload Salt": "2-byte",
        "Certification": "EO gas sterilized",
        "Status": "Pre-tested & pre-loaded",
        "Detector": "13.56MHz X Field included",
        "Installation": "Professional required",
        "Customization": "Fixed-function device",
      },
      features: [
        "AES128 encryption",
        "FIPS 197 compliant",
        "Plug-and-play deployment",
        "Pre-sterilized assembly",
        "NFC Type 4 compatible",
        "Field detector included",
        "NIST certified",
        "Secure payload",
      ],
      useCases: [
        "Cryptographic authentication",
        "Secure data storage",
        "NFC reader compatible",
        "Biometric integration",
        "Secure identity",
        "Encrypted communications",
        "Two-factor authentication",
      ],
      limitations: [
        "Fixed-function device",
        "No applet deployment",
        "NOT Tesla-capable",
        "Shorter read range",
        "No customization",
      ],
    },
    {
      id: "apex",
      name: "Apex Flex",
      price: "$349–$449",
      icon: <Zap className="w-8 h-8" />,
      color: "from-purple-500 to-purple-600",
      formFactor: "7.5×28×0.4mm flexible biopolymer",
      protocol: "JCOP 4 / Java Card 3.0.5",
      memory: "83,872 bytes EEPROM",
      encryption: "Full cryptographic suite",
      specs: {
        "Platform": "Java Card 3.0.5",
        "Certification": "Common Criteria EAL 6+",
        "Applet Deployment": "Fidesmo (user-friendly)",
        "Antennas": "Narrow / Module / Spectrum",
        "Installation": "Scalpel or needle procedure",
        "Manufacturing": "Small batch USA production",
        "Flexibility": "Biocompatible polymer",
        "Customization": "Unlimited applets",
      },
      features: [
        "Java Card applets",
        "83KB application storage",
        "EAL 6+ certified",
        "Multiple antenna options",
        "Fidesmo app deployment",
        "OTP, Tesla, NFC Share applets",
        "Custom applet support",
        "Blockchain ready",
      ],
      useCases: [
        "Digital identity",
        "Blockchain applications",
        "OTP authentication",
        "Tesla vehicle access",
        "Custom cryptography",
        "NFC sharing",
        "Cryptocurrency wallets",
        "Advanced security",
      ],
      limitations: [
        "NO payment support",
        "Requires professional install",
        "Higher cost",
        "More complex setup",
        "Scalpel procedure required",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">Chip Comparison</h1>
            <p className="text-sm text-slate-400">
              Detailed specifications and capabilities
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {/* Three-Panel Comparison */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {chips.map((chip) => (
            <Card
              key={chip.id}
              className="flex flex-col overflow-hidden border-slate-700 bg-slate-800/50 hover:border-slate-600 transition-colors"
            >
              {/* Header with gradient */}
              <div className={`bg-gradient-to-r ${chip.color} p-6 text-white`}>
                <div className="flex items-center justify-between mb-3">
                  <div className="p-2 bg-white/20 rounded-lg">{chip.icon}</div>
                  <Badge variant="secondary" className="text-xs">
                    {chip.price}
                  </Badge>
                </div>
                <h3 className="text-2xl font-bold">{chip.name}</h3>
                <p className="text-white/80 text-sm mt-2">{chip.formFactor}</p>
              </div>

              {/* Content */}
              <CardContent className="flex-1 pt-6 pb-4">
                <Tabs defaultValue="specs" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-4 bg-slate-700/50">
                    <TabsTrigger value="specs" className="text-xs">
                      Specs
                    </TabsTrigger>
                    <TabsTrigger value="features" className="text-xs">
                      Features
                    </TabsTrigger>
                    <TabsTrigger value="use" className="text-xs">
                      Use Cases
                    </TabsTrigger>
                  </TabsList>

                  {/* Specs Tab */}
                  <TabsContent value="specs" className="space-y-3">
                    <div className="space-y-2 text-sm">
                      <div>
                        <p className="font-semibold text-slate-300">Protocol</p>
                        <p className="text-slate-400">{chip.protocol}</p>
                      </div>
                      <div>
                        <p className="font-semibold text-slate-300">Memory</p>
                        <p className="text-slate-400">{chip.memory}</p>
                      </div>
                      <div>
                        <p className="font-semibold text-slate-300">Encryption</p>
                        <p className="text-slate-400">{chip.encryption}</p>
                      </div>
                    </div>

                    {/* Detailed specs */}
                    <div className="mt-4 pt-4 border-t border-slate-700 space-y-2">
                      {Object.entries(chip.specs).map(([key, value]) => (
                        <div key={key} className="text-xs">
                          <p className="font-medium text-slate-300">{key}</p>
                          <p className="text-slate-400">{value}</p>
                        </div>
                      ))}
                    </div>
                  </TabsContent>

                  {/* Features Tab */}
                  <TabsContent value="features" className="space-y-2">
                    {chip.features.map((feature, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2 text-sm p-2 rounded bg-slate-700/30"
                      >
                        <span className="text-green-400 font-bold mt-0.5">✓</span>
                        <span className="text-slate-300">{feature}</span>
                      </div>
                    ))}
                  </TabsContent>

                  {/* Use Cases Tab */}
                  <TabsContent value="use" className="space-y-2">
                    {chip.useCases.map((useCase, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2 text-sm p-2 rounded bg-blue-900/20"
                      >
                        <span className="text-blue-400 mt-0.5">→</span>
                        <span className="text-slate-300">{useCase}</span>
                      </div>
                    ))}
                  </TabsContent>
                </Tabs>

                {/* Limitations */}
                <div className="mt-6 pt-4 border-t border-slate-700">
                  <p className="text-xs font-semibold text-slate-300 mb-2">
                    Limitations
                  </p>
                  <div className="space-y-1">
                    {chip.limitations.map((limit, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2 text-xs p-1.5 rounded bg-red-900/20"
                      >
                        <span className="text-red-400 font-bold">✕</span>
                        <span className="text-slate-300">{limit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Comparison Table */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">
            Side-by-Side Comparison
          </h2>
          <div className="overflow-x-auto rounded-lg border border-slate-700 bg-slate-800/50">
            <table className="w-full text-sm">
              <thead className="bg-slate-700/50 border-b border-slate-700">
                <tr>
                  <th className="px-4 py-3 text-left font-semibold text-slate-100">
                    Specification
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-100">
                    xM1 gen2
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-100">
                    Spark 2
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-100">
                    Apex Flex
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {[
                  ["Price", "$89.00", "$50.00", "$349–$449"],
                  ["Form Factor", "3×13mm cylinder", "2.1×14mm cylinder", "7.5×28×0.4mm flex"],
                  ["Protocol", "ISO14443-A", "ISO14443A / NFC Type 4", "Java Card 3.0.5"],
                  ["Memory", "768 bytes", "Fixed capacity", "83,872 bytes"],
                  ["Encryption", "Crypto1 (legacy)", "AES128 (FIPS 197)", "Full suite (EAL 6+)"],
                  ["Customization", "Writable UID", "Fixed function", "Java applets"],
                  ["Payment Support", "✕ No", "✕ No", "✕ No"],
                  ["Installation", "Professional", "Professional", "Professional (scalpel)"],
                  ["Read Range", "Extremely short", "Extremely short", "Variable (antenna)"],
                  ["Cost Effectiveness", "★★★★★", "★★★★★", "★★★☆☆"],
                ].map((row, idx) => (
                  <tr
                    key={idx}
                    className="hover:bg-slate-700/30 transition-colors"
                  >
                    <td className="px-4 py-3 font-medium text-slate-100">
                      {row[0]}
                    </td>
                    <td className="px-4 py-3 text-slate-300">{row[1]}</td>
                    <td className="px-4 py-3 text-slate-300">{row[2]}</td>
                    <td className="px-4 py-3 text-slate-300">{row[3]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Recommendation Guide */}
        <section className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border border-blue-800/50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-white mb-6">Which Chip Is Right for You?</h2>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700">
              <h3 className="text-lg font-bold text-blue-400 mb-3">Choose xM1 gen2 if:</h3>
              <ul className="space-y-2 text-slate-300 text-sm">
                <li>✓ Budget-conscious</li>
                <li>✓ Need access control</li>
                <li>✓ Want cloning capability</li>
                <li>✓ Prefer simplicity</li>
                <li>✓ Testing biohacking</li>
              </ul>
            </div>

            <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700">
              <h3 className="text-lg font-bold text-emerald-400 mb-3">Choose Spark 2 if:</h3>
              <ul className="space-y-2 text-slate-300 text-sm">
                <li>✓ Want strong encryption</li>
                <li>✓ Need FIPS compliance</li>
                <li>✓ Prefer plug-and-play</li>
                <li>✓ Most affordable crypto</li>
                <li>✓ Secure authentication</li>
              </ul>
            </div>

            <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700">
              <h3 className="text-lg font-bold text-purple-400 mb-3">Choose Apex Flex if:</h3>
              <ul className="space-y-2 text-slate-300 text-sm">
                <li>✓ Need unlimited customization</li>
                <li>✓ Want applet deployment</li>
                <li>✓ Blockchain applications</li>
                <li>✓ Advanced security</li>
                <li>✓ Future-proof investment</li>
              </ul>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
