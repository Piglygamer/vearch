import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

/**
 * Real Merchant Terminal
 * Accepts tap-to-pay transactions from biohacking implants
 * 
 * Flow:
 * 1. Merchant enters transaction amount
 * 2. Customer taps their implant
 * 3. Terminal reads UID from implant
 * 4. Terminal POSTs UID + amount to /api/merchant/charge
 * 5. Vearch backend charges customer's card
 * 6. Funds transferred to merchant's Stripe Connect account
 * 7. Transaction confirmed
 */

interface Transaction {
  id: string;
  uid: string;
  amount: number;
  currency: string;
  status: "pending" | "success" | "failed";
  timestamp: string;
  customerName?: string;
}

export default function MerchantTerminal() {
  const [amount, setAmount] = useState<string>("");
  const [currency, setCurrency] = useState<string>("USD");
  const [isReading, setIsReading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [merchantKey, setMerchantKey] = useState<string>(
    localStorage.getItem("merchant_key") || ""
  );
  const [showKeyInput, setShowKeyInput] = useState(!merchantKey);

  // Get merchant info
  const { data: merchantInfo } = trpc.merchant.whoami.useQuery(
    { merchantKey },
    { enabled: !!merchantKey }
  );

  // Process transaction mutation
  const processTransaction = trpc.merchant.charge.useMutation({
    onSuccess: (result) => {
      setIsProcessing(false);
      toast.success(`Transaction successful! Amount: $${(result.amount / 100).toFixed(2)}`);

      // Add to transaction history
      const newTransaction: Transaction = {
        id: result.transactionId,
        uid: result.uid,
        amount: result.amount,
        currency: result.currency,
        status: "success",
        timestamp: new Date().toISOString(),
      };

      setTransactions([newTransaction, ...transactions]);
      setAmount("");
    },
    onError: (error) => {
      setIsProcessing(false);
      toast.error(`Transaction failed: ${error.message}`);
    },
  });

  /**
   * Start NFC read for customer tap
   */
  const startNFCRead = async () => {
    if (!amount) {
      toast.error("Please enter transaction amount");
      return;
    }

    setIsReading(true);

    try {
      // Check if Web NFC is supported
      if (!("NDEFReader" in window)) {
        toast.error("NFC not supported on this device");
        setIsReading(false);
        return;
      }

      const ndef = new (window as any).NDEFReader();

      // Start scanning
      await ndef.scan();

      ndef.addEventListener("reading", async (event: any) => {
        try {
          const { serialNumber } = event.message;

          if (!serialNumber) {
            toast.error("Could not read chip UID");
            setIsReading(false);
            return;
          }

          console.log("[Terminal] Chip read: UID =", serialNumber);

          // Process transaction
          setIsProcessing(true);

          processTransaction.mutate({
            uid: serialNumber,
            amountCents: Math.round(parseFloat(amount) * 100),
            currency: currency.toLowerCase(),
            merchantKey: merchantKey,
          });

          setIsReading(false);
        } catch (error) {
          console.error("[Terminal] Error processing read:", error);
          toast.error("Error processing transaction");
          setIsReading(false);
        }
      });

      ndef.addEventListener("error", (event: any) => {
        console.error("[Terminal] NFC error:", event);
        toast.error("NFC read failed");
        setIsReading(false);
      });

      // Timeout after 30 seconds
      setTimeout(() => {
        if (isReading) {
          setIsReading(false);
          toast.error("NFC read timeout");
        }
      }, 30000);
    } catch (error) {
      console.error("[Terminal] NFC setup failed:", error);
      toast.error("Failed to start NFC read");
      setIsReading(false);
    }
  };

  /**
   * Save merchant key
   */
  const saveMerchantKey = () => {
    if (!merchantKey.trim()) {
      toast.error("Please enter merchant API key");
      return;
    }

    localStorage.setItem("merchant_key", merchantKey);
    setShowKeyInput(false);
    toast.success("Merchant key saved");
  };

  /**
   * Format currency
   */
  const formatCurrency = (cents: number, curr: string) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: curr,
    }).format(cents / 100);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Merchant Terminal</h1>
          <p className="text-slate-400">Accept tap-to-pay implant transactions</p>
        </div>

        {/* Merchant Key Setup */}
        {showKeyInput && (
          <Card className="bg-slate-800 border-slate-700 p-6 mb-6">
            <h2 className="text-xl font-semibold text-white mb-4">Merchant Setup</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-300 mb-2">Merchant API Key</label>
                <Input
                  type="password"
                  placeholder="vmk_..."
                  value={merchantKey}
                  onChange={(e) => setMerchantKey(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white"
                />
              </div>
              <Button
                onClick={saveMerchantKey}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                Save Merchant Key
              </Button>
            </div>
          </Card>
        )}

        {/* Merchant Info */}
        {merchantInfo && (
          <Card className="bg-slate-800 border-slate-700 p-6 mb-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-slate-400">Merchant</p>
                <p className="text-xl font-semibold text-white">{merchantInfo.name}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  localStorage.removeItem("merchant_key");
                  setMerchantKey("");
                  setShowKeyInput(true);
                }}
              >
                Change Key
              </Button>
            </div>
          </Card>
        )}

        {/* Transaction Input */}
        <Card className="bg-slate-800 border-slate-700 p-6 mb-6">
          <h2 className="text-xl font-semibold text-white mb-4">New Transaction</h2>

          <div className="space-y-4">
            {/* Amount Input */}
            <div>
              <label className="block text-sm text-slate-300 mb-2">Amount</label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  step="0.01"
                  min="0"
                  className="bg-slate-700 border-slate-600 text-white flex-1"
                />
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="bg-slate-700 border border-slate-600 text-white px-3 rounded-md"
                >
                  <option>USD</option>
                  <option>EUR</option>
                  <option>GBP</option>
                  <option>CAD</option>
                </select>
              </div>
            </div>

            {/* NFC Read Button */}
            <Button
              onClick={startNFCRead}
              disabled={isReading || isProcessing || !amount}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-6 text-lg"
            >
              {isReading && <Spinner className="mr-2 h-5 w-5" />}
              {isProcessing && <Spinner className="mr-2 h-5 w-5" />}
              {isReading ? "Waiting for tap..." : isProcessing ? "Processing..." : "Ready for Tap"}
            </Button>

            {/* Instructions */}
            <div className="bg-slate-700 rounded-lg p-4 text-sm text-slate-300">
              <p className="font-semibold text-white mb-2">Instructions:</p>
              <ol className="list-decimal list-inside space-y-1">
                <li>Enter transaction amount</li>
                <li>Click "Ready for Tap"</li>
                <li>Customer taps their implant on device</li>
                <li>Transaction processes automatically</li>
              </ol>
            </div>
          </div>
        </Card>

        {/* Transaction History */}
        {transactions.length > 0 && (
          <Card className="bg-slate-800 border-slate-700 p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Transaction History</h2>

            <div className="space-y-3 max-h-96 overflow-y-auto">
              {transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="flex justify-between items-center bg-slate-700 rounded-lg p-4"
                >
                  <div>
                    <p className="text-sm text-slate-400">UID: {tx.uid.substring(0, 16)}...</p>
                    <p className="text-xs text-slate-500">
                      {new Date(tx.timestamp).toLocaleString()}
                    </p>
                  </div>

                  <div className="text-right">
                    <p className="text-lg font-semibold text-white">
                      {formatCurrency(tx.amount, tx.currency)}
                    </p>
                    <p
                      className={`text-sm font-semibold ${
                        tx.status === "success" ? "text-green-400" : "text-red-400"
                      }`}
                    >
                      {tx.status.toUpperCase()}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="mt-4 pt-4 border-t border-slate-600">
              <p className="text-sm text-slate-400">
                Total transactions:{" "}
                <span className="text-white font-semibold">{transactions.length}</span>
              </p>
              <p className="text-sm text-slate-400">
                Total volume:{" "}
                <span className="text-white font-semibold">
                  {formatCurrency(
                    transactions.reduce((sum, tx) => sum + tx.amount, 0),
                    currency
                  )}
                </span>
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
