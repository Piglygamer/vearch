import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { spark2Manager } from "./vivokey-spark2-manager";
import { magicChipManager } from "./magic-chip-manager";
import { apexFlexManager } from "./apex-flex-manager";
import {
  addUserChip,
  getUserChips,
  getUserChipById,
  updateUserChip,
  deleteUserChip,
  createChipBackup,
  getUserChipBackups,
  deleteChipBackup,
  logOperation,
  getUserOperationLogs,
  getChipOperationLogs,
} from "./user-account-db";

/**
 * Chip Management Router
 * tRPC procedures for all chip operations
 */

export const chipManagementRouter = router({
  // ==========================================
  // VIVOKEY SPARK 2 OPERATIONS
  // ==========================================

  spark2: router({
    /**
     * Discover and connect to VivoKey Spark 2 chip
     */
    discover: protectedProcedure
      .input(z.object({ uid: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const chip = await spark2Manager.discoverChip(input.uid);

          if (!chip) {
            throw new Error("Failed to discover chip");
          }

          // Add to user's chips
          const userChip = await addUserChip({
            userId: ctx.user.id,
            chipType: "vivokey_spark2",
            uid: input.uid,
          });

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: userChip?.id,
            operationType: "read",
            operationDetails: { action: "discover", chipType: "vivokey_spark2" },
            success: true,
          });

          return { success: true, chip, userChipId: userChip?.id };
        } catch (error) {
          console.error("[ROUTER] Spark2 discover failed:", error);
          throw error;
        }
      }),

    /**
     * Read sector from VivoKey Spark 2
     */
    readSector: protectedProcedure
      .input(z.object({ chipId: z.number(), sectorNumber: z.number() }))
      .query(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const sector = await spark2Manager.readSector(userChip.uid, input.sectorNumber);

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.chipId,
            operationType: "read",
            operationDetails: { sectorNumber: input.sectorNumber },
            success: !!sector,
          });

          return sector;
        } catch (error) {
          console.error("[ROUTER] Spark2 read sector failed:", error);
          throw error;
        }
      }),

    /**
     * Write sector to VivoKey Spark 2
     */
    writeSector: protectedProcedure
      .input(
        z.object({
          chipId: z.number(),
          sectorNumber: z.number(),
          data: z.string(), // Hex string
        })
      )
      .mutation(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const dataBuffer = Buffer.from(input.data, "hex");
          const success = await spark2Manager.writeSector(
            userChip.uid,
            input.sectorNumber,
            dataBuffer
          );

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.chipId,
            operationType: "write",
            operationDetails: { sectorNumber: input.sectorNumber },
            success,
          });

          return { success };
        } catch (error) {
          console.error("[ROUTER] Spark2 write sector failed:", error);
          throw error;
        }
      }),

    /**
     * Read all sectors
     */
    readAllSectors: protectedProcedure
      .input(z.object({ chipId: z.number() }))
      .query(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const sectors = await spark2Manager.readAllSectors(userChip.uid);

          return sectors;
        } catch (error) {
          console.error("[ROUTER] Spark2 read all sectors failed:", error);
          throw error;
        }
      }),
  }),

  // ==========================================
  // MAGIC CHIPS (xM1 gen2) OPERATIONS
  // ==========================================

  magic: router({
    /**
     * Discover magic chip
     */
    discover: protectedProcedure
      .input(z.object({ cuid: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const chip = await magicChipManager.discoverChip(input.cuid);

          if (!chip) {
            throw new Error("Failed to discover chip");
          }

          const userChip = await addUserChip({
            userId: ctx.user.id,
            chipType: "magic_xm1_gen2",
            uid: input.cuid,
            cuid: input.cuid,
          });

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: userChip?.id,
            operationType: "read",
            operationDetails: { action: "discover", chipType: "magic_xm1_gen2" },
            success: true,
          });

          return { success: true, chip, userChipId: userChip?.id };
        } catch (error) {
          console.error("[ROUTER] Magic chip discover failed:", error);
          throw error;
        }
      }),

    /**
     * Change UID on magic chip
     */
    changeUid: protectedProcedure
      .input(z.object({ chipId: z.number(), newUid: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const success = await magicChipManager.changeUid(userChip.cuid || userChip.uid, input.newUid);

          // Update user chip record
          if (success) {
            await updateUserChip(input.chipId, { cuid: input.newUid, uid: input.newUid });
          }

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.chipId,
            operationType: "uid_change",
            operationDetails: { oldUid: userChip.uid, newUid: input.newUid },
            success,
          });

          return { success };
        } catch (error) {
          console.error("[ROUTER] Magic chip UID change failed:", error);
          throw error;
        }
      }),

    /**
     * Clone card
     */
    cloneCard: protectedProcedure
      .input(z.object({ sourceChipId: z.number(), targetChipId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const sourceChip = await getUserChipById(ctx.user.id, input.sourceChipId);
          const targetChip = await getUserChipById(ctx.user.id, input.targetChipId);

          if (!sourceChip || !targetChip) {
            throw new Error("Source or target chip not found");
          }

          const success = await magicChipManager.cloneCard(
            sourceChip.cuid || sourceChip.uid,
            targetChip.cuid || targetChip.uid
          );

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.targetChipId,
            operationType: "clone",
            operationDetails: { sourceChipId: input.sourceChipId },
            success,
          });

          return { success };
        } catch (error) {
          console.error("[ROUTER] Magic chip clone failed:", error);
          throw error;
        }
      }),

    /**
     * Backup chip
     */
    backupChip: protectedProcedure
      .input(z.object({ chipId: z.number(), backupName: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const backup = await magicChipManager.backupChip(userChip.cuid || userChip.uid);

          if (!backup) {
            throw new Error("Backup failed");
          }

          const backupRecord = await createChipBackup({
            userId: ctx.user.id,
            chipId: input.chipId,
            backupName: input.backupName,
            backupData: backup.toString("base64"),
            backupSize: backup.length,
            chipSnapshot: {
              uid: userChip.uid,
              chipType: userChip.chipType,
              timestamp: new Date(),
            },
          });

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.chipId,
            operationType: "backup",
            operationDetails: { backupName: input.backupName, backupSize: backup.length },
            success: !!backupRecord,
          });

          return { success: !!backupRecord, backupId: backupRecord?.id };
        } catch (error) {
          console.error("[ROUTER] Magic chip backup failed:", error);
          throw error;
        }
      }),

    /**
     * Restore chip from backup
     */
    restoreChip: protectedProcedure
      .input(z.object({ chipId: z.number(), backupId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const backups = await getUserChipBackups(ctx.user.id, input.chipId);
          const backup = backups.find((b) => b.id === input.backupId);

          if (!backup || !backup.backupData) {
            throw new Error("Backup not found");
          }

          const backupBuffer = Buffer.from(backup.backupData, "base64");
          const success = await magicChipManager.restoreChip(
            userChip.cuid || userChip.uid,
            backupBuffer
          );

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.chipId,
            operationType: "restore",
            operationDetails: { backupId: input.backupId },
            success,
          });

          return { success };
        } catch (error) {
          console.error("[ROUTER] Magic chip restore failed:", error);
          throw error;
        }
      }),
  }),

  // ==========================================
  // APEX FLEX OPERATIONS
  // ==========================================

  apex: router({
    /**
     * Discover Apex Flex chip
     */
    discover: protectedProcedure
      .input(z.object({ uid: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const chip = await apexFlexManager.discoverChip(input.uid);

          if (!chip) {
            throw new Error("Failed to discover chip");
          }

          const userChip = await addUserChip({
            userId: ctx.user.id,
            chipType: "apex_flex",
            uid: input.uid,
          });

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: userChip?.id,
            operationType: "read",
            operationDetails: { action: "discover", chipType: "apex_flex" },
            success: true,
          });

          return { success: true, chip, userChipId: userChip?.id };
        } catch (error) {
          console.error("[ROUTER] Apex discover failed:", error);
          throw error;
        }
      }),

    /**
     * Install applet
     */
    installApplet: protectedProcedure
      .input(z.object({ chipId: z.number(), appletAid: z.string() }))
      .mutation(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const success = await apexFlexManager.installApplet(userChip.uid, input.appletAid);

          // Log operation
          await logOperation({
            userId: ctx.user.id,
            chipId: input.chipId,
            operationType: "applet_install",
            operationDetails: { appletAid: input.appletAid },
            success,
          });

          return { success };
        } catch (error) {
          console.error("[ROUTER] Apex install applet failed:", error);
          throw error;
        }
      }),

    /**
     * Get installed applets
     */
    getInstalledApplets: protectedProcedure
      .input(z.object({ chipId: z.number() }))
      .query(async ({ input, ctx }) => {
        try {
          const userChip = await getUserChipById(ctx.user.id, input.chipId);
          if (!userChip) {
            throw new Error("Chip not found");
          }

          const applets = apexFlexManager.getInstalledApplets(userChip.uid);

          return applets || [];
        } catch (error) {
          console.error("[ROUTER] Apex get installed applets failed:", error);
          throw error;
        }
      }),

    /**
     * Get available applets
     */
    getAvailableApplets: protectedProcedure.query(async () => {
      try {
        return apexFlexManager.getAvailableApplets();
      } catch (error) {
        console.error("[ROUTER] Apex get available applets failed:", error);
        throw error;
      }
    }),
  }),

  // ==========================================
  // GENERAL CHIP OPERATIONS
  // ==========================================

  /**
   * Get user's chips
   */
  getUserChips: protectedProcedure.query(async ({ ctx }) => {
    try {
      return await getUserChips(ctx.user.id);
    } catch (error) {
      console.error("[ROUTER] Get user chips failed:", error);
      throw error;
    }
  }),

  /**
   * Get chip backups
   */
  getChipBackups: protectedProcedure
    .input(z.object({ chipId: z.number() }))
    .query(async ({ input, ctx }) => {
      try {
        return await getUserChipBackups(ctx.user.id, input.chipId);
      } catch (error) {
        console.error("[ROUTER] Get chip backups failed:", error);
        throw error;
      }
    }),

  /**
   * Delete chip backup
   */
  deleteChipBackup: protectedProcedure
    .input(z.object({ backupId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const success = await deleteChipBackup(ctx.user.id, input.backupId);
        return { success };
      } catch (error) {
        console.error("[ROUTER] Delete chip backup failed:", error);
        throw error;
      }
    }),

  /**
   * Get operation logs
   */
  getOperationLogs: protectedProcedure
    .input(z.object({ chipId: z.number().optional(), limit: z.number().default(50) }))
    .query(async ({ input, ctx }) => {
      try {
        if (input.chipId) {
          return await getChipOperationLogs(input.chipId, input.limit);
        }
        return await getUserOperationLogs(ctx.user.id, input.limit);
      } catch (error) {
        console.error("[ROUTER] Get operation logs failed:", error);
        throw error;
      }
    }),
});
