import { eq, and, desc, like } from "drizzle-orm";
import {
  applets,
  appletVersions,
  userChips,
  installedApplets,
  deploymentHistory,
  appletExecutionLogs,
  developers,
  appletReviews,
  Applet,
  InsertApplet,
  UserChip,
  InsertUserChip,
  InstalledApplet,
  InsertInstalledApplet,
  DeploymentHistory,
  InsertDeploymentHistory,
} from "../drizzle/applet-schema";
import { getDb } from "./db";

/**
 * APPLET MANAGEMENT
 */

export async function publishApplet(applet: InsertApplet): Promise<Applet | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(applets).values(applet);
  const appletId = result[0].insertId;
  return db.query.applets.findFirst({ where: eq(applets.id, Number(appletId)) });
}

export async function getAppletByName(name: string): Promise<Applet | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.query.applets.findFirst({
    where: eq(applets.name, name),
  });
  return result || null;
}

export async function getAppletById(id: number): Promise<Applet | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.query.applets.findFirst({
    where: eq(applets.id, id),
  });
  return result || null;
}

export async function listPublicApplets(limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];

  return db.query.applets.findMany({
    where: and(eq(applets.isPublic, true), eq(applets.status, "published")),
    limit,
    offset,
    orderBy: desc(applets.downloads),
  });
}

export async function searchApplets(query: string) {
  const db = await getDb();
  if (!db) return [];

  return db.query.applets.findMany({
    where: and(
      eq(applets.isPublic, true),
      eq(applets.status, "published"),
      like(applets.name, `%${query}%`)
    ),
    limit: 20,
  });
}

export async function updateAppletDownloadCount(appletId: number) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(applets)
    .set({ downloads: applets.downloads + 1 })
    .where(eq(applets.id, appletId));
}

/**
 * CHIP MANAGEMENT
 */

export async function registerUserChip(chip: InsertUserChip): Promise<UserChip | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(userChips).values(chip);
  const chipId = result[0].insertId;
  return db.query.userChips.findFirst({ where: eq(userChips.id, Number(chipId)) });
}

export async function getUserChips(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.query.userChips.findMany({
    where: eq(userChips.userId, userId),
  });
}

export async function getChipByUid(chipUid: string): Promise<UserChip | null> {
  const db = await getDb();
  if (!db) return null;

  return db.query.userChips.findFirst({
    where: eq(userChips.chipUid, chipUid),
  });
}

export async function updateChipLastSeen(chipId: number) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(userChips)
    .set({ lastSeen: new Date() })
    .where(eq(userChips.id, chipId));
}

/**
 * APPLET INSTALLATION
 */

export async function installApplet(
  installation: InsertInstalledApplet
): Promise<InstalledApplet | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(installedApplets).values(installation);
  const installId = result[0].insertId;
  return db.query.installedApplets.findFirst({
    where: eq(installedApplets.id, Number(installId)),
  });
}

export async function getInstalledApplets(chipId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.query.installedApplets.findMany({
    where: eq(installedApplets.chipId, chipId),
  });
}

export async function getInstalledApplet(chipId: number, appletId: number) {
  const db = await getDb();
  if (!db) return null;

  return db.query.installedApplets.findFirst({
    where: and(eq(installedApplets.chipId, chipId), eq(installedApplets.appletId, appletId)),
  });
}

export async function updateInstalledAppletStatus(
  id: number,
  status: "installing" | "active" | "updating" | "failed" | "uninstalled"
) {
  const db = await getDb();
  if (!db) return;

  await db.update(installedApplets).set({ status }).where(eq(installedApplets.id, id));
}

/**
 * DEPLOYMENT TRACKING
 */

export async function recordDeployment(
  deployment: InsertDeploymentHistory
): Promise<DeploymentHistory | null> {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(deploymentHistory).values(deployment);
  const deployId = result[0].insertId;
  return db.query.deploymentHistory.findFirst({
    where: eq(deploymentHistory.id, Number(deployId)),
  });
}

export async function getChipDeploymentHistory(chipId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return db.query.deploymentHistory.findMany({
    where: eq(deploymentHistory.chipId, chipId),
    limit,
    orderBy: desc(deploymentHistory.initiatedAt),
  });
}

export async function updateDeploymentStatus(
  deployId: number,
  status: "pending" | "in_progress" | "success" | "failed",
  errorMessage?: string
) {
  const db = await getDb();
  if (!db) return;

  const updates: Record<string, any> = {
    status,
    completedAt: new Date(),
  };

  if (errorMessage) {
    updates.errorMessage = errorMessage;
  }

  await db.update(deploymentHistory).set(updates).where(eq(deploymentHistory.id, deployId));
}

/**
 * EXECUTION LOGGING
 */

export async function logAppletExecution(data: any) {
  const db = await getDb();
  if (!db) return;

  await db.insert(appletExecutionLogs).values(data);
}

export async function getAppletExecutionLogs(chipId: number, appletId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];

  return db.query.appletExecutionLogs.findMany({
    where: and(
      eq(appletExecutionLogs.chipId, chipId),
      eq(appletExecutionLogs.appletId, appletId)
    ),
    limit,
    orderBy: desc(appletExecutionLogs.executedAt),
  });
}

/**
 * DEVELOPER MANAGEMENT
 */

export async function getDeveloperByUserId(userId: number) {
  const db = await getDb();
  if (!db) return null;

  return db.query.developers.findFirst({
    where: eq(developers.userId, userId),
  });
}

export async function createDeveloperProfile(userId: number, displayName: string) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(developers).values({
    userId,
    displayName,
  });

  const devId = result[0].insertId;
  return db.query.developers.findFirst({
    where: eq(developers.id, Number(devId)),
  });
}

/**
 * REVIEWS & RATINGS
 */

export async function getAppletReviews(appletId: number, limit: number = 20) {
  const db = await getDb();
  if (!db) return [];

  return db.query.appletReviews.findMany({
    where: eq(appletReviews.appletId, appletId),
    limit,
    orderBy: desc(appletReviews.createdAt),
  });
}

export async function addAppletReview(
  appletId: number,
  userId: number,
  rating: number,
  title: string,
  content: string
) {
  const db = await getDb();
  if (!db) return null;

  const result = await db.insert(appletReviews).values({
    appletId,
    userId,
    rating,
    title,
    content,
  });

  const reviewId = result[0].insertId;
  return db.query.appletReviews.findFirst({
    where: eq(appletReviews.id, Number(reviewId)),
  });
}
