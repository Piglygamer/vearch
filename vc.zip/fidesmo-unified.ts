import axios, { AxiosInstance } from "axios";
import crypto from "crypto";
import { getDb } from "./db";
import { implantApplets, applets } from "../drizzle/complete-schema";
import { eq } from "drizzle-orm";

/**
 * UNIFIED Fidesmo API Integration
 * Production-grade implementation with real authentication and bytecode handling
 * 
 * This is the ONLY Fidesmo client - replaces all previous implementations
 */

export interface FidesmoConfig {
  baseUrl: string; // https://api.fidesmo.com/v3
  username: string;
  password: string;
  callbackUrl: string; // Your webhook callback URL
  callbackSecret: string; // Secret for webhook signature verification
}

interface FidesmoToken {
  token: string;
  expiresIn: number;
}

interface ServiceDeliverySession {
  sessionId: string;
  cin: string; // Card Identification Number
  status: string;
}

interface DeploymentOperation {
  operationId: string;
  status: "pending" | "success" | "failure";
  timestamp: string;
  message?: string;
}

/**
 * Production Fidesmo Client
 * Handles all API communication with real Fidesmo backend
 */
export class FidesmoClient {
  private config: FidesmoConfig;
  private client: AxiosInstance;
  private token: FidesmoToken | null = null;
  private tokenExpiry: number = 0;

  constructor(config: FidesmoConfig) {
    this.config = config;

    // Initialize axios with proper headers
    this.client = axios.create({
      baseURL: config.baseUrl,
      timeout: 60000, // 60s timeout for large bytecode uploads
      headers: {
        "Content-Type": "application/json",
      },
    });

    // Add auth interceptor
    this.client.interceptors.request.use(
      async (config) => {
        const token = await this.getValidToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );
  }

  /**
   * Get or refresh authentication token
   */
  private async getValidToken(): Promise<string | null> {
    try {
      // Return existing token if still valid
      if (this.token && this.tokenExpiry > Date.now()) {
        return this.token.token;
      }

      console.log("[Fidesmo] Requesting new authentication token...");

      // Request new token using username/password
      const response = await axios.post(
        `${this.config.baseUrl}/token`,
        {
          username: this.config.username,
          password: this.config.password,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      this.token = {
        token: response.data.token,
        expiresIn: response.data.expiresIn,
      };

      // Set expiry to 1 minute before actual expiry for safety
      this.tokenExpiry = Date.now() + (response.data.expiresIn * 1000 - 60000);

      console.log("[Fidesmo] Authentication successful, token valid for", response.data.expiresIn, "seconds");

      return this.token.token;
    } catch (error) {
      console.error("[Fidesmo] Authentication failed:", error);
      throw new Error("Failed to authenticate with Fidesmo");
    }
  }

  /**
   * Start a service delivery session
   * This initiates communication with the chip
   */
  async startServiceDelivery(
    serviceId: string,
    cin: string
  ): Promise<ServiceDeliverySession> {
    try {
      console.log(`[Fidesmo] Starting service delivery: serviceId=${serviceId}, cin=${cin}`);

      const response = await this.client.post("/service-delivery/start", {
        serviceId,
        cin,
      });

      return {
        sessionId: response.data.sessionId,
        cin,
        status: "active",
      };
    } catch (error) {
      console.error("[Fidesmo] Failed to start service delivery:", error);
      throw error;
    }
  }

  /**
   * Upload applet bytecode to Fidesmo
   * Real bytecode upload, not simulated
   */
  async uploadAppletBytecode(
    appletAid: string,
    bytecode: Buffer,
    metadata?: { name: string; version: string }
  ): Promise<{ lfdbh: string; aid: string }> {
    try {
      console.log(`[Fidesmo] Uploading applet bytecode: ${appletAid}, size=${bytecode.length} bytes`);

      // Calculate Load File Data Block Hash
      const lfdbh = crypto.createHash("sha256").update(bytecode).digest("hex");

      // Upload bytecode to Fidesmo
      const response = await this.client.post(
        "/applet/load",
        {
          aid: appletAid,
          bytecode: bytecode.toString("base64"),
          metadata,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      console.log(`[Fidesmo] Bytecode uploaded successfully: LFDBH=${lfdbh}`);

      return {
        lfdbh,
        aid: appletAid,
      };
    } catch (error) {
      console.error("[Fidesmo] Bytecode upload failed:", error);
      throw error;
    }
  }

  /**
   * Install applet on chip via service delivery session
   */
  async installApplet(
    sessionId: string,
    appletAid: string,
    lfdbh: string,
    installParameters?: string
  ): Promise<DeploymentOperation> {
    try {
      console.log(`[Fidesmo] Installing applet: ${appletAid} on session ${sessionId}`);

      const response = await this.client.post(
        "/ccm/install",
        {
          aid: appletAid,
          module: appletAid,
          application: appletAid,
          lfdbh,
          selectable: true,
          encryptLoad: true,
          installParameters,
        },
        {
          headers: {
            sessionId,
            "X-Callback-Url": this.config.callbackUrl,
            "X-Callback-Secret": this.config.callbackSecret,
          },
        }
      );

      return {
        operationId: response.data.operationId,
        status: "pending",
        timestamp: new Date().toISOString(),
        message: "Installation in progress",
      };
    } catch (error) {
      console.error("[Fidesmo] Applet installation failed:", error);
      throw error;
    }
  }

  /**
   * Delete applet from chip
   */
  async deleteApplet(
    sessionId: string,
    appletAid: string
  ): Promise<DeploymentOperation> {
    try {
      console.log(`[Fidesmo] Deleting applet: ${appletAid} from session ${sessionId}`);

      const response = await this.client.post(
        "/ccm/delete",
        {
          aid: appletAid,
          withRelated: true,
        },
        {
          headers: {
            sessionId,
            "X-Callback-Url": this.config.callbackUrl,
          },
        }
      );

      return {
        operationId: response.data.operationId,
        status: "pending",
        timestamp: new Date().toISOString(),
        message: "Deletion in progress",
      };
    } catch (error) {
      console.error("[Fidesmo] Applet deletion failed:", error);
      throw error;
    }
  }

  /**
   * Complete service delivery session
   */
  async completeServiceDelivery(sessionId: string): Promise<boolean> {
    try {
      console.log(`[Fidesmo] Completing service delivery: ${sessionId}`);

      await this.client.post(`/service-delivery/${sessionId}/complete`);

      console.log(`[Fidesmo] Service delivery completed: ${sessionId}`);

      return true;
    } catch (error) {
      console.error("[Fidesmo] Failed to complete service delivery:", error);
      throw error;
    }
  }

  /**
   * Get operation status
   */
  async getOperationStatus(operationId: string): Promise<DeploymentOperation> {
    try {
      const response = await this.client.get(`/operations/${operationId}`);

      return {
        operationId,
        status: response.data.status,
        timestamp: response.data.timestamp,
        message: response.data.message,
      };
    } catch (error) {
      console.error("[Fidesmo] Failed to get operation status:", error);
      throw error;
    }
  }

  /**
   * Verify webhook callback signature
   * Called when Fidesmo sends deployment completion callback
   */
  verifyCallbackSignature(payload: string, signature: string): boolean {
    try {
      const expectedSignature = crypto
        .createHmac("sha256", this.config.callbackSecret)
        .update(payload)
        .digest("hex");

      return expectedSignature === signature;
    } catch (error) {
      console.error("[Fidesmo] Signature verification failed:", error);
      return false;
    }
  }
}

/**
 * High-level Fidesmo Service Manager
 * Orchestrates complete applet deployment workflows
 */
export class FidesmoServiceManager {
  private client: FidesmoClient;
  private config: FidesmoConfig;

  constructor(config: FidesmoConfig) {
    this.config = config;
    this.client = new FidesmoClient(config);
  }

  /**
   * Deploy payment applet to chip (complete workflow)
   */
  async deployPaymentApplet(
    userId: number,
    implantId: number,
    cin: string,
    appletAid: string,
    bytecode: Buffer,
    installParameters?: string
  ): Promise<{ deploymentId: string; status: string }> {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    try {
      console.log(`[Fidesmo] Starting payment applet deployment for user ${userId}, implant ${implantId}`);

      // Step 1: Start service delivery session
      const session = await this.client.startServiceDelivery(
        process.env.FIDESMO_SERVICE_ID || "vearch-payment",
        cin
      );

      // Step 2: Upload bytecode
      const { lfdbh } = await this.client.uploadAppletBytecode(appletAid, bytecode);

      // Step 3: Install applet on chip
      const operation = await this.client.installApplet(
        session.sessionId,
        appletAid,
        lfdbh,
        installParameters
      );

      // Step 4: Record deployment in database
      const result = await db.insert(implantApplets).values({
        implantId,
        appletId: 1, // Reference to applet in database
        status: "pending",
        deploymentId: operation.operationId,
      });

      // Step 5: Complete service delivery session
      await this.client.completeServiceDelivery(session.sessionId);

      console.log(`[Fidesmo] Deployment initiated: ${operation.operationId}`);

      return {
        deploymentId: operation.operationId,
        status: operation.status,
      };
    } catch (error) {
      console.error("[Fidesmo] Deployment failed:", error);
      throw error;
    }
  }

  /**
   * Handle Fidesmo webhook callback
   * Called when deployment completes (success or failure)
   */
  async handleDeploymentCallback(
    operationId: string,
    status: "success" | "failure",
    message?: string
  ): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    try {
      console.log(`[Fidesmo] Handling callback: operationId=${operationId}, status=${status}`);

      // Update deployment status in database
      await db
        .update(implantApplets)
        .set({
          status: status === "success" ? "installed" : "failed",
          installedAt: status === "success" ? new Date() : null,
        })
        .where(eq(implantApplets.deploymentId, operationId));

      console.log(`[Fidesmo] Deployment status updated: ${operationId} → ${status}`);
    } catch (error) {
      console.error("[Fidesmo] Callback handling failed:", error);
      throw error;
    }
  }

  /**
   * Retry failed deployment
   * Implements exponential backoff
   */
  async retryDeployment(
    deploymentId: string,
    retryCount: number = 0,
    maxRetries: number = 3
  ): Promise<boolean> {
    try {
      if (retryCount >= maxRetries) {
        console.error(`[Fidesmo] Max retries exceeded for deployment ${deploymentId}`);
        return false;
      }

      // Exponential backoff: 2s, 4s, 8s
      const delayMs = Math.pow(2, retryCount + 1) * 1000;
      console.log(`[Fidesmo] Retrying deployment ${deploymentId} after ${delayMs}ms (attempt ${retryCount + 1})`);

      await new Promise((resolve) => setTimeout(resolve, delayMs));

      const operation = await this.client.getOperationStatus(deploymentId);

      if (operation.status === "success") {
        console.log(`[Fidesmo] Deployment succeeded: ${deploymentId}`);
        return true;
      } else if (operation.status === "failure") {
        console.error(`[Fidesmo] Deployment failed: ${deploymentId} - ${operation.message}`);
        return false;
      } else {
        // Still pending, retry
        return this.retryDeployment(deploymentId, retryCount + 1, maxRetries);
      }
    } catch (error) {
      console.error("[Fidesmo] Retry failed:", error);
      if (retryCount < maxRetries) {
        return this.retryDeployment(deploymentId, retryCount + 1, maxRetries);
      }
      return false;
    }
  }
}

/**
 * Export singleton factory
 */
export function createFidesmoClient(config: FidesmoConfig): FidesmoClient {
  return new FidesmoClient(config);
}

export function createFidesmoServiceManager(config: FidesmoConfig): FidesmoServiceManager {
  return new FidesmoServiceManager(config);
}
