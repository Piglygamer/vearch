import Stripe from "stripe";
import { getDb } from "./db";
import { transactions, paymentMethods, implants, users } from "../drizzle/complete-schema";
import { eq } from "drizzle-orm";

/**
 * Stripe Payment Service
 * Handles real off-session payment processing for implant tap-to-pay
 * 
 * Payment flow:
 * 1. User links card via SetupIntent (card never touches Vearch)
 * 2. Merchant POSTs UID + amount to /api/merchant/charge
 * 3. Vearch resolves UID → user → payment method
 * 4. Creates PaymentIntent with off_session=true
 * 5. Charges cardholder's saved card
 * 6. Transfers funds to merchant's Stripe Connect account
 */

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2024-12-18",
});

interface ChargeRequest {
  userId: number;
  implantId: number;
  merchantId: number;
  amountCents: number;
  currency: string;
  idempotencyKey: string;
}

interface ChargeResponse {
  transactionId: number;
  status: string;
  chargeId: string;
  amount: number;
  currency: string;
  timestamp: string;
}

/**
 * Production Stripe Payment Service
 */
export class StripePaymentService {
  /**
   * Process off-session payment from implant
   * 
   * This is the core payment flow:
   * - Cardholder taps implant at merchant terminal
   * - Terminal POSTs UID + amount to Vearch
   * - Vearch charges the cardholder's saved card
   * - Funds go to merchant's Stripe Connect account
   */
  async chargeByImplantUid(request: ChargeRequest): Promise<ChargeResponse> {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    try {
      // Step 1: Get user's default payment method
      const paymentMethod = await db
        .select()
        .from(paymentMethods)
        .where(eq(paymentMethods.userId, request.userId))
        .limit(1);

      if (!paymentMethod[0]) {
        throw new Error("No payment method found for user");
      }

      // Step 2: Get merchant's Stripe Connect account
      // In production, this would be stored in the merchants table
      const merchantStripeAccountId = `acct_merchant_${request.merchantId}`;

      // Step 3: Create PaymentIntent with off-session charging
      // off_session=true means we're charging a saved card without user interaction
      // confirm=true means we immediately process the charge
      const paymentIntent = await stripe.paymentIntents.create(
        {
          amount: request.amountCents,
          currency: request.currency,
          payment_method: paymentMethod[0].stripePaymentMethodId,
          customer: paymentMethod[0].stripeCustomerId,
          off_session: true, // Charging a saved card
          confirm: true, // Immediately process
          transfer_data: {
            destination: merchantStripeAccountId,
          },
          metadata: {
            userId: request.userId.toString(),
            implantId: request.implantId.toString(),
            merchantId: request.merchantId.toString(),
            type: "implant_tap_to_pay",
          },
        },
        {
          idempotencyKey: request.idempotencyKey,
        }
      );

      // Step 4: Record transaction in database
      const result = await db.insert(transactions).values({
        userId: request.userId,
        implantId: request.implantId,
        merchantId: request.merchantId,
        amountCents: request.amountCents,
        currency: request.currency,
        status: paymentIntent.status === "succeeded" ? "completed" : "pending",
        stripePaymentIntentId: paymentIntent.id,
      });

      console.log(`[Stripe] Payment processed: ${paymentIntent.id}, status=${paymentIntent.status}`);

      return {
        transactionId: result.insertId as number,
        status: paymentIntent.status,
        chargeId: paymentIntent.id,
        amount: paymentIntent.amount,
        currency: paymentIntent.currency,
        timestamp: new Date().toISOString(),
      };
    } catch (error) {
      console.error("[Stripe] Payment processing failed:", error);
      throw error;
    }
  }

  /**
   * Create SetupIntent for card linking
   * User adds card via Stripe Elements (card never touches Vearch)
   */
  async createSetupIntent(userId: number): Promise<{ clientSecret: string }> {
    try {
      // Get or create Stripe customer
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const user = await db.select().from(users).where(eq(users.id, userId)).limit(1);

      if (!user[0]) {
        throw new Error("User not found");
      }

      let stripeCustomerId = user[0].stripeCustomerId;

      if (!stripeCustomerId) {
        // Create new Stripe customer
        const customer = await stripe.customers.create({
          email: user[0].email,
          metadata: {
            userId: userId.toString(),
          },
        });

        stripeCustomerId = customer.id;

        // Update user with Stripe customer ID
        await db
          .update(users)
          .set({ stripeCustomerId })
          .where(eq(users.id, userId));
      }

      // Create SetupIntent
      const setupIntent = await stripe.setupIntents.create({
        customer: stripeCustomerId,
        payment_method_types: ["card"],
        usage: "off_session", // For off-session charging
      });

      console.log(`[Stripe] SetupIntent created: ${setupIntent.id}`);

      return {
        clientSecret: setupIntent.client_secret || "",
      };
    } catch (error) {
      console.error("[Stripe] SetupIntent creation failed:", error);
      throw error;
    }
  }

  /**
   * Handle Stripe webhook events
   * Updates transaction status when payment succeeds/fails
   */
  async handleWebhookEvent(event: Stripe.Event): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    try {
      switch (event.type) {
        case "payment_intent.succeeded":
          const piSucceeded = event.data.object as Stripe.PaymentIntent;
          console.log(`[Stripe] Payment succeeded: ${piSucceeded.id}`);

          await db
            .update(transactions)
            .set({ status: "completed" })
            .where(eq(transactions.stripePaymentIntentId, piSucceeded.id));

          break;

        case "payment_intent.payment_failed":
          const piFailed = event.data.object as Stripe.PaymentIntent;
          console.log(`[Stripe] Payment failed: ${piFailed.id}`);

          await db
            .update(transactions)
            .set({ status: "failed" })
            .where(eq(transactions.stripePaymentIntentId, piFailed.id));

          break;

        case "charge.refunded":
          const chargeRefunded = event.data.object as Stripe.Charge;
          console.log(`[Stripe] Charge refunded: ${chargeRefunded.id}`);

          if (chargeRefunded.payment_intent) {
            await db
              .update(transactions)
              .set({ status: "refunded" })
              .where(eq(transactions.stripePaymentIntentId, chargeRefunded.payment_intent as string));
          }

          break;

        case "setup_intent.succeeded":
          const siSucceeded = event.data.object as Stripe.SetupIntent;
          console.log(`[Stripe] SetupIntent succeeded: ${siSucceeded.id}`);

          // Payment method is now ready for off-session use
          if (siSucceeded.payment_method) {
            const paymentMethod = await stripe.paymentMethods.retrieve(
              siSucceeded.payment_method as string
            );

            // Store payment method in database
            if (siSucceeded.customer) {
              const customerId = siSucceeded.customer as string;
              const customer = await stripe.customers.retrieve(customerId);

              const userId = parseInt(customer.metadata?.userId || "0");

              if (userId > 0) {
                await db.insert(paymentMethods).values({
                  userId,
                  stripeCustomerId: customerId,
                  stripePaymentMethodId: paymentMethod.id,
                  type: "card",
                  brand: paymentMethod.card?.brand || "unknown",
                  last4: paymentMethod.card?.last4 || "0000",
                  isDefault: true,
                });

                console.log(`[Stripe] Payment method stored for user ${userId}`);
              }
            }
          }

          break;

        default:
          console.log(`[Stripe] Unhandled event type: ${event.type}`);
      }
    } catch (error) {
      console.error("[Stripe] Webhook handling failed:", error);
      throw error;
    }
  }

  /**
   * Verify Stripe webhook signature
   */
  verifyWebhookSignature(body: string, signature: string): Stripe.Event | null {
    try {
      const event = stripe.webhooks.constructEvent(
        body,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET || ""
      );

      return event;
    } catch (error) {
      console.error("[Stripe] Webhook signature verification failed:", error);
      return null;
    }
  }
}

export default new StripePaymentService();
