import React, { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";

/**
 * Real Chip Comparison Page
 * Comprehensive comparison of all biohacking chips
 * 
 * Features:
 * - Search and filter chips
 * - Side-by-side comparison
 * - Detailed specifications
 * - Capability matrix
 * - Pricing comparison
 * - Compatibility matrix
 */

interface ChipFilter {
  search: string;
  status: "all" | "active" | "discontinued" | "prototype";
  paymentCapable: boolean;
  minPrice: number;
  maxPrice: number;
}

export default function ChipComparison() {
  const [filters, setFilters] = useState<ChipFilter>({
    search: "",
    status: "all",
    paymentCapable: false,
    minPrice: 0,
    maxPrice: 500,
  });

  const [selectedChips, setSelectedChips] = useState<string[]>([]);

  // Get all chips from server
  const { data: allChips = [] } = trpc.chips.list.useQuery();

  // Filter chips
  const filteredChips = useMemo(() => {
    return allChips.filter((chip: any) => {
      // Search filter
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        const matches =
          chip.name.toLowerCase().includes(searchLower) ||
          chip.manufacturer.toLowerCase().includes(searchLower) ||
          chip.type.toLowerCase().includes(searchLower);

        if (!matches) return false;
      }

      // Status filter
      if (filters.status !== "all" && chip.status !== filters.status) {
        return false;
      }

      // Payment capability filter
      if (filters.paymentCapable && !chip.paymentCapable) {
        return false;
      }

      // Price filter
      if (chip.price < filters.minPrice || chip.price > filters.maxPrice) {
        return false;
      }

      return true;
    });
  }, [allChips, filters]);

  /**
   * Get status badge color
   */
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500";
      case "discontinued":
        return "bg-red-500";
      case "prototype":
        return "bg-yellow-500";
      case "experimental":
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  /**
   * Toggle chip selection for comparison
   */
  const toggleChipSelection = (chipId: string) => {
    setSelectedChips((prev) =>
      prev.includes(chipId) ? prev.filter((id) => id !== chipId) : [...prev, chipId]
    );
  };

  /**
   * Get selected chip objects
   */
  const comparisonChips = useMemo(() => {
    return allChips.filter((chip: any) => selectedChips.includes(chip.id));
  }, [allChips, selectedChips]);

  /**
   * Get all unique capabilities
   */
  const allCapabilities = useMemo(() => {
    const capabilities = new Set<string>();
    comparisonChips.forEach((chip: any) => {
      chip.capabilities.forEach((cap: string) => capabilities.add(cap));
    });
    return Array.from(capabilities).sort();
  }, [comparisonChips]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Chip Comparison</h1>
          <p className="text-slate-400">Compare all biohacking chips side-by-side</p>
        </div>

        {/* Filters */}
        <Card className="bg-slate-800 border-slate-700 p-6 mb-6">
          <h2 className="text-lg font-semibold text-white mb-4">Filters</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Search */}
            <div>
              <label className="block text-sm text-slate-300 mb-2">Search</label>
              <Input
                placeholder="Chip name, type..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white"
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm text-slate-300 mb-2">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value as any })}
                className="w-full bg-slate-700 border border-slate-600 text-white px-3 py-2 rounded-md"
              >
                <option value="all">All</option>
                <option value="active">Active</option>
                <option value="discontinued">Discontinued</option>
                <option value="prototype">Prototype</option>
              </select>
            </div>

            {/* Payment Capable */}
            <div className="flex items-end">
              <label className="flex items-center text-slate-300">
                <input
                  type="checkbox"
                  checked={filters.paymentCapable}
                  onChange={(e) => setFilters({ ...filters, paymentCapable: e.target.checked })}
                  className="mr-2"
                />
                Payment Capable
              </label>
            </div>

            {/* Price Range */}
            <div>
              <label className="block text-sm text-slate-300 mb-2">
                Price: ${filters.minPrice} - ${filters.maxPrice}
              </label>
              <input
                type="range"
                min="0"
                max="500"
                value={filters.maxPrice}
                onChange={(e) => setFilters({ ...filters, maxPrice: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>
          </div>

          {/* Results count */}
          <p className="text-sm text-slate-400 mt-4">
            Showing {filteredChips.length} of {allChips.length} chips
          </p>
        </Card>

        {/* Chip Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {filteredChips.map((chip: any) => (
            <Card
              key={chip.id}
              className={`bg-slate-800 border-2 p-4 cursor-pointer transition-all ${
                selectedChips.includes(chip.id)
                  ? "border-blue-500 ring-2 ring-blue-500"
                  : "border-slate-700 hover:border-slate-600"
              }`}
              onClick={() => toggleChipSelection(chip.id)}
            >
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-lg font-semibold text-white">{chip.name}</h3>
                  <p className="text-sm text-slate-400">{chip.manufacturer}</p>
                </div>
                <Badge className={`${getStatusColor(chip.status)} text-white`}>
                  {chip.status}
                </Badge>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Type:</span>
                  <span className="text-white">{chip.type}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Memory:</span>
                  <span className="text-white">{chip.memorySize}B</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Price:</span>
                  <span className="text-white font-semibold">${chip.price}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Success Rate:</span>
                  <span className="text-white">{chip.successRate}%</span>
                </div>
              </div>

              {/* Capabilities */}
              <div className="flex flex-wrap gap-1">
                {chip.capabilities.slice(0, 3).map((cap: string) => (
                  <Badge key={cap} variant="outline" className="text-xs">
                    {cap}
                  </Badge>
                ))}
                {chip.capabilities.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{chip.capabilities.length - 3}
                  </Badge>
                )}
              </div>
            </Card>
          ))}
        </div>

        {/* Comparison Table */}
        {comparisonChips.length > 0 && (
          <Card className="bg-slate-800 border-slate-700 p-6 overflow-x-auto">
            <h2 className="text-xl font-semibold text-white mb-4">
              Comparison ({comparisonChips.length} chips)
            </h2>

            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-700">
                  <th className="text-left py-2 px-2 text-slate-300">Property</th>
                  {comparisonChips.map((chip: any) => (
                    <th key={chip.id} className="text-left py-2 px-2 text-white">
                      {chip.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {/* Manufacturer */}
                <tr className="border-b border-slate-700">
                  <td className="py-2 px-2 text-slate-400">Manufacturer</td>
                  {comparisonChips.map((chip: any) => (
                    <td key={chip.id} className="py-2 px-2 text-white">
                      {chip.manufacturer}
                    </td>
                  ))}
                </tr>

                {/* Type */}
                <tr className="border-b border-slate-700">
                  <td className="py-2 px-2 text-slate-400">Type</td>
                  {comparisonChips.map((chip: any) => (
                    <td key={chip.id} className="py-2 px-2 text-white">
                      {chip.type}
                    </td>
                  ))}
                </tr>

                {/* Memory */}
                <tr className="border-b border-slate-700">
                  <td className="py-2 px-2 text-slate-400">Memory</td>
                  {comparisonChips.map((chip: any) => (
                    <td key={chip.id} className="py-2 px-2 text-white">
                      {chip.memorySize}B
                    </td>
                  ))}
                </tr>

                {/* Price */}
                <tr className="border-b border-slate-700">
                  <td className="py-2 px-2 text-slate-400">Price</td>
                  {comparisonChips.map((chip: any) => (
                    <td key={chip.id} className="py-2 px-2 text-white font-semibold">
                      ${chip.price}
                    </td>
                  ))}
                </tr>

                {/* Success Rate */}
                <tr className="border-b border-slate-700">
                  <td className="py-2 px-2 text-slate-400">Success Rate</td>
                  {comparisonChips.map((chip: any) => (
                    <td key={chip.id} className="py-2 px-2 text-white">
                      {chip.successRate}%
                    </td>
                  ))}
                </tr>

                {/* Payment Capable */}
                <tr className="border-b border-slate-700">
                  <td className="py-2 px-2 text-slate-400">Payment</td>
                  {comparisonChips.map((chip: any) => (
                    <td key={chip.id} className="py-2 px-2">
                      {chip.paymentCapable ? (
                        <Badge className="bg-green-500">Yes</Badge>
                      ) : (
                        <Badge variant="outline">No</Badge>
                      )}
                    </td>
                  ))}
                </tr>

                {/* Capabilities */}
                {allCapabilities.map((capability) => (
                  <tr key={capability} className="border-b border-slate-700">
                    <td className="py-2 px-2 text-slate-400">{capability}</td>
                    {comparisonChips.map((chip: any) => (
                      <td key={chip.id} className="py-2 px-2">
                        {chip.capabilities.includes(capability) ? (
                          <span className="text-green-400">✓</span>
                        ) : (
                          <span className="text-slate-600">-</span>
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Clear Selection */}
            <Button
              onClick={() => setSelectedChips([])}
              variant="outline"
              className="mt-4"
            >
              Clear Selection
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
