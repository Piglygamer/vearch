import { router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { FidesmoPaymentService, PaymentProcessingService } from "./fidesmo-payment-service";
import { getDb } from "./db";
import { implants, merchants } from "../drizzle/complete-schema";
import { eq } from "drizzle-orm";

// Initialize services
const fidesmoConfig = {
  apiUrl: process.env.FIDESMO_API_URL || "https://api.fidesmo.com",
  apiKey: process.env.FIDESMO_API_KEY || "",
  serviceId: process.env.FIDESMO_SERVICE_ID || "",
};

const fidesmoService = new FidesmoPaymentService(fidesmoConfig);
const paymentService = new PaymentProcessingService();

/**
 * Payment procedures for real tap-to-pay functionality
 */
export const paymentProcedures = router({
  /**
   * Deploy payment applet to chip via Fidesmo
   */
  deployPaymentApplet: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        appletId: z.number(),
        paymentMethodId: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const result = await fidesmoService.deployPaymentApplet({
          implantId: input.implantId,
          userId: ctx.user.id,
          appletId: input.appletId,
          paymentMethodId: input.paymentMethodId,
        });

        return {
          success: true,
          deploymentId: result.deploymentId,
          status: result.status,
        };
      } catch (error) {
        console.error("[Payment] Deployment failed:", error);
        throw new Error("Failed to deploy payment applet");
      }
    }),

  /**
   * Check deployment status
   */
  checkDeploymentStatus: protectedProcedure
    .input(z.object({ deploymentId: z.string() }))
    .query(async ({ input }) => {
      try {
        const status = await fidesmoService.checkDeploymentStatus(input.deploymentId);
        return { status };
      } catch (error) {
        console.error("[Payment] Status check failed:", error);
        throw new Error("Failed to check deployment status");
      }
    }),

  /**
   * Process tap-to-pay transaction
   * This is called when user taps their chip at a merchant terminal
   */
  processTransaction: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        merchantId: z.number(),
        amountCents: z.number(),
        currency: z.string().default("usd"),
        chipSignature: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        // Verify chip authenticity
        const isValid = await paymentService.verifyChipSignature(
          `implant-${input.implantId}`,
          input.chipSignature
        );

        if (!isValid) {
          throw new Error("Invalid chip signature");
        }

        // Check for fraud
        const isSafe = await paymentService.checkFraudPatterns(
          ctx.user.id,
          input.merchantId,
          input.amountCents
        );

        if (!isSafe) {
          throw new Error("Transaction flagged as potential fraud");
        }

        // Verify implant belongs to user
        const implant = await db
          .select()
          .from(implants)
          .where(eq(implants.id, input.implantId))
          .limit(1);

        if (!implant[0] || implant[0].userId !== ctx.user.id) {
          throw new Error("Implant not found or not authorized");
        }

        // Process payment
        const result = await paymentService.processImplantPayment(
          ctx.user.id,
          input.implantId,
          input.merchantId,
          input.amountCents,
          input.currency
        );

        return {
          success: true,
          transactionId: result.transactionId,
          status: result.status,
          amount: input.amountCents,
          currency: input.currency,
        };
      } catch (error) {
        console.error("[Payment] Transaction processing failed:", error);
        throw error;
      }
    }),

  /**
   * Get available merchants for tap-to-pay
   */
  getMerchants: protectedProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];

    try {
      return await db.select().from(merchants);
    } catch (error) {
      console.error("[Payment] Failed to get merchants:", error);
      return [];
    }
  }),

  /**
   * Handle Fidesmo webhook callback
   */
  handleFidesmoCallback: protectedProcedure
    .input(
      z.object({
        deploymentId: z.string(),
        status: z.string(),
        implantId: z.number(),
        timestamp: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        await fidesmoService.handleDeploymentCallback(input);
        return { success: true };
      } catch (error) {
        console.error("[Payment] Callback handling failed:", error);
        throw error;
      }
    }),
});

export type PaymentProcedures = typeof paymentProcedures;
