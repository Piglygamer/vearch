import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { createFidesmoServiceManager, FidesmoConfig } from "./fidesmo-integration";
import { logOperation } from "./user-account-db";
import { ENV } from "./_core/env";

/**
 * Fidesmo Applet Deployment Router
 * Complete end-to-end applet deployment with full lifecycle management
 */

// Initialize Fidesmo service manager
const fidesmoConfig: FidesmoConfig = {
  baseUrl: process.env.FIDESMO_API_URL || "https://api.fidesmo.com/v3",
  username: process.env.FIDESMO_USERNAME || "",
  password: process.env.FIDESMO_PASSWORD || "",
  callbackUrl: process.env.FIDESMO_CALLBACK_URL || "https://your-domain.com/api/fidesmo/callback",
};

const fidesmoManager = createFidesmoServiceManager(fidesmoConfig);

// Track ongoing deployments
const deploymentStatus: Map<
  string,
  {
    operationId: string;
    chipId: number;
    userId: number;
    appletAid: string;
    status: "pending" | "success" | "failed";
    progress: number;
    error?: string;
    startedAt: Date;
  }
> = new Map();

export const fidesmoRouter = router({
  /**
   * Deploy applet to chip
   */
  deployApplet: protectedProcedure
    .input(
      z.object({
        chipId: z.number(),
        appletAid: z.string(),
        bytecodeUrl: z.string(),
        installParameters: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        console.log(`[ROUTER] Deploying applet ${input.appletAid} to chip ${input.chipId}`);

        // Validate user owns the chip
        const { getUserChipById } = await import("./user-account-db");
        const userChip = await getUserChipById(ctx.user.id, input.chipId);

        if (!userChip) {
          throw new Error("Chip not found or not owned by user");
        }

        // Download bytecode
        let bytecode: Buffer;
        try {
          const response = await fetch(input.bytecodeUrl);
          if (!response.ok) {
            throw new Error(`Failed to download bytecode: ${response.statusText}`);
          }
          bytecode = Buffer.from(await response.arrayBuffer());
        } catch (error) {
          console.error("[ROUTER] Bytecode download failed:", error);
          throw new Error("Failed to download applet bytecode");
        }

        // Start deployment
        const { sessionId, operationId } = await fidesmoManager.deployApplet(
          userChip.uid, // CIN (Card Identification Number)
          process.env.FIDESMO_SERVICE_ID || "default-service",
          input.appletAid,
          bytecode,
          input.installParameters
        );

        // Track deployment
        deploymentStatus.set(operationId, {
          operationId,
          chipId: input.chipId,
          userId: ctx.user.id,
          appletAid: input.appletAid,
          status: "pending",
          progress: 25,
          startedAt: new Date(),
        });

        // Log operation
        await logOperation({
          userId: ctx.user.id,
          chipId: input.chipId,
          operationType: "applet_install",
          operationDetails: {
            appletAid: input.appletAid,
            operationId,
            sessionId,
          },
          success: false, // Will update on callback
        });

        // Register callback handler
        fidesmoManager.onOperationComplete(operationId, async (result) => {
          const deployment = deploymentStatus.get(operationId);
          if (!deployment) return;

          if (result.status === "success") {
            deployment.status = "success";
            deployment.progress = 100;
            console.log(`[FIDESMO] Applet deployment successful: ${operationId}`);

            // Update installed applets
            const { db } = await import("./db");
            const database = await db();
            if (database) {
              // Record installed applet
              console.log(`[FIDESMO] Recording installed applet: ${input.appletAid}`);
            }
          } else {
            deployment.status = "failed";
            deployment.error = result.message || "Deployment failed";
            console.error(`[FIDESMO] Applet deployment failed: ${operationId}`);
          }
        });

        return {
          success: true,
          operationId,
          sessionId,
          status: "pending",
          message: "Applet deployment initiated",
        };
      } catch (error) {
        console.error("[ROUTER] Deploy applet failed:", error);
        throw error;
      }
    }),

  /**
   * Get deployment status
   */
  getDeploymentStatus: protectedProcedure
    .input(z.object({ operationId: z.string() }))
    .query(async ({ input, ctx }) => {
      try {
        const deployment = deploymentStatus.get(input.operationId);

        if (!deployment) {
          throw new Error("Deployment not found");
        }

        // Verify user owns this deployment
        if (deployment.userId !== ctx.user.id) {
          throw new Error("Unauthorized");
        }

        return {
          operationId: deployment.operationId,
          status: deployment.status,
          progress: deployment.progress,
          appletAid: deployment.appletAid,
          error: deployment.error,
          startedAt: deployment.startedAt,
          elapsedSeconds: Math.floor(
            (Date.now() - deployment.startedAt.getTime()) / 1000
          ),
        };
      } catch (error) {
        console.error("[ROUTER] Get deployment status failed:", error);
        throw error;
      }
    }),

  /**
   * Uninstall applet from chip
   */
  uninstallApplet: protectedProcedure
    .input(
      z.object({
        chipId: z.number(),
        appletAid: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        console.log(`[ROUTER] Uninstalling applet ${input.appletAid} from chip ${input.chipId}`);

        const { getUserChipById } = await import("./user-account-db");
        const userChip = await getUserChipById(ctx.user.id, input.chipId);

        if (!userChip) {
          throw new Error("Chip not found or not owned by user");
        }

        // Start uninstallation
        const { sessionId, operationId } = await fidesmoManager.uninstallApplet(
          userChip.uid,
          process.env.FIDESMO_SERVICE_ID || "default-service",
          input.appletAid
        );

        // Track operation
        deploymentStatus.set(operationId, {
          operationId,
          chipId: input.chipId,
          userId: ctx.user.id,
          appletAid: input.appletAid,
          status: "pending",
          progress: 25,
          startedAt: new Date(),
        });

        // Log operation
        await logOperation({
          userId: ctx.user.id,
          chipId: input.chipId,
          operationType: "applet_uninstall",
          operationDetails: {
            appletAid: input.appletAid,
            operationId,
            sessionId,
          },
          success: false,
        });

        return {
          success: true,
          operationId,
          sessionId,
          status: "pending",
          message: "Applet uninstallation initiated",
        };
      } catch (error) {
        console.error("[ROUTER] Uninstall applet failed:", error);
        throw error;
      }
    }),

  /**
   * Get available applets
   */
  getAvailableApplets: protectedProcedure.query(async () => {
    try {
      // Return available applets from registry
      return [
        {
          aid: "A0000000041010",
          name: "Vearch Payment",
          version: "1.0.0",
          description: "EMV payment applet for contactless payments",
          size: 8192,
          permissions: ["PAYMENT", "CRYPTO"],
          bytecodeUrl: "/api/applets/vearch-payment/bytecode",
        },
        {
          aid: "A0000000042010",
          name: "Vearch Identity",
          version: "1.0.0",
          description: "Decentralized identity credentials",
          size: 4096,
          permissions: ["IDENTITY", "CRYPTO"],
          bytecodeUrl: "/api/applets/vearch-identity/bytecode",
        },
        {
          aid: "A0000000043010",
          name: "Vearch Access",
          version: "1.0.0",
          description: "Physical and digital access control",
          size: 6144,
          permissions: ["ACCESS", "CRYPTO"],
          bytecodeUrl: "/api/applets/vearch-access/bytecode",
        },
      ];
    } catch (error) {
      console.error("[ROUTER] Get available applets failed:", error);
      throw error;
    }
  }),

  /**
   * Handle Fidesmo callback
   */
  handleCallback: protectedProcedure
    .input(
      z.object({
        operationId: z.string(),
        status: z.enum(["success", "failure"]),
        statusCode: z.number(),
        message: z.string().optional(),
        data: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        console.log(`[ROUTER] Handling Fidesmo callback: ${input.operationId}`);

        fidesmoManager.handleCallback(input.operationId, {
          operationId: input.operationId,
          status: input.status,
          statusCode: input.statusCode,
          message: input.message,
          data: input.data,
        });

        return { success: true };
      } catch (error) {
        console.error("[ROUTER] Handle callback failed:", error);
        throw error;
      }
    }),

  /**
   * Get deployment history
   */
  getDeploymentHistory: protectedProcedure
    .input(z.object({ chipId: z.number().optional(), limit: z.number().default(50) }))
    .query(async ({ input, ctx }) => {
      try {
        const { getChipOperationLogs } = await import("./user-account-db");

        if (input.chipId) {
          const logs = await getChipOperationLogs(input.chipId, input.limit);
          return logs.filter((log) => log.operationType.includes("applet"));
        }

        const { getUserOperationLogs } = await import("./user-account-db");
        const logs = await getUserOperationLogs(ctx.user.id, input.limit);
        return logs.filter((log) => log.operationType.includes("applet"));
      } catch (error) {
        console.error("[ROUTER] Get deployment history failed:", error);
        throw error;
      }
    }),

  /**
   * Retry failed deployment
   */
  retryDeployment: protectedProcedure
    .input(
      z.object({
        operationId: z.string(),
        chipId: z.number(),
        appletAid: z.string(),
        bytecodeUrl: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        console.log(`[ROUTER] Retrying deployment: ${input.operationId}`);

        const deployment = deploymentStatus.get(input.operationId);

        if (!deployment) {
          throw new Error("Original deployment not found");
        }

        if (deployment.userId !== ctx.user.id) {
          throw new Error("Unauthorized");
        }

        // Remove old deployment
        deploymentStatus.delete(input.operationId);

        // Retry deployment
        const result = await this.createCaller(ctx).deployApplet({
          chipId: input.chipId,
          appletAid: input.appletAid,
          bytecodeUrl: input.bytecodeUrl,
        });

        return result;
      } catch (error) {
        console.error("[ROUTER] Retry deployment failed:", error);
        throw error;
      }
    }),
});
