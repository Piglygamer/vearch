import { eq, and } from "drizzle-orm";
import {
  userAccounts,
  userChips,
  chipBackups,
  installedApplets,
  paymentMethods,
  operationLogs,
  userPreferences,
  transactions,
  UserAccount,
  InsertUserAccount,
  UserChip,
  InsertUserChip,
  ChipBackup,
  InsertChipBackup,
  OperationLog,
  InsertOperationLog,
} from "../drizzle/user-chip-schema";
import { getDb } from "./db";

/**
 * User Account Database Helpers
 */

// ==========================================
// USER ACCOUNT OPERATIONS
// ==========================================

export async function createUserAccount(user: InsertUserAccount): Promise<UserAccount | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db.insert(userAccounts).values(user);
    console.log(`[DB] User account created: ${user.email}`);

    return {
      ...user,
      id: result[0].insertId as number,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as UserAccount;
  } catch (error) {
    console.error("[DB] Create user account failed:", error);
    return null;
  }
}

export async function getUserByOpenId(openId: string): Promise<UserAccount | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(userAccounts)
      .where(eq(userAccounts.openId, openId))
      .limit(1);

    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[DB] Get user by openId failed:", error);
    return null;
  }
}

export async function getUserById(id: number): Promise<UserAccount | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(userAccounts)
      .where(eq(userAccounts.id, id))
      .limit(1);

    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[DB] Get user by id failed:", error);
    return null;
  }
}

export async function updateUserAccount(id: number, updates: Partial<UserAccount>): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db.update(userAccounts).set(updates).where(eq(userAccounts.id, id));
    console.log(`[DB] User account updated: ${id}`);

    return true;
  } catch (error) {
    console.error("[DB] Update user account failed:", error);
    return false;
  }
}

// ==========================================
// USER CHIP OPERATIONS
// ==========================================

export async function addUserChip(chip: InsertUserChip): Promise<UserChip | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db.insert(userChips).values(chip);
    console.log(`[DB] User chip added: ${chip.uid}`);

    return {
      ...chip,
      id: result[0].insertId as number,
      createdAt: new Date(),
      updatedAt: new Date(),
    } as UserChip;
  } catch (error) {
    console.error("[DB] Add user chip failed:", error);
    return null;
  }
}

export async function getUserChips(userId: number): Promise<UserChip[]> {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select()
      .from(userChips)
      .where(eq(userChips.userId, userId));

    return result;
  } catch (error) {
    console.error("[DB] Get user chips failed:", error);
    return [];
  }
}

export async function getUserChipById(userId: number, chipId: number): Promise<UserChip | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(userChips)
      .where(and(eq(userChips.userId, userId), eq(userChips.id, chipId)))
      .limit(1);

    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[DB] Get user chip by id failed:", error);
    return null;
  }
}

export async function updateUserChip(chipId: number, updates: Partial<UserChip>): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db.update(userChips).set(updates).where(eq(userChips.id, chipId));
    console.log(`[DB] User chip updated: ${chipId}`);

    return true;
  } catch (error) {
    console.error("[DB] Update user chip failed:", error);
    return false;
  }
}

export async function deleteUserChip(userId: number, chipId: number): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db
      .delete(userChips)
      .where(and(eq(userChips.userId, userId), eq(userChips.id, chipId)));

    console.log(`[DB] User chip deleted: ${chipId}`);

    return true;
  } catch (error) {
    console.error("[DB] Delete user chip failed:", error);
    return false;
  }
}

// ==========================================
// CHIP BACKUP OPERATIONS
// ==========================================

export async function createChipBackup(backup: InsertChipBackup): Promise<ChipBackup | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db.insert(chipBackups).values(backup);
    console.log(`[DB] Chip backup created: ${backup.backupName}`);

    return {
      ...backup,
      id: result[0].insertId as number,
      createdAt: new Date(),
    } as ChipBackup;
  } catch (error) {
    console.error("[DB] Create chip backup failed:", error);
    return null;
  }
}

export async function getUserChipBackups(userId: number, chipId: number): Promise<ChipBackup[]> {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select()
      .from(chipBackups)
      .where(and(eq(chipBackups.userId, userId), eq(chipBackups.chipId, chipId)));

    return result;
  } catch (error) {
    console.error("[DB] Get user chip backups failed:", error);
    return [];
  }
}

export async function deleteChipBackup(userId: number, backupId: number): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db
      .delete(chipBackups)
      .where(and(eq(chipBackups.userId, userId), eq(chipBackups.id, backupId)));

    console.log(`[DB] Chip backup deleted: ${backupId}`);

    return true;
  } catch (error) {
    console.error("[DB] Delete chip backup failed:", error);
    return false;
  }
}

// ==========================================
// OPERATION LOG OPERATIONS
// ==========================================

export async function logOperation(log: InsertOperationLog): Promise<OperationLog | null> {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db.insert(operationLogs).values(log);
    console.log(`[DB] Operation logged: ${log.operationType}`);

    return {
      ...log,
      id: result[0].insertId as number,
      createdAt: new Date(),
    } as OperationLog;
  } catch (error) {
    console.error("[DB] Log operation failed:", error);
    return null;
  }
}

export async function getUserOperationLogs(userId: number, limit: number = 100): Promise<OperationLog[]> {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select()
      .from(operationLogs)
      .where(eq(operationLogs.userId, userId))
      .orderBy((t) => t.createdAt)
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[DB] Get user operation logs failed:", error);
    return [];
  }
}

export async function getChipOperationLogs(chipId: number, limit: number = 100): Promise<OperationLog[]> {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select()
      .from(operationLogs)
      .where(eq(operationLogs.chipId, chipId))
      .orderBy((t) => t.createdAt)
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[DB] Get chip operation logs failed:", error);
    return [];
  }
}

// ==========================================
// PAYMENT METHOD OPERATIONS
// ==========================================

export async function addPaymentMethod(
  userId: number,
  stripePaymentMethodId: string,
  cardBrand?: string,
  cardLast4?: string
): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db.insert(paymentMethods).values({
      userId,
      stripePaymentMethodId,
      cardBrand,
      cardLast4,
      isDefault: true,
    });

    console.log(`[DB] Payment method added for user: ${userId}`);

    return true;
  } catch (error) {
    console.error("[DB] Add payment method failed:", error);
    return false;
  }
}

export async function getUserPaymentMethods(userId: number) {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select()
      .from(paymentMethods)
      .where(eq(paymentMethods.userId, userId));

    return result;
  } catch (error) {
    console.error("[DB] Get user payment methods failed:", error);
    return [];
  }
}

// ==========================================
// TRANSACTION OPERATIONS
// ==========================================

export async function createTransaction(
  userId: number,
  transactionType: string,
  amount: number,
  description?: string
): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db.insert(transactions).values({
      userId,
      transactionType: transactionType as any,
      amount: amount.toString(),
      description,
      status: "pending",
    });

    console.log(`[DB] Transaction created for user: ${userId}`);

    return true;
  } catch (error) {
    console.error("[DB] Create transaction failed:", error);
    return false;
  }
}

export async function getUserTransactions(userId: number, limit: number = 50) {
  try {
    const db = await getDb();
    if (!db) return [];

    const result = await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy((t) => t.createdAt)
      .limit(limit);

    return result;
  } catch (error) {
    console.error("[DB] Get user transactions failed:", error);
    return [];
  }
}

// ==========================================
// USER PREFERENCES OPERATIONS
// ==========================================

export async function createUserPreferences(userId: number): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db.insert(userPreferences).values({ userId });

    console.log(`[DB] User preferences created for user: ${userId}`);

    return true;
  } catch (error) {
    console.error("[DB] Create user preferences failed:", error);
    return false;
  }
}

export async function getUserPreferences(userId: number) {
  try {
    const db = await getDb();
    if (!db) return null;

    const result = await db
      .select()
      .from(userPreferences)
      .where(eq(userPreferences.userId, userId))
      .limit(1);

    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[DB] Get user preferences failed:", error);
    return null;
  }
}

export async function updateUserPreferences(userId: number, updates: any): Promise<boolean> {
  try {
    const db = await getDb();
    if (!db) return false;

    await db.update(userPreferences).set(updates).where(eq(userPreferences.userId, userId));

    console.log(`[DB] User preferences updated for user: ${userId}`);

    return true;
  } catch (error) {
    console.error("[DB] Update user preferences failed:", error);
    return false;
  }
}
