import crypto from "crypto";

/**
 * NFC Communication Layer
 * Real protocol for deploying applets to Apex Flex chips via NFC
 * Implements ISO 7816-4 APDU (Application Protocol Data Unit) commands
 */

/**
 * APDU Command Structure
 * CLA | INS | P1 | P2 | Lc | Data | Le
 */
interface APDUCommand {
  cla: number; // Class byte (0x00 = standard, 0x80 = proprietary)
  ins: number; // Instruction
  p1: number; // Parameter 1
  p2: number; // Parameter 2
  data?: Buffer; // Command data
  le?: number; // Expected response length
}

interface APDUResponse {
  data: Buffer;
  sw1: number; // Status word 1
  sw2: number; // Status word 2
  statusWord: string; // Combined status (e.g., "9000")
  success: boolean;
}

/**
 * Java Card Installation APDU Commands
 */
const JAVA_CARD_COMMANDS = {
  // SELECT command - Select application
  SELECT: {
    cla: 0x00,
    ins: 0xa4,
    p1: 0x04,
    p2: 0x00,
  },

  // INSTALL command - Install applet
  INSTALL: {
    cla: 0x80,
    ins: 0xe6,
    p1: 0x0c,
    p2: 0x00,
  },

  // LOAD command - Load applet code
  LOAD: {
    cla: 0x80,
    ins: 0xe8,
    p1: 0x00,
    p2: 0x00,
  },

  // DELETE command - Delete applet
  DELETE: {
    cla: 0x80,
    ins: 0xe4,
    p1: 0x00,
    p2: 0x00,
  },

  // GET STATUS command - Get applet status
  GET_STATUS: {
    cla: 0x80,
    ins: 0xf2,
    p1: 0x80,
    p2: 0x00,
  },
};

/**
 * Vearch Custom Commands for Apex Flex
 */
const VEARCH_COMMANDS = {
  // Get chip UID
  GET_CHIP_UID: {
    cla: 0x80,
    ins: 0x00,
    p1: 0x00,
    p2: 0x00,
  },

  // Get chip version
  GET_VERSION: {
    cla: 0x80,
    ins: 0x01,
    p1: 0x00,
    p2: 0x00,
  },

  // Get installed applets
  GET_APPLETS: {
    cla: 0x80,
    ins: 0x02,
    p1: 0x00,
    p2: 0x00,
  },

  // Get chip memory info
  GET_MEMORY: {
    cla: 0x80,
    ins: 0x03,
    p1: 0x00,
    p2: 0x00,
  },

  // Verify biometric
  VERIFY_BIOMETRIC: {
    cla: 0x80,
    ins: 0x20,
    p1: 0x00,
    p2: 0x00,
  },

  // Execute applet command
  EXECUTE_APPLET: {
    cla: 0x80,
    ins: 0x30,
    p1: 0x00,
    p2: 0x00,
  },
};

/**
 * NFC Communication Handler
 */
export class NFCCommunicationHandler {
  private chipUid: string | null = null;
  private chipVersion: string | null = null;
  private encryptionKey: Buffer | null = null;
  private sequenceNumber: number = 0;

  /**
   * Initialize NFC connection with chip
   */
  async initializeConnection(chipUid: string): Promise<boolean> {
    try {
      this.chipUid = chipUid;

      // Step 1: Get chip version
      const versionResponse = await this.sendAPDU(VEARCH_COMMANDS.GET_VERSION);
      if (!versionResponse.success) {
        throw new Error("Failed to get chip version");
      }

      this.chipVersion = versionResponse.data.toString("utf8");
      console.log(`[NFC] Connected to chip ${chipUid}, version ${this.chipVersion}`);

      // Step 2: Generate session encryption key
      this.encryptionKey = crypto.randomBytes(32); // AES-256

      // Step 3: Verify chip authenticity
      const authSuccess = await this.verifyChipAuthenticity();
      if (!authSuccess) {
        throw new Error("Chip authentication failed");
      }

      return true;
    } catch (error) {
      console.error("[NFC] Connection initialization failed:", error);
      return false;
    }
  }

  /**
   * Deploy applet to chip
   */
  async deployApplet(
    appletBytecode: Buffer,
    appletAid: string,
    appletName: string
  ): Promise<{ success: boolean; message: string; txHash?: string }> {
    try {
      if (!this.chipUid || !this.encryptionKey) {
        throw new Error("NFC connection not initialized");
      }

      console.log(`[NFC] Starting applet deployment: ${appletName} (${appletAid})`);

      // Step 1: Check chip memory
      const memoryResponse = await this.sendAPDU(VEARCH_COMMANDS.GET_MEMORY);
      if (!memoryResponse.success) {
        throw new Error("Failed to get chip memory info");
      }

      const memoryInfo = this.parseMemoryInfo(memoryResponse.data);
      console.log(`[NFC] Chip memory: ${memoryInfo.available}/${memoryInfo.total} bytes available`);

      if (memoryInfo.available < appletBytecode.length) {
        throw new Error(
          `Insufficient chip memory: need ${appletBytecode.length}, have ${memoryInfo.available}`
        );
      }

      // Step 2: Load applet bytecode in chunks (max 255 bytes per APDU)
      const chunkSize = 240; // Leave room for APDU overhead
      const chunks = Math.ceil(appletBytecode.length / chunkSize);

      console.log(`[NFC] Loading applet bytecode in ${chunks} chunks...`);

      for (let i = 0; i < chunks; i++) {
        const start = i * chunkSize;
        const end = Math.min(start + chunkSize, appletBytecode.length);
        const chunk = appletBytecode.slice(start, end);

        const loadCommand: APDUCommand = {
          ...JAVA_CARD_COMMANDS.LOAD,
          p1: i >> 8, // Chunk index high byte
          p2: i & 0xff, // Chunk index low byte
          data: chunk,
        };

        const response = await this.sendAPDU(loadCommand);
        if (!response.success) {
          throw new Error(`Failed to load chunk ${i}/${chunks}`);
        }

        console.log(`[NFC] Loaded chunk ${i + 1}/${chunks}`);
      }

      // Step 3: Install applet
      console.log(`[NFC] Installing applet...`);

      const installData = this.buildInstallData(appletAid, appletName);
      const installCommand: APDUCommand = {
        ...JAVA_CARD_COMMANDS.INSTALL,
        data: installData,
      };

      const installResponse = await this.sendAPDU(installCommand);
      if (!installResponse.success) {
        throw new Error("Applet installation failed");
      }

      // Step 4: Verify installation
      console.log(`[NFC] Verifying installation...`);

      const verifyResponse = await this.sendAPDU(VEARCH_COMMANDS.GET_APPLETS);
      if (!verifyResponse.success) {
        throw new Error("Failed to verify applet installation");
      }

      const installedApplets = this.parseAppletList(verifyResponse.data);
      const appletInstalled = installedApplets.some((a) => a.aid === appletAid);

      if (!appletInstalled) {
        throw new Error("Applet not found after installation");
      }

      // Step 5: Generate deployment transaction hash
      const txHash = this.generateDeploymentHash(appletAid, appletBytecode);

      console.log(`[NFC] Applet deployment successful: ${txHash}`);

      return {
        success: true,
        message: `Applet ${appletName} deployed successfully`,
        txHash,
      };
    } catch (error) {
      console.error("[NFC] Applet deployment failed:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }

  /**
   * Execute applet command
   */
  async executeAppletCommand(
    appletAid: string,
    command: string,
    commandData?: Buffer
  ): Promise<{ success: boolean; response: Buffer; statusWord: string }> {
    try {
      if (!this.chipUid) {
        throw new Error("NFC connection not initialized");
      }

      // Step 1: Select applet
      const selectCommand: APDUCommand = {
        ...JAVA_CARD_COMMANDS.SELECT,
        data: Buffer.from(appletAid, "hex"),
      };

      const selectResponse = await this.sendAPDU(selectCommand);
      if (!selectResponse.success) {
        throw new Error("Failed to select applet");
      }

      // Step 2: Execute command
      const executeData = this.buildExecuteData(command, commandData);
      const executeCommand: APDUCommand = {
        ...VEARCH_COMMANDS.EXECUTE_APPLET,
        data: executeData,
        le: 255, // Expect response
      };

      const executeResponse = await this.sendAPDU(executeCommand);

      return {
        success: executeResponse.success,
        response: executeResponse.data,
        statusWord: executeResponse.statusWord,
      };
    } catch (error) {
      console.error("[NFC] Applet command execution failed:", error);
      return {
        success: false,
        response: Buffer.alloc(0),
        statusWord: "6F00", // Unknown error
      };
    }
  }

  /**
   * Verify biometric on chip
   */
  async verifyBiometric(biometricData: Buffer): Promise<boolean> {
    try {
      const verifyCommand: APDUCommand = {
        ...VEARCH_COMMANDS.VERIFY_BIOMETRIC,
        data: biometricData,
      };

      const response = await this.sendAPDU(verifyCommand);
      return response.success && response.statusWord === "9000";
    } catch (error) {
      console.error("[NFC] Biometric verification failed:", error);
      return false;
    }
  }

  /**
   * Send APDU command to chip
   */
  private async sendAPDU(command: APDUCommand): Promise<APDUResponse> {
    try {
      // Build APDU command
      const apdu = this.buildAPDU(command);

      // Encrypt command if encryption key is set
      let transmitData = apdu;
      if (this.encryptionKey) {
        transmitData = this.encryptAPDU(apdu);
      }

      // Simulate NFC transmission
      // In production, this would use actual NFC hardware API
      const response = await this.simulateNFCTransmission(transmitData);

      // Decrypt response if needed
      let responseData = response;
      if (this.encryptionKey) {
        responseData = this.decryptAPDU(response);
      }

      // Parse response
      const parsed = this.parseAPDUResponse(responseData);

      return parsed;
    } catch (error) {
      console.error("[NFC] APDU transmission failed:", error);
      return {
        data: Buffer.alloc(0),
        sw1: 0x6f,
        sw2: 0x00,
        statusWord: "6F00",
        success: false,
      };
    }
  }

  /**
   * Build APDU command
   */
  private buildAPDU(command: APDUCommand): Buffer {
    const data = command.data || Buffer.alloc(0);
    const le = command.le !== undefined ? Buffer.from([command.le]) : Buffer.alloc(0);

    return Buffer.concat([
      Buffer.from([command.cla, command.ins, command.p1, command.p2]),
      Buffer.from([data.length]),
      data,
      le,
    ]);
  }

  /**
   * Parse APDU response
   */
  private parseAPDUResponse(response: Buffer): APDUResponse {
    if (response.length < 2) {
      return {
        data: Buffer.alloc(0),
        sw1: 0x6f,
        sw2: 0x00,
        statusWord: "6F00",
        success: false,
      };
    }

    const sw1 = response[response.length - 2];
    const sw2 = response[response.length - 1];
    const data = response.slice(0, response.length - 2);

    return {
      data,
      sw1,
      sw2,
      statusWord: `${sw1.toString(16).padStart(2, "0")}${sw2.toString(16).padStart(2, "0")}`,
      success: sw1 === 0x90 && sw2 === 0x00,
    };
  }

  /**
   * Encrypt APDU command
   */
  private encryptAPDU(apdu: Buffer): Buffer {
    if (!this.encryptionKey) throw new Error("Encryption key not set");

    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv("aes-256-cbc", this.encryptionKey, iv);

    let encrypted = cipher.update(apdu);
    encrypted = Buffer.concat([encrypted, cipher.final()]);

    return Buffer.concat([iv, encrypted]);
  }

  /**
   * Decrypt APDU response
   */
  private decryptAPDU(encrypted: Buffer): Buffer {
    if (!this.encryptionKey) throw new Error("Encryption key not set");

    const iv = encrypted.slice(0, 16);
    const data = encrypted.slice(16);

    const decipher = crypto.createDecipheriv("aes-256-cbc", this.encryptionKey, iv);

    let decrypted = decipher.update(data);
    decrypted = Buffer.concat([decrypted, decipher.final()]);

    return decrypted;
  }

  /**
   * Simulate NFC transmission
   * In production, this would use actual NFC hardware
   */
  private async simulateNFCTransmission(data: Buffer): Promise<Buffer> {
    // Simulate network latency
    await new Promise((resolve) => setTimeout(resolve, 50));

    // Simulate successful response
    // In production, this would communicate with actual NFC reader
    return Buffer.concat([Buffer.from([0x90, 0x00])]);
  }

  /**
   * Build install data for applet
   */
  private buildInstallData(appletAid: string, appletName: string): Buffer {
    const aidBuffer = Buffer.from(appletAid, "hex");
    const nameBuffer = Buffer.from(appletName, "utf8");

    return Buffer.concat([
      Buffer.from([aidBuffer.length]),
      aidBuffer,
      Buffer.from([nameBuffer.length]),
      nameBuffer,
    ]);
  }

  /**
   * Build execute data for applet command
   */
  private buildExecuteData(command: string, data?: Buffer): Buffer {
    const commandBuffer = Buffer.from(command, "utf8");
    const dataBuffer = data || Buffer.alloc(0);

    return Buffer.concat([
      Buffer.from([commandBuffer.length]),
      commandBuffer,
      Buffer.from([dataBuffer.length]),
      dataBuffer,
    ]);
  }

  /**
   * Parse memory info from response
   */
  private parseMemoryInfo(data: Buffer): { total: number; available: number } {
    if (data.length < 4) {
      return { total: 0, available: 0 };
    }

    const total = data.readUInt16BE(0);
    const available = data.readUInt16BE(2);

    return { total, available };
  }

  /**
   * Parse applet list from response
   */
  private parseAppletList(data: Buffer): Array<{ aid: string; name: string }> {
    const applets: Array<{ aid: string; name: string }> = [];
    let offset = 0;

    while (offset < data.length) {
      const aidLength = data[offset];
      offset++;

      if (offset + aidLength > data.length) break;

      const aid = data.slice(offset, offset + aidLength).toString("hex");
      offset += aidLength;

      const nameLength = data[offset];
      offset++;

      if (offset + nameLength > data.length) break;

      const name = data.slice(offset, offset + nameLength).toString("utf8");
      offset += nameLength;

      applets.push({ aid, name });
    }

    return applets;
  }

  /**
   * Verify chip authenticity
   */
  private async verifyChipAuthenticity(): Promise<boolean> {
    // In production, this would verify chip certificate or signature
    return true;
  }

  /**
   * Generate deployment transaction hash
   */
  private generateDeploymentHash(appletAid: string, bytecode: Buffer): string {
    const hash = crypto
      .createHash("sha256")
      .update(Buffer.concat([Buffer.from(appletAid, "hex"), bytecode]))
      .digest("hex");

    return `0x${hash}`;
  }
}

/**
 * Export singleton instance
 */
export const nfcHandler = new NFCCommunicationHandler();
