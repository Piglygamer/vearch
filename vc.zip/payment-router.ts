import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import {
  createWallet,
  getUserWallets,
  getWalletBalance,
  createPaymentIntent,
  confirmPayment,
  processTransaction,
  addPaymentMethod,
  getUserPaymentMethods,
  setDefaultPaymentMethod,
  createCryptoWallet,
  getUserCryptoWallets,
  createRecurringPayment,
  getUserRecurringPayments,
  cancelRecurringPayment,
  getWalletTransactions,
  getTransactionById,
} from "./payment-service";

export const paymentRouter = router({
  /**
   * WALLET MANAGEMENT
   */
  createWallet: protectedProcedure
    .input(
      z.object({
        chipId: z.number(),
        walletName: z.string(),
        walletType: z.enum(["fiat", "cryptocurrency", "hybrid"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return createWallet(
        ctx.user.id,
        input.chipId,
        input.walletName,
        input.walletType
      );
    }),

  getMyWallets: protectedProcedure.query(async ({ ctx }) => {
    return getUserWallets(ctx.user.id);
  }),

  getWalletBalance: protectedProcedure
    .input(
      z.object({
        walletId: z.number(),
        currency: z.string(),
      })
    )
    .query(async ({ input }) => {
      return getWalletBalance(input.walletId, input.currency);
    }),

  /**
   * PAYMENT PROCESSING
   */
  createPaymentIntent: protectedProcedure
    .input(
      z.object({
        walletId: z.number(),
        amount: z.number().positive(),
        currency: z.string().default("USD"),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return createPaymentIntent(
        ctx.user.id,
        input.walletId,
        input.amount,
        input.currency,
        input.description
      );
    }),

  confirmPayment: protectedProcedure
    .input(
      z.object({
        paymentIntentId: z.string(),
        paymentMethodId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      return confirmPayment(input.paymentIntentId, input.paymentMethodId);
    }),

  processTransaction: protectedProcedure
    .input(
      z.object({
        walletId: z.number(),
        amount: z.number().positive(),
        currency: z.string(),
        transactionType: z.enum([
          "payment",
          "transfer",
          "deposit",
          "withdrawal",
          "refund",
          "fee",
        ]),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return processTransaction(
        input.walletId,
        input.amount,
        input.currency,
        input.transactionType,
        input.description
      );
    }),

  /**
   * PAYMENT METHODS
   */
  addPaymentMethod: protectedProcedure
    .input(
      z.object({
        stripePaymentMethodId: z.string(),
        methodType: z.enum(["card", "bank_account", "wallet", "cryptocurrency"]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return addPaymentMethod(
        ctx.user.id,
        input.stripePaymentMethodId,
        input.methodType
      );
    }),

  getMyPaymentMethods: protectedProcedure.query(async ({ ctx }) => {
    return getUserPaymentMethods(ctx.user.id);
  }),

  setDefaultPaymentMethod: protectedProcedure
    .input(z.object({ methodId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      return setDefaultPaymentMethod(ctx.user.id, input.methodId);
    }),

  /**
   * CRYPTOCURRENCY
   */
  createCryptoWallet: protectedProcedure
    .input(
      z.object({
        chipId: z.number(),
        cryptocurrency: z.string(),
        publicAddress: z.string(),
        encryptedPrivateKey: z.string(),
        derivationPath: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return createCryptoWallet(
        ctx.user.id,
        input.chipId,
        input.cryptocurrency,
        input.publicAddress,
        input.encryptedPrivateKey,
        input.derivationPath
      );
    }),

  getMyCryptoWallets: protectedProcedure.query(async ({ ctx }) => {
    return getUserCryptoWallets(ctx.user.id);
  }),

  /**
   * RECURRING PAYMENTS
   */
  createRecurringPayment: protectedProcedure
    .input(
      z.object({
        walletId: z.number(),
        amount: z.number().positive(),
        currency: z.string(),
        frequency: z.enum([
          "daily",
          "weekly",
          "biweekly",
          "monthly",
          "quarterly",
          "yearly",
        ]),
      })
    )
    .mutation(async ({ input, ctx }) => {
      return createRecurringPayment(
        ctx.user.id,
        input.walletId,
        input.amount,
        input.currency,
        input.frequency
      );
    }),

  getMyRecurringPayments: protectedProcedure.query(async ({ ctx }) => {
    return getUserRecurringPayments(ctx.user.id);
  }),

  cancelRecurringPayment: protectedProcedure
    .input(z.object({ subscriptionId: z.string() }))
    .mutation(async ({ input }) => {
      return cancelRecurringPayment(input.subscriptionId);
    }),

  /**
   * TRANSACTION HISTORY
   */
  getWalletTransactions: protectedProcedure
    .input(
      z.object({
        walletId: z.number(),
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      return getWalletTransactions(input.walletId, input.limit, input.offset);
    }),

  getTransaction: protectedProcedure
    .input(z.object({ transactionId: z.number() }))
    .query(async ({ input }) => {
      return getTransactionById(input.transactionId);
    }),
});

export type PaymentRouter = typeof paymentRouter;
