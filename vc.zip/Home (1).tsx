import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Zap, Users, BookOpen, MapPin, Cpu, Shield } from "lucide-react";
import { useLocation } from "wouter";

/**
 * VEARCH CHIP - Home Page
 * Hero section with navigation to all platform features
 */

export default function Home() {
  const [, navigate] = useLocation();

  const features = [
    {
      icon: <Cpu className="w-8 h-8" />,
      title: "Compare Chips",
      description: "Detailed specs for xM1 gen2, Spark 2, and Apex Flex",
      href: "/comparison",
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Chip Registry",
      description: "Track, manage, and monitor your implants",
      href: "/registry",
    },
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Installation Guides",
      description: "Professional procedures and aftercare protocols",
      href: "/installation",
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Community",
      description: "Connect with biohackers and share experiences",
      href: "/community",
    },
    {
      icon: <MapPin className="w-8 h-8" />,
      title: "Find Professionals",
      description: "Locate certified installation partners",
      href: "/professionals",
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Dashboard",
      description: "Manage your implants and settings",
      href: "/dashboard",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-lg flex items-center justify-center">
              <Cpu className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white">Vearch CHIP</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/comparison")}
              className="text-slate-300 hover:text-white"
            >
              Compare
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/community")}
              className="text-slate-300 hover:text-white"
            >
              Community
            </Button>
            <Button
              size="sm"
              onClick={() => navigate("/dashboard")}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Dashboard
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-6 bg-blue-900/50 text-blue-300 border-blue-700">
            Biohacking Platform
          </Badge>

          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            The Future of Implant Technology
          </h2>

          <p className="text-xl text-slate-400 mb-8 max-w-2xl mx-auto">
            Vearch CHIP is the comprehensive platform for managing, comparing, and deploying biohacking implants. From the affordable xM1 gen2 to the advanced Apex Flex, explore everything you need to know about subdermal technology.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button
              size="lg"
              onClick={() => navigate("/comparison")}
              className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
            >
              Explore Chips <ArrowRight className="w-4 h-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/professionals")}
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              Find Installation Partner
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 md:gap-8 mb-16">
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="text-2xl md:text-3xl font-bold text-cyan-400">3</div>
              <p className="text-sm text-slate-400 mt-1">Chip Types</p>
            </div>
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="text-2xl md:text-3xl font-bold text-cyan-400">100%</div>
              <p className="text-sm text-slate-400 mt-1">Open Source</p>
            </div>
            <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
              <div className="text-2xl md:text-3xl font-bold text-cyan-400">24/7</div>
              <p className="text-sm text-slate-400 mt-1">Support</p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container py-20">
        <h3 className="text-3xl font-bold text-white mb-12 text-center">
          Platform Features
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, idx) => (
            <Card
              key={idx}
              className="bg-slate-800/50 border-slate-700 hover:border-blue-600 transition-all duration-300 cursor-pointer group"
              onClick={() => navigate(feature.href)}
            >
              <CardContent className="p-6">
                <div className="mb-4 text-cyan-400 group-hover:text-blue-400 transition-colors">
                  {feature.icon}
                </div>
                <h4 className="text-lg font-semibold text-white mb-2">
                  {feature.title}
                </h4>
                <p className="text-slate-400 text-sm mb-4">{feature.description}</p>
                <div className="flex items-center gap-2 text-blue-400 text-sm font-medium group-hover:gap-3 transition-all">
                  Learn more <ArrowRight className="w-4 h-4" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Quick Start */}
      <section className="container py-20">
        <div className="bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border border-blue-800/50 rounded-xl p-12">
          <h3 className="text-2xl font-bold text-white mb-6">Quick Start Guide</h3>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
                1
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">Compare Chips</h4>
                <p className="text-slate-400 text-sm">
                  Explore detailed specifications and capabilities of each implant
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
                2
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">Find Professional</h4>
                <p className="text-slate-400 text-sm">
                  Locate certified installation partners in your area
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold">
                3
              </div>
              <div>
                <h4 className="font-semibold text-white mb-2">Get Implanted</h4>
                <p className="text-slate-400 text-sm">
                  Follow professional procedures and aftercare protocols
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold text-white mb-4">Platform</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <button
                    onClick={() => navigate("/comparison")}
                    className="hover:text-white transition-colors"
                  >
                    Compare Chips
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate("/registry")}
                    className="hover:text-white transition-colors"
                  >
                    Chip Registry
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate("/dashboard")}
                    className="hover:text-white transition-colors"
                  >
                    Dashboard
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-white mb-4">Resources</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <button
                    onClick={() => navigate("/installation")}
                    className="hover:text-white transition-colors"
                  >
                    Installation Guides
                  </button>
                </li>
                <li>
                  <button
                    onClick={() => navigate("/professionals")}
                    className="hover:text-white transition-colors"
                  >
                    Find Professionals
                  </button>
                </li>
                <li>
                  <a
                    href="https://dangerousthings.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors"
                  >
                    Dangerous Things
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-white mb-4">Community</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <button
                    onClick={() => navigate("/community")}
                    className="hover:text-white transition-colors"
                  >
                    Forum
                  </button>
                </li>
                <li>
                  <a
                    href="https://forum.dangerousthings.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors"
                  >
                    DT Forum
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-white transition-colors">
                    Disclaimer
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-8 text-center text-slate-400 text-sm">
            <p>
              © 2026 Vearch CHIP. All rights reserved. Biohacking responsibly.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
