import { describe, it, expect, beforeEach, vi } from "vitest";
import Spark2OperationsManager from "./spark2-operations";
import ApexFlexOperationsManager from "./apex-flex-operations";

/**
 * Comprehensive Test Suite for NFC Operations
 * Tests all chip operations, applet management, and error handling
 */

describe("Spark 2 Operations", () => {
  describe("Capability Detection", () => {
    it("should detect basic capability from UID", () => {
      const uid = "01ABCDEF1234567890";
      const capabilities = Spark2OperationsManager.getCapabilitiesFromUID(uid);

      expect(capabilities).toContain("uid_read");
      expect(capabilities).toContain("ndef_read");
    });

    it("should detect payment capability from UID", () => {
      const uid = "03ABCDEF1234567890";
      const capabilities = Spark2OperationsManager.getCapabilitiesFromUID(uid);

      expect(capabilities).toContain("payment");
      expect(capabilities).toContain("applet_deployment");
    });

    it("should return empty array for unknown UID prefix", () => {
      const uid = "FFABCDEF1234567890";
      const capabilities = Spark2OperationsManager.getCapabilitiesFromUID(uid);

      expect(Array.isArray(capabilities)).toBe(true);
    });
  });

  describe("Capability Upgrades", () => {
    it("should upgrade from basic to payment capability", async () => {
      const currentUID = "01ABCDEF1234567890";
      const result = await Spark2OperationsManager.upgradeCapability(
        currentUID,
        "payment"
      );

      expect(result.success).toBe(true);
      expect(result.oldUID).toBe(currentUID);
      expect(result.newUID).toMatch(/^03/);
      expect(result.capability).toBe("payment");
      expect(result.timestamp).toBeDefined();
    });

    it("should throw error for unknown capability", async () => {
      const currentUID = "01ABCDEF1234567890";

      await expect(
        Spark2OperationsManager.upgradeCapability(currentUID, "unknown")
      ).rejects.toThrow("Unknown capability");
    });
  });

  describe("Upgrade Paths", () => {
    it("should return available upgrades", () => {
      const uid = "01ABCDEF1234567890";
      const upgrades = Spark2OperationsManager.getAvailableUpgrades(uid);

      expect(Array.isArray(upgrades)).toBe(true);
      expect(upgrades.length).toBeGreaterThan(0);
      expect(upgrades[0].cost).toBeGreaterThan(0);
    });

    it("should return upgrade path from basic to premium", () => {
      const uid = "01ABCDEF1234567890";
      const path = Spark2OperationsManager.getUpgradePath(uid, "premium");

      expect(Array.isArray(path)).toBe(true);
      expect(path.length).toBeGreaterThan(0);
      expect(path[path.length - 1].name).toBe("Premium");
    });
  });

  describe("Chip Verification", () => {
    it("should verify chip authenticity", async () => {
      const uid = "01ABCDEF1234567890";
      const isAuthentic = await Spark2OperationsManager.verifyChipAuthenticity(uid);

      expect(typeof isAuthentic).toBe("boolean");
    });
  });

  describe("Chip Status", () => {
    it("should return complete chip status", async () => {
      const uid = "03ABCDEF1234567890";
      const status = await Spark2OperationsManager.getChipStatus(uid);

      expect(status.uid).toBe(uid);
      expect(status.capability).toBeDefined();
      expect(Array.isArray(status.features)).toBe(true);
      expect(typeof status.isAuthentic).toBe("boolean");
      expect(typeof status.canUpgrade).toBe("boolean");
    });
  });
});

describe("Apex Flex Operations", () => {
  describe("Applet Management", () => {
    it("should return list of available applets", () => {
      const applets = ApexFlexOperationsManager.getAvailableApplets();

      expect(Array.isArray(applets)).toBe(true);
      expect(applets.length).toBeGreaterThan(0);
      expect(applets[0]).toHaveProperty("aid");
      expect(applets[0]).toHaveProperty("name");
      expect(applets[0]).toHaveProperty("type");
    });

    it("should get applet by AID", () => {
      const aid = "A0000000041010";
      const applet = ApexFlexOperationsManager.getAppletByAID(aid);

      expect(applet).toBeDefined();
      expect(applet?.aid).toBe(aid);
      expect(applet?.name).toBe("EMV Payment Applet");
    });

    it("should return undefined for unknown AID", () => {
      const applet = ApexFlexOperationsManager.getAppletByAID("UNKNOWN");

      expect(applet).toBeUndefined();
    });

    it("should filter applets by type", () => {
      const paymentApplets = ApexFlexOperationsManager.getAppletsByType("payment");

      expect(Array.isArray(paymentApplets)).toBe(true);
      expect(paymentApplets.length).toBeGreaterThan(0);
      expect(paymentApplets.every((a) => a.type === "payment")).toBe(true);
    });
  });

  describe("Applet Deployment", () => {
    it("should deploy applet successfully", async () => {
      const aid = "A0000000041010";
      const bytecode = Buffer.from("00112233445566778899");

      const result = await ApexFlexOperationsManager.deployApplet(aid, bytecode);

      expect(result.success).toBe(true);
      expect(result.applet).toBeDefined();
      expect(result.applet?.installed).toBe(true);
      expect(result.applet?.deploymentDate).toBeDefined();
    });

    it("should fail deployment for unknown applet", async () => {
      const aid = "UNKNOWN";
      const bytecode = Buffer.from("00112233445566778899");

      const result = await ApexFlexOperationsManager.deployApplet(aid, bytecode);

      expect(result.success).toBe(false);
      expect(result.applet).toBeUndefined();
    });
  });

  describe("Applet Commands", () => {
    it("should execute command on installed applet", async () => {
      const aid = "A0000000041010";
      const command = {
        cla: "00",
        ins: "A4",
        p1: "04",
        p2: "00",
        data: "A0000000041010",
      };

      const result = await ApexFlexOperationsManager.executeCommand(aid, command);

      expect(result.success).toBe(true);
      expect(result.status).toBe("9000");
    });

    it("should fail command on uninstalled applet", async () => {
      const aid = "A0000000041010";
      const command = {
        cla: "00",
        ins: "A4",
        p1: "04",
        p2: "00",
      };

      const result = await ApexFlexOperationsManager.executeCommand(aid, command);

      expect(result.success).toBe(false);
    });
  });

  describe("Applet Uninstall", () => {
    it("should uninstall applet", async () => {
      const aid = "A0000000041010";
      const result = await ApexFlexOperationsManager.uninstallApplet(aid);

      expect(result.success).toBe(true);
      expect(result.message).toContain("uninstalled");
    });

    it("should fail uninstall for unknown applet", async () => {
      const result = await ApexFlexOperationsManager.uninstallApplet("UNKNOWN");

      expect(result.success).toBe(false);
    });
  });

  describe("Chip Status", () => {
    it("should return complete chip status", async () => {
      const uid = "0123456789ABCDEF";
      const status = await ApexFlexOperationsManager.getChipStatus(uid);

      expect(status.uid).toBe(uid);
      expect(status.isConnected).toBe(true);
      expect(Array.isArray(status.installedApplets)).toBe(true);
      expect(typeof status.memoryAvailable).toBe("number");
      expect(typeof status.memoryTotal).toBe("number");
      expect(typeof status.isAuthentic).toBe("boolean");
    });
  });

  describe("Recommended Setups", () => {
    it("should return payment setup applets", () => {
      const applets = ApexFlexOperationsManager.getPaymentSetup();

      expect(Array.isArray(applets)).toBe(true);
      expect(applets.length).toBeGreaterThan(0);
      expect(applets.some((a) => a.type === "payment")).toBe(true);
    });

    it("should return identity setup applets", () => {
      const applets = ApexFlexOperationsManager.getIdentitySetup();

      expect(Array.isArray(applets)).toBe(true);
      expect(applets.length).toBeGreaterThan(0);
      expect(applets.some((a) => a.type === "identity")).toBe(true);
    });

    it("should return crypto setup applets", () => {
      const applets = ApexFlexOperationsManager.getCryptoSetup();

      expect(Array.isArray(applets)).toBe(true);
      expect(applets.length).toBeGreaterThan(0);
      expect(applets.some((a) => a.type === "crypto")).toBe(true);
    });
  });

  describe("Memory Management", () => {
    it("should check if applet can be installed", () => {
      const applet = ApexFlexOperationsManager.getAvailableApplets()[0];
      const canInstall = ApexFlexOperationsManager.canInstallApplet(applet, 32768);

      expect(typeof canInstall).toBe("boolean");
      expect(canInstall).toBe(true);
    });

    it("should reject applet installation if insufficient memory", () => {
      const applet = ApexFlexOperationsManager.getAvailableApplets()[0];
      const canInstall = ApexFlexOperationsManager.canInstallApplet(applet, 100);

      expect(canInstall).toBe(false);
    });
  });
});

describe("Error Handling", () => {
  it("should handle invalid UID format gracefully", () => {
    const capabilities = Spark2OperationsManager.getCapabilitiesFromUID("");

    expect(Array.isArray(capabilities)).toBe(true);
  });

  it("should handle null/undefined inputs", () => {
    const capabilities = Spark2OperationsManager.getCapabilitiesFromUID(null as any);

    expect(Array.isArray(capabilities)).toBe(true);
  });
});

describe("Integration Tests", () => {
  it("should complete full Spark 2 upgrade workflow", async () => {
    const uid = "01ABCDEF1234567890";

    // Get current status
    const initialStatus = await Spark2OperationsManager.getChipStatus(uid);
    expect(initialStatus.capability).toBe("Basic");

    // Get available upgrades
    const upgrades = Spark2OperationsManager.getAvailableUpgrades(uid);
    expect(upgrades.length).toBeGreaterThan(0);

    // Upgrade to payment
    const upgradeResult = await Spark2OperationsManager.upgradeCapability(
      uid,
      "payment"
    );
    expect(upgradeResult.success).toBe(true);

    // Verify new capabilities
    const newCapabilities = Spark2OperationsManager.getCapabilitiesFromUID(
      upgradeResult.newUID
    );
    expect(newCapabilities).toContain("payment");
  });

  it("should complete full Apex Flex applet deployment workflow", async () => {
    // Get available payment applets
    const paymentApplets = ApexFlexOperationsManager.getPaymentApplets();
    expect(paymentApplets.length).toBeGreaterThan(0);

    const applet = paymentApplets[0];

    // Deploy applet
    const bytecode = Buffer.from("00112233445566778899");
    const deployResult = await ApexFlexOperationsManager.deployApplet(
      applet.aid,
      bytecode
    );
    expect(deployResult.success).toBe(true);

    // Execute command
    const command = {
      cla: "00",
      ins: "A4",
      p1: "04",
      p2: "00",
      data: applet.aid,
    };
    const execResult = await ApexFlexOperationsManager.executeCommand(
      applet.aid,
      command
    );
    expect(execResult.success).toBe(true);

    // Uninstall applet
    const uninstallResult = await ApexFlexOperationsManager.uninstallApplet(
      applet.aid
    );
    expect(uninstallResult.success).toBe(true);
  });
});
