import { Router, Request, Response } from "express";
import { FidesmoServiceManager } from "./fidesmo-unified";
import crypto from "crypto";

/**
 * Fidesmo Webhook Handler
 * Public endpoint for receiving deployment completion callbacks from Fidesmo
 * 
 * This is NOT a tRPC procedure - it's a real Express endpoint
 * that Fidesmo calls directly with webhook events
 */

const fidesmoConfig = {
  baseUrl: process.env.FIDESMO_API_URL || "https://api.fidesmo.com/v3",
  username: process.env.FIDESMO_USERNAME || "",
  password: process.env.FIDESMO_PASSWORD || "",
  callbackUrl: process.env.FIDESMO_CALLBACK_URL || "https://your-domain.com/api/fidesmo/webhook",
  callbackSecret: process.env.FIDESMO_CALLBACK_SECRET || "",
};

const fidesmoManager = new FidesmoServiceManager(fidesmoConfig);

export const fidesmoWebhookRouter = Router();

/**
 * POST /api/fidesmo/webhook
 * 
 * Fidesmo sends deployment completion events to this endpoint
 * 
 * Expected payload:
 * {
 *   "operationId": "op_xxx",
 *   "status": "success" | "failure",
 *   "message": "Installation completed successfully",
 *   "timestamp": "2026-05-16T20:00:00Z"
 * }
 * 
 * Signature verification:
 * - Header: X-Fidesmo-Signature
 * - Calculated as: HMAC-SHA256(payload, callbackSecret)
 */
fidesmoWebhookRouter.post("/webhook", async (req: Request, res: Response) => {
  try {
    // Get signature from header
    const signature = req.headers["x-fidesmo-signature"] as string;
    if (!signature) {
      console.error("[Fidesmo Webhook] Missing signature header");
      return res.status(401).json({ error: "Missing signature" });
    }

    // Get raw body for signature verification
    const rawBody = JSON.stringify(req.body);

    // Verify signature
    const expectedSignature = crypto
      .createHmac("sha256", fidesmoConfig.callbackSecret)
      .update(rawBody)
      .digest("hex");

    if (signature !== expectedSignature) {
      console.error("[Fidesmo Webhook] Invalid signature");
      return res.status(401).json({ error: "Invalid signature" });
    }

    // Extract event data
    const { operationId, status, message, timestamp } = req.body;

    if (!operationId || !status) {
      console.error("[Fidesmo Webhook] Missing required fields");
      return res.status(400).json({ error: "Missing operationId or status" });
    }

    console.log(`[Fidesmo Webhook] Received callback: operationId=${operationId}, status=${status}`);

    // Handle the deployment completion
    await fidesmoManager.handleDeploymentCallback(
      operationId,
      status as "success" | "failure",
      message
    );

    // Return success to Fidesmo
    res.json({
      success: true,
      operationId,
      receivedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[Fidesmo Webhook] Error processing callback:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

/**
 * GET /api/fidesmo/webhook/health
 * Health check endpoint for webhook delivery verification
 */
fidesmoWebhookRouter.get("/webhook/health", (req: Request, res: Response) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
  });
});

export default fidesmoWebhookRouter;
