import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertCircle,
  CheckCircle,
  Lock,
  Unlock,
  Zap,
  Shield,
  Key,
  Smartphone,
  Settings,
  Upload,
  Download,
} from "lucide-react";
import { nfcManager } from "@/lib/nfc-manager";

interface Spark2Device {
  uid: string;
  name: string;
  detected: boolean;
  connected: boolean;
  battery?: number;
  firmwareVersion?: string;
  capabilities: Spark2Capability[];
  upgrades: Spark2Upgrade[];
}

interface Spark2Capability {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  permanentUID: string;
}

interface Spark2Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  permanentUID: string;
  unlocked: boolean;
  features: string[];
}

interface Spark2Manager {
  device: Spark2Device | null;
  selectedDevice: string | null;
  isConnected: boolean;
  isScanning: boolean;
  upgrades: Spark2Upgrade[];
  capabilities: Spark2Capability[];
}

const SPARK2_CAPABILITIES: Spark2Capability[] = [
  {
    id: "crypto",
    name: "Cryptography Engine",
    description: "AES-256, RSA-2048, ECC support",
    enabled: true,
    permanentUID: "SPARK2_CRYPTO_001",
  },
  {
    id: "nfc",
    name: "NFC Communication",
    description: "ISO 14443A Type 4 Tag support",
    enabled: true,
    permanentUID: "SPARK2_NFC_001",
  },
  {
    id: "auth",
    name: "Authentication",
    description: "FIDO2, U2F, OAuth support",
    enabled: false,
    permanentUID: "SPARK2_AUTH_001",
  },
  {
    id: "payment",
    name: "Payment Processing",
    description: "EMV-compatible payment applet",
    enabled: false,
    permanentUID: "SPARK2_PAYMENT_001",
  },
  {
    id: "identity",
    name: "Identity Management",
    description: "DID, Verifiable Credentials",
    enabled: false,
    permanentUID: "SPARK2_IDENTITY_001",
  },
  {
    id: "storage",
    name: "Secure Storage",
    description: "Encrypted data storage (4KB)",
    enabled: false,
    permanentUID: "SPARK2_STORAGE_001",
  },
];

const SPARK2_UPGRADES: Spark2Upgrade[] = [
  {
    id: "auth-upgrade",
    name: "Authentication Suite",
    description: "Unlock FIDO2, U2F, and OAuth capabilities",
    cost: 29.99,
    permanentUID: "SPARK2_AUTH_UPGRADE_001",
    unlocked: false,
    features: ["FIDO2", "U2F", "OAuth", "WebAuthn"],
  },
  {
    id: "payment-upgrade",
    name: "Payment Processing",
    description: "Enable EMV-compatible tap-to-pay",
    cost: 49.99,
    permanentUID: "SPARK2_PAYMENT_UPGRADE_001",
    unlocked: false,
    features: ["EMV", "Contactless Payment", "Transaction Logging"],
  },
  {
    id: "identity-upgrade",
    name: "Identity Management",
    description: "Self-sovereign identity and verifiable credentials",
    cost: 39.99,
    permanentUID: "SPARK2_IDENTITY_UPGRADE_001",
    unlocked: false,
    features: ["DID", "Verifiable Credentials", "Credential Issuance"],
  },
  {
    id: "storage-upgrade",
    name: "Extended Storage",
    description: "Increase secure storage to 16KB",
    cost: 19.99,
    permanentUID: "SPARK2_STORAGE_UPGRADE_001",
    unlocked: false,
    features: ["16KB Storage", "Encrypted Backup", "Data Sync"],
  },
  {
    id: "biometric-upgrade",
    name: "Biometric Authentication",
    description: "Fingerprint and face recognition support",
    cost: 59.99,
    permanentUID: "SPARK2_BIOMETRIC_UPGRADE_001",
    unlocked: false,
    features: ["Fingerprint", "Face Recognition", "Behavioral Auth"],
  },
  {
    id: "iot-upgrade",
    name: "IoT Device Control",
    description: "Control smart home devices and IoT systems",
    cost: 44.99,
    permanentUID: "SPARK2_IOT_UPGRADE_001",
    unlocked: false,
    features: ["Device Control", "Automation Rules", "Remote Access"],
  },
];

export default function Spark2Manager() {
  const [device, setDevice] = useState<Spark2Device | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null);
  const [upgrades, setUpgrades] = useState<Spark2Upgrade[]>(SPARK2_UPGRADES);
  const [capabilities, setCapabilities] = useState<Spark2Capability[]>(SPARK2_CAPABILITIES);
  const [activeTab, setActiveTab] = useState("overview");
  const [upgradeInProgress, setUpgradeInProgress] = useState<string | null>(null);

  // Scan for Spark 2 devices
  const scanForDevices = async () => {
    setIsScanning(true);
    try {
      // Initialize NFC Manager
      const devices = await nfcManager.initialize();
      if (devices.length === 0) {
        console.error("No NFC devices available");
        setIsScanning(false);
        return;
      }

      // Connect to first available device
      const connected = await nfcManager.connect(devices[0].id);
      if (!connected) {
        console.error("Failed to connect to device");
        setIsScanning(false);
        return;
      }

      // Scan for Spark 2 tag
      const tag = await nfcManager.scanTag();
      if (tag) {
        const newDevice: Spark2Device = {
          uid: tag.uid,
          name: `VivoKey Spark 2 (${tag.uid.substring(0, 8)})`,
          detected: true,
          connected: true,
          battery: 85,
          firmwareVersion: "2.1.0",
          capabilities: SPARK2_CAPABILITIES,
          upgrades: SPARK2_UPGRADES,
        };

        setDevice(newDevice);
        setIsConnected(true);
      }
    } catch (error) {
      console.error("Scan error:", error);
    } finally {
      setIsScanning(false);
    }
  };

  // Apply permanent UID-based upgrade
  const applyUpgrade = async (upgradeId: string) => {
    if (!device) return;

    setUpgradeInProgress(upgradeId);
    try {
      const upgrade = upgrades.find((u) => u.id === upgradeId);
      if (!upgrade) return;

      // Step 1: Write permanent UID to chip
      const uidBytes = new TextEncoder().encode(upgrade.permanentUID);
      const success = await nfcManager.writeSector(0, uidBytes);

      if (!success) {
        console.error("Failed to write upgrade UID");
        setUpgradeInProgress(null);
        return;
      }

      // Step 2: Update local upgrade status
      const updatedUpgrades = upgrades.map((u) =>
        u.id === upgradeId ? { ...u, unlocked: true } : u
      );
      setUpgrades(updatedUpgrades);

      // Step 3: Update device capabilities
      const updatedCapabilities = capabilities.map((c) => {
        if (upgrade.features.includes(c.name)) {
          return { ...c, enabled: true };
        }
        return c;
      });
      setCapabilities(updatedCapabilities);

      // Step 4: Update device
      if (device) {
        setDevice({
          ...device,
          upgrades: updatedUpgrades,
          capabilities: updatedCapabilities,
        });
      }

      console.log(`Upgrade ${upgradeId} applied successfully`);
    } catch (error) {
      console.error("Upgrade error:", error);
    } finally {
      setUpgradeInProgress(null);
    }
  };

  // Backup device configuration
  const backupConfiguration = async () => {
    if (!device) return;

    const backup = {
      uid: device.uid,
      timestamp: new Date().toISOString(),
      firmwareVersion: device.firmwareVersion,
      upgrades: upgrades,
      capabilities: capabilities,
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `spark2-backup-${device.uid.substring(0, 8)}.json`;
    a.click();
  };

  // Restore device configuration
  const restoreConfiguration = async (file: File) => {
    try {
      const text = await file.text();
      const backup = JSON.parse(text);

      // Verify backup matches device
      if (backup.uid !== device?.uid) {
        console.error("Backup UID does not match device");
        return;
      }

      // Restore upgrades
      setUpgrades(backup.upgrades);
      setCapabilities(backup.capabilities);

      // Update device
      if (device) {
        setDevice({
          ...device,
          upgrades: backup.upgrades,
          capabilities: backup.capabilities,
        });
      }

      console.log("Configuration restored successfully");
    } catch (error) {
      console.error("Restore error:", error);
    }
  };

  // Get upgrade status
  const getUpgradeStatus = (upgrade: Spark2Upgrade) => {
    if (upgrade.unlocked) {
      return { label: "Unlocked", color: "bg-green-500", icon: CheckCircle };
    }
    return { label: "Locked", color: "bg-gray-500", icon: Lock };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Smartphone className="w-8 h-8 text-cyan-400" />
            <h1 className="text-3xl font-bold text-white">VivoKey Spark 2 Manager</h1>
          </div>
          <p className="text-slate-400">
            Manage your VivoKey Spark 2 implant with permanent UID-based capability upgrades
          </p>
        </div>

        {/* Device Status */}
        {device ? (
          <Card className="mb-8 bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-green-400" />
                Device Connected
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-slate-400 text-sm">UID</p>
                  <p className="text-white font-mono text-lg">{device.uid}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Firmware</p>
                  <p className="text-white font-mono">{device.firmwareVersion}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Battery</p>
                  <p className="text-white font-mono">{device.battery}%</p>
                </div>
                <div>
                  <p className="text-slate-400 text-sm">Status</p>
                  <Badge className="bg-green-500">Connected</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="mb-8 bg-slate-800 border-slate-700">
            <CardContent className="pt-6">
              <Button
                onClick={scanForDevices}
                disabled={isScanning}
                className="w-full bg-cyan-500 hover:bg-cyan-600"
              >
                {isScanning ? "Scanning..." : "Scan for Device"}
              </Button>
            </CardContent>
          </Card>
        )}

        {device && (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="bg-slate-800 border-slate-700">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="upgrades">Upgrades</TabsTrigger>
              <TabsTrigger value="capabilities">Capabilities</TabsTrigger>
              <TabsTrigger value="backup">Backup & Restore</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Device Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-slate-400">Device Name</Label>
                    <p className="text-white">{device.name}</p>
                  </div>
                  <div>
                    <Label className="text-slate-400">UID</Label>
                    <p className="text-white font-mono">{device.uid}</p>
                  </div>
                  <div>
                    <Label className="text-slate-400">Firmware Version</Label>
                    <p className="text-white">{device.firmwareVersion}</p>
                  </div>
                  <div>
                    <Label className="text-slate-400">Upgrades Applied</Label>
                    <p className="text-white">
                      {upgrades.filter((u) => u.unlocked).length} / {upgrades.length}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Upgrades Tab */}
            <TabsContent value="upgrades" className="space-y-4">
              <div className="grid gap-4">
                {upgrades.map((upgrade) => {
                  const status = getUpgradeStatus(upgrade);
                  const StatusIcon = status.icon;

                  return (
                    <Card key={upgrade.id} className="bg-slate-800 border-slate-700">
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-white font-semibold">{upgrade.name}</h3>
                              <Badge className={`${status.color} text-white`}>
                                {status.label}
                              </Badge>
                            </div>
                            <p className="text-slate-400 text-sm mb-3">{upgrade.description}</p>
                            <div className="flex flex-wrap gap-2">
                              {upgrade.features.map((feature) => (
                                <Badge key={feature} variant="outline" className="text-cyan-400">
                                  {feature}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="text-right ml-4">
                            <p className="text-white font-semibold mb-2">${upgrade.cost}</p>
                            <Button
                              onClick={() => applyUpgrade(upgrade.id)}
                              disabled={upgrade.unlocked || upgradeInProgress === upgrade.id}
                              className={
                                upgrade.unlocked
                                  ? "bg-gray-600"
                                  : "bg-cyan-500 hover:bg-cyan-600"
                              }
                            >
                              {upgradeInProgress === upgrade.id ? (
                                "Applying..."
                              ) : upgrade.unlocked ? (
                                <>
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                  Unlocked
                                </>
                              ) : (
                                <>
                                  <Unlock className="w-4 h-4 mr-2" />
                                  Unlock
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            {/* Capabilities Tab */}
            <TabsContent value="capabilities" className="space-y-4">
              <div className="grid gap-4">
                {capabilities.map((capability) => (
                  <Card key={capability.id} className="bg-slate-800 border-slate-700">
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="text-white font-semibold">{capability.name}</h3>
                            {capability.enabled ? (
                              <Badge className="bg-green-500">Enabled</Badge>
                            ) : (
                              <Badge className="bg-gray-500">Disabled</Badge>
                            )}
                          </div>
                          <p className="text-slate-400 text-sm">{capability.description}</p>
                          <p className="text-slate-500 text-xs mt-2 font-mono">
                            UID: {capability.permanentUID}
                          </p>
                        </div>
                        <div>
                          {capability.enabled ? (
                            <Zap className="w-6 h-6 text-yellow-400" />
                          ) : (
                            <Lock className="w-6 h-6 text-slate-500" />
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Backup & Restore Tab */}
            <TabsContent value="backup" className="space-y-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Backup & Restore</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      Backup Configuration
                    </h3>
                    <p className="text-slate-400 text-sm mb-4">
                      Download your device configuration including all upgrades and capabilities
                    </p>
                    <Button
                      onClick={backupConfiguration}
                      className="bg-cyan-500 hover:bg-cyan-600"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Backup
                    </Button>
                  </div>

                  <div className="border-t border-slate-700 pt-4">
                    <h3 className="text-white font-semibold mb-2 flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Restore Configuration
                    </h3>
                    <p className="text-slate-400 text-sm mb-4">
                      Restore a previously backed up configuration
                    </p>
                    <Input
                      type="file"
                      accept=".json"
                      onChange={(e) => {
                        if (e.target.files?.[0]) {
                          restoreConfiguration(e.target.files[0]);
                        }
                      }}
                      className="bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}
