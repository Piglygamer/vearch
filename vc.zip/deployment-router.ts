import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { nfcHandler } from "./nfc-communication";
import { executePaymentFlow, getPaymentStatus } from "./payment-flow";
import { recordDeployment, updateDeploymentStatus } from "./applet-db";

export const deploymentRouter = router({
  /**
   * NFC DEPLOYMENT OPERATIONS
   */

  /**
   * Deploy applet to user's chip
   */
  deployApplet: protectedProcedure
    .input(
      z.object({
        chipUid: z.string(),
        appletBytecode: z.instanceof(Buffer),
        appletAid: z.string(), // Application Identifier
        appletName: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        // Record deployment in database
        const deployment = await recordDeployment({
          chipId: 0, // Would be looked up from chipUid
          appletId: 0, // Would be looked up from appletAid
          action: "install",
          toVersion: "1.0.0",
          status: "in_progress",
        });

        if (!deployment) {
          throw new Error("Failed to record deployment");
        }

        // Deploy via NFC
        const result = await nfcHandler.deployApplet(
          input.appletBytecode,
          input.appletAid,
          input.appletName
        );

        // Update deployment status
        await updateDeploymentStatus(
          deployment.id,
          result.success ? "success" : "failed",
          result.success ? undefined : result.message
        );

        return {
          success: result.success,
          deploymentId: deployment.id,
          message: result.message,
          txHash: result.txHash,
        };
      } catch (error) {
        return {
          success: false,
          message: error instanceof Error ? error.message : "Deployment failed",
        };
      }
    }),

  /**
   * Execute command on applet
   */
  executeAppletCommand: protectedProcedure
    .input(
      z.object({
        chipUid: z.string(),
        appletAid: z.string(),
        command: z.string(),
        commandData: z.instanceof(Buffer).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Initialize NFC connection
        const connected = await nfcHandler.initializeConnection(input.chipUid);
        if (!connected) {
          throw new Error("Failed to connect to chip");
        }

        // Execute command
        const result = await nfcHandler.executeAppletCommand(
          input.appletAid,
          input.command,
          input.commandData
        );

        return {
          success: result.success,
          response: result.response.toString("hex"),
          statusWord: result.statusWord,
        };
      } catch (error) {
        return {
          success: false,
          response: "",
          statusWord: "6F00",
          error: error instanceof Error ? error.message : "Command failed",
        };
      }
    }),

  /**
   * PAYMENT FLOW OPERATIONS
   */

  /**
   * Execute complete payment flow
   * User taps chip → Biometric verification → Stripe payment → Wallet update
   */
  processPayment: protectedProcedure
    .input(
      z.object({
        chipUid: z.string(),
        amount: z.number().positive(),
        currency: z.string(),
        merchantId: z.string(),
        biometricData: z.instanceof(Buffer),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const result = await executePaymentFlow({
          chipUid: input.chipUid,
          amount: input.amount,
          currency: input.currency,
          merchantId: input.merchantId,
          biometricData: input.biometricData,
          description: input.description,
        });

        return {
          success: result.success,
          transactionId: result.transactionId,
          stripePaymentIntentId: result.stripePaymentIntentId,
          message: result.message,
          timestamp: result.timestamp,
        };
      } catch (error) {
        return {
          success: false,
          message: error instanceof Error ? error.message : "Payment failed",
          timestamp: new Date(),
        };
      }
    }),

  /**
   * Get payment status
   */
  getPaymentStatus: protectedProcedure
    .input(z.object({ transactionId: z.number() }))
    .query(async ({ input }) => {
      return getPaymentStatus(input.transactionId);
    }),

  /**
   * Get deployment status
   */
  getDeploymentStatus: protectedProcedure
    .input(z.object({ deploymentId: z.number() }))
    .query(async ({ input }) => {
      // Would query deployment history from database
      return {
        deploymentId: input.deploymentId,
        status: "completed",
        message: "Applet deployed successfully",
      };
    }),
});

export type DeploymentRouter = typeof deploymentRouter;
