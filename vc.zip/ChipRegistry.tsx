import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Plus, Trash2, Edit2, Eye } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function ChipRegistry() {
  const [, navigate] = useLocation();
  const [chips, setChips] = useState([
    {
      id: 1,
      name: "My xM1 gen2",
      type: "xM1 gen2",
      uid: "A1B2C3D4",
      location: "Left hand (webbing)",
      installDate: "2024-03-15",
      status: "Active",
      notes: "Access control for office building",
    },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    type: "xM1 gen2",
    uid: "",
    location: "",
    notes: "",
  });

  const handleAddChip = () => {
    if (formData.name && formData.uid) {
      setChips([
        ...chips,
        {
          id: chips.length + 1,
          ...formData,
          installDate: new Date().toISOString().split("T")[0],
          status: "Active",
        },
      ]);
      setFormData({ name: "", type: "xM1 gen2", uid: "", location: "", notes: "" });
      setShowForm(false);
    }
  };

  const handleDeleteChip = (id: number) => {
    setChips(chips.filter((c) => c.id !== id));
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "xM1 gen2":
        return "bg-blue-900/30 text-blue-300 border-blue-700";
      case "VivoKey Spark 2":
        return "bg-emerald-900/30 text-emerald-300 border-emerald-700";
      case "Apex Flex":
        return "bg-purple-900/30 text-purple-300 border-purple-700";
      default:
        return "bg-slate-900/30 text-slate-300 border-slate-700";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate("/")}
              className="text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-white">Chip Registry</h1>
              <p className="text-sm text-slate-400">Manage your implants</p>
            </div>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-blue-600 hover:bg-blue-700 gap-2"
          >
            <Plus className="w-4 h-4" />
            Register Chip
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {/* Add Chip Form */}
        {showForm && (
          <Card className="mb-8 border-slate-700 bg-slate-800/50">
            <CardHeader>
              <CardTitle className="text-white">Register New Chip</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Chip Name
                  </label>
                  <Input
                    placeholder="e.g., My xM1 gen2"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Chip Type
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) =>
                      setFormData({ ...formData, type: e.target.value })
                    }
                    className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-md"
                  >
                    <option>xM1 gen2</option>
                    <option>VivoKey Spark 2</option>
                    <option>Apex Flex</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    UID/Serial
                  </label>
                  <Input
                    placeholder="e.g., A1B2C3D4"
                    value={formData.uid}
                    onChange={(e) =>
                      setFormData({ ...formData, uid: e.target.value })
                    }
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Installation Location
                  </label>
                  <Input
                    placeholder="e.g., Left hand (webbing)"
                    value={formData.location}
                    onChange={(e) =>
                      setFormData({ ...formData, location: e.target.value })
                    }
                    className="bg-slate-700/50 border-slate-600 text-white"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Notes
                </label>
                <textarea
                  placeholder="Any additional notes about this chip..."
                  value={formData.notes}
                  onChange={(e) =>
                    setFormData({ ...formData, notes: e.target.value })
                  }
                  className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 text-white rounded-md"
                  rows={3}
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleAddChip}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Register Chip
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setShowForm(false)}
                  className="border-slate-600 text-slate-300"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Chips Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {chips.map((chip) => (
            <Card
              key={chip.id}
              className="border-slate-700 bg-slate-800/50 hover:border-slate-600 transition-colors"
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-white">{chip.name}</CardTitle>
                    <Badge className={`mt-2 ${getTypeColor(chip.type)}`}>
                      {chip.type}
                    </Badge>
                  </div>
                  <Badge variant="outline" className="border-green-700 text-green-400">
                    {chip.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-slate-400">UID</p>
                    <p className="text-white font-mono">{chip.uid}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Location</p>
                    <p className="text-white">{chip.location}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Install Date</p>
                    <p className="text-white">{chip.installDate}</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Days Active</p>
                    <p className="text-white">
                      {Math.floor(
                        (new Date().getTime() -
                          new Date(chip.installDate).getTime()) /
                          (1000 * 60 * 60 * 24)
                      )}
                    </p>
                  </div>
                </div>

                {chip.notes && (
                  <div>
                    <p className="text-slate-400 text-sm mb-1">Notes</p>
                    <p className="text-slate-300 text-sm">{chip.notes}</p>
                  </div>
                )}

                <div className="flex gap-2 pt-4 border-t border-slate-700">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-slate-600 text-slate-300 flex-1 gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    View Details
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-slate-600 text-slate-300 gap-2"
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-red-700/50 text-red-400 hover:bg-red-900/20 gap-2"
                    onClick={() => handleDeleteChip(chip.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Empty State */}
        {chips.length === 0 && !showForm && (
          <Card className="border-slate-700 bg-slate-800/50 text-center py-12">
            <div className="text-slate-400 mb-4">
              <Eye className="w-12 h-12 mx-auto opacity-50" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">
              No chips registered yet
            </h3>
            <p className="text-slate-400 mb-6">
              Start by registering your first biohacking implant
            </p>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Register Your First Chip
            </Button>
          </Card>
        )}

        {/* Registry Statistics */}
        <section className="grid md:grid-cols-3 gap-6">
          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">
                  {chips.length}
                </div>
                <p className="text-slate-400 mt-2">Chips Registered</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-400">
                  {chips.filter((c) => c.status === "Active").length}
                </div>
                <p className="text-slate-400 mt-2">Active Implants</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-400">
                  {new Set(chips.map((c) => c.type)).size}
                </div>
                <p className="text-slate-400 mt-2">Chip Types</p>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
