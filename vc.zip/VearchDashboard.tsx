import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Smartphone,
  Zap,
  Settings,
  LogOut,
  LayoutDashboard,
  Cpu,
  Lock,
  TrendingUp,
  Plus,
  ChevronDown,
  Wifi,
  Battery,
  ArrowUpRight,
  ArrowDownLeft,
} from "lucide-react";

export default function VearchDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [implants] = useState([
    {
      id: "spark2-001",
      name: "VivoKey Spark 2",
      uid: "A1B2C3D4",
      status: "connected",
      battery: 85,
      upgrades: 3,
    },
    {
      id: "magic-001",
      name: "Magic Chip xM1",
      uid: "E5F6G7H8",
      status: "paired",
      battery: 92,
      upgrades: 1,
    },
  ]);

  const [transactions] = useState([
    {
      id: 1,
      merchant: "Starbucks",
      amount: "$4.50",
      date: "Today, 2:30 PM",
      status: "completed",
    },
    {
      id: 2,
      merchant: "Whole Foods",
      amount: "$32.15",
      date: "Yesterday, 5:45 PM",
      status: "completed",
    },
  ]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-blue-500">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white">Vearch CHIP</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <Settings className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-slate-400 hover:text-white">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="bg-slate-800 border border-slate-700">
            <TabsTrigger value="overview" className="gap-2">
              <LayoutDashboard className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="implants" className="gap-2">
              <Cpu className="h-4 w-4" />
              Implants
            </TabsTrigger>
            <TabsTrigger value="upgrades" className="gap-2">
              <Lock className="h-4 w-4" />
              Upgrades
            </TabsTrigger>
            <TabsTrigger value="activity" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              Activity
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">
                    Active Implants
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">{implants.length}</div>
                  <p className="text-xs text-slate-500 mt-1">All connected</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">
                    Total Upgrades
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">
                    {implants.reduce((sum, i) => sum + i.upgrades, 0)}
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Deployed</p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800 border-slate-700">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-slate-400">
                    Transactions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-white">{transactions.length}</div>
                  <p className="text-xs text-slate-500 mt-1">This month</p>
                </CardContent>
              </Card>
            </div>

            {/* Implants Overview */}
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Your Implants</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {implants.map((implant) => (
                  <div
                    key={implant.id}
                    className="flex items-center justify-between p-4 rounded-lg bg-slate-700/50 border border-slate-600"
                  >
                    <div className="flex items-center gap-4">
                      <Smartphone className="h-6 w-6 text-cyan-400" />
                      <div>
                        <p className="font-medium text-white">{implant.name}</p>
                        <p className="text-sm text-slate-400">UID: {implant.uid}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-2">
                        <Battery className="h-4 w-4 text-green-400" />
                        <span className="text-sm text-slate-300">{implant.battery}%</span>
                      </div>
                      <Badge
                        variant={implant.status === "connected" ? "default" : "secondary"}
                        className="gap-1"
                      >
                        <Wifi className="h-3 w-3" />
                        {implant.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Implants Tab */}
          <TabsContent value="implants" className="space-y-6">
            <Button className="gap-2 bg-cyan-500 hover:bg-cyan-600">
              <Plus className="h-4 w-4" />
              Link New Implant
            </Button>

            <div className="space-y-4">
              {implants.map((implant) => (
                <Card key={implant.id} className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">{implant.name}</CardTitle>
                      <Badge>{implant.upgrades} upgrades</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-slate-400">UID</p>
                        <p className="text-white font-mono">{implant.uid}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-400">Status</p>
                        <p className="text-white capitalize">{implant.status}</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-400">Battery</p>
                        <p className="text-white">{implant.battery}%</p>
                      </div>
                      <div>
                        <p className="text-sm text-slate-400">Type</p>
                        <p className="text-white">{implant.name.split(" ")[0]}</p>
                      </div>
                    </div>
                    <Button className="w-full bg-slate-700 hover:bg-slate-600">
                      Manage
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Upgrades Tab */}
          <TabsContent value="upgrades" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { name: "Authentication", icon: Lock, status: "active" },
                { name: "Payment", icon: Zap, status: "active" },
                { name: "Identity", icon: Smartphone, status: "inactive" },
                { name: "Storage", icon: Lock, status: "inactive" },
              ].map((upgrade) => (
                <Card key={upgrade.name} className="bg-slate-800 border-slate-700">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <upgrade.icon className="h-5 w-5 text-cyan-400" />
                        <CardTitle className="text-white">{upgrade.name}</CardTitle>
                      </div>
                      <Badge
                        variant={upgrade.status === "active" ? "default" : "secondary"}
                      >
                        {upgrade.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Button className="w-full bg-slate-700 hover:bg-slate-600">
                      {upgrade.status === "active" ? "Manage" : "Deploy"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white">Recent Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {transactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-slate-700/50 border border-slate-600"
                    >
                      <div className="flex items-center gap-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-cyan-500/20">
                          <ArrowUpRight className="h-5 w-5 text-cyan-400" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{tx.merchant}</p>
                          <p className="text-sm text-slate-400">{tx.date}</p>
                        </div>
                      </div>
                      <p className="font-semibold text-white">{tx.amount}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
