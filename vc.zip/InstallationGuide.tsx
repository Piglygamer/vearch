import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, AlertCircle, CheckCircle2, Clock, Syringe } from "lucide-react";
import { useLocation } from "wouter";

export default function InstallationGuide() {
  const [, navigate] = useLocation();

  const procedures = [
    {
      chip: "xM1 gen2",
      method: "Injection",
      depth: "Subcutaneous (under skin)",
      location: "Webbing between thumb & index finger",
      duration: "15-30 minutes",
      pain: "Moderate (local anesthetic provided)",
      healing: "7-14 days",
      steps: [
        "Professional applies local anesthetic (lidocaine)",
        "Skin is cleaned with antiseptic solution",
        "Small incision made using sterile needle",
        "Chip implant inserted into subcutaneous layer",
        "Incision closed with sterile adhesive or sutures",
        "Sterile bandage applied",
      ],
    },
    {
      chip: "VivoKey Spark 2",
      method: "Injection",
      depth: "Subcutaneous (under skin)",
      location: "Webbing between thumb & index finger",
      duration: "15-30 minutes",
      pain: "Moderate (local anesthetic provided)",
      healing: "7-14 days",
      steps: [
        "Professional applies local anesthetic (lidocaine)",
        "Skin is cleaned with antiseptic solution",
        "Small incision made using sterile needle",
        "Pre-sterilized Spark 2 injector assembly used",
        "Chip deployed into subcutaneous layer",
        "Incision closed with sterile adhesive or sutures",
        "Sterile bandage applied",
      ],
    },
    {
      chip: "Apex Flex",
      method: "Scalpel or Needle",
      depth: "Subcutaneous (under skin)",
      location: "Forearm or hand (varies by antenna)",
      duration: "30-60 minutes",
      pain: "Moderate to high (local anesthetic provided)",
      healing: "14-21 days",
      steps: [
        "Professional applies local anesthetic (lidocaine)",
        "Skin is cleaned with antiseptic solution",
        "Small incision made using sterile scalpel or needle",
        "Pocket created in subcutaneous layer",
        "Apex Flex implant carefully positioned",
        "Incision closed with sterile sutures",
        "Sterile bandage and compression applied",
      ],
    },
  ];

  const aftercare = [
    {
      timeframe: "First 24 Hours",
      tasks: [
        "Keep bandage clean and dry",
        "Avoid touching or moving the implant",
        "Take prescribed pain medication as needed",
        "Apply ice packs (15 min on, 15 min off) to reduce swelling",
        "Elevate hand above heart level",
        "Avoid strenuous activities",
      ],
    },
    {
      timeframe: "Days 2-7",
      tasks: [
        "Change bandage daily with sterile supplies",
        "Clean incision with sterile saline solution",
        "Apply antibiotic ointment if recommended",
        "Continue ice therapy as needed",
        "Avoid water (no swimming, long showers)",
        "Wear compression glove if provided",
        "Monitor for signs of infection",
      ],
    },
    {
      timeframe: "Weeks 2-4",
      tasks: [
        "Gradually increase hand activity",
        "Continue keeping incision clean",
        "Remove sutures if applicable (follow professional's schedule)",
        "Avoid heavy lifting or gripping",
        "Monitor healing progress",
        "Schedule follow-up appointment if needed",
        "Begin gentle range-of-motion exercises",
      ],
    },
    {
      timeframe: "Month 2+",
      tasks: [
        "Resume normal activities gradually",
        "Scar tissue will continue to mature",
        "Implant should be fully healed",
        "Can resume sports and strenuous activities",
        "Maintain regular check-ups",
        "Monitor for any complications",
      ],
    },
  ];

  const warnings = [
    {
      title: "Infection Signs",
      items: [
        "Increased redness or warmth",
        "Pus or discharge",
        "Fever or chills",
        "Severe pain or swelling",
        "Red streaks extending from incision",
      ],
      action: "Contact healthcare provider immediately",
    },
    {
      title: "Rejection Signs",
      items: [
        "Implant moving or shifting",
        "Persistent pain after healing",
        "Skin breakdown over implant",
        "Chronic inflammation",
        "Implant working intermittently",
      ],
      action: "Contact professional installer for evaluation",
    },
    {
      title: "Complications to Avoid",
      items: [
        "Do not submerge in water for first 2 weeks",
        "Avoid contact sports for 4 weeks",
        "Do not apply heat directly to incision",
        "Avoid tight bandaging that cuts off circulation",
        "Do not attempt to remove sutures yourself",
      ],
      action: "Follow all professional instructions carefully",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">Installation Guide</h1>
            <p className="text-sm text-slate-400">
              Professional procedures and aftercare
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        {/* Critical Warning */}
        <Card className="mb-8 border-red-700/50 bg-red-900/20">
          <CardContent className="pt-6 flex gap-4">
            <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-red-300 mb-2">
                Professional Installation Required
              </h3>
              <p className="text-red-200 text-sm">
                All biohacking implants must be installed by qualified professionals. Improper installation can result in infection, rejection, nerve damage, or other serious complications. Always seek professional installation partners certified by Dangerous Things or similar organizations.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Installation Procedures */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Installation Procedures</h2>

          <Tabs defaultValue="xm1" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-slate-700/50 mb-6">
              <TabsTrigger value="xm1">xM1 gen2</TabsTrigger>
              <TabsTrigger value="spark2">Spark 2</TabsTrigger>
              <TabsTrigger value="apex">Apex Flex</TabsTrigger>
            </TabsList>

            {procedures.map((proc, idx) => (
              <TabsContent key={idx} value={proc.chip.toLowerCase().replace(/\s/g, "")}>
                <Card className="border-slate-700 bg-slate-800/50">
                  <CardHeader>
                    <CardTitle className="text-white">{proc.chip}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Quick Stats */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg bg-slate-700/30">
                        <p className="text-slate-400 text-sm mb-1">Installation Method</p>
                        <p className="text-white font-semibold">{proc.method}</p>
                      </div>
                      <div className="p-4 rounded-lg bg-slate-700/30">
                        <p className="text-slate-400 text-sm mb-1">Duration</p>
                        <p className="text-white font-semibold">{proc.duration}</p>
                      </div>
                      <div className="p-4 rounded-lg bg-slate-700/30">
                        <p className="text-slate-400 text-sm mb-1">Pain Level</p>
                        <p className="text-white font-semibold">{proc.pain}</p>
                      </div>
                      <div className="p-4 rounded-lg bg-slate-700/30">
                        <p className="text-slate-400 text-sm mb-1">Healing Time</p>
                        <p className="text-white font-semibold">{proc.healing}</p>
                      </div>
                    </div>

                    {/* Location */}
                    <div>
                      <h4 className="font-semibold text-white mb-2">Installation Location</h4>
                      <p className="text-slate-300">{proc.location}</p>
                      <p className="text-slate-400 text-sm mt-2">
                        Depth: <span className="text-slate-300">{proc.depth}</span>
                      </p>
                    </div>

                    {/* Steps */}
                    <div>
                      <h4 className="font-semibold text-white mb-4">Installation Steps</h4>
                      <ol className="space-y-3">
                        {proc.steps.map((step, stepIdx) => (
                          <li key={stepIdx} className="flex gap-3">
                            <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-600 text-white text-sm flex items-center justify-center font-semibold">
                              {stepIdx + 1}
                            </span>
                            <span className="text-slate-300 pt-0.5">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </section>

        {/* Aftercare */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Aftercare Timeline</h2>

          <div className="space-y-4">
            {aftercare.map((phase, idx) => (
              <Card key={idx} className="border-slate-700 bg-slate-800/50">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-blue-400" />
                    <CardTitle className="text-white">{phase.timeframe}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {phase.tasks.map((task, taskIdx) => (
                      <li key={taskIdx} className="flex items-start gap-2 text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        {task}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Warnings */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Important Warnings</h2>

          <div className="grid md:grid-cols-3 gap-6">
            {warnings.map((warning, idx) => (
              <Card
                key={idx}
                className="border-red-700/50 bg-red-900/20"
              >
                <CardHeader>
                  <CardTitle className="text-red-300 text-lg">
                    {warning.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {warning.items.map((item, itemIdx) => (
                      <li key={itemIdx} className="flex items-start gap-2 text-red-200 text-sm">
                        <span className="text-red-400 font-bold mt-0.5">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                  <div className="pt-4 border-t border-red-700/30">
                    <p className="text-red-300 font-semibold text-sm">
                      {warning.action}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Pre-Installation Checklist */}
        <section className="bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border border-blue-800/50 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-white mb-6">Pre-Installation Checklist</h2>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-blue-300 mb-4">Before Your Appointment</h3>
              <ul className="space-y-2">
                {[
                  "Schedule with certified professional",
                  "Verify installer credentials",
                  "Discuss chip type and location",
                  "Review aftercare instructions",
                  "Arrange transportation home",
                  "Avoid blood thinners (7 days before)",
                  "Get adequate sleep",
                  "Eat a healthy meal before appointment",
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-blue-300 mb-4">Bring to Appointment</h3>
              <ul className="space-y-2">
                {[
                  "Valid ID and insurance card",
                  "List of current medications",
                  "Allergy information",
                  "Emergency contact",
                  "Comfortable clothing",
                  "Compression glove (if provided)",
                  "Pain medication (if approved)",
                  "Someone to drive you home",
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
