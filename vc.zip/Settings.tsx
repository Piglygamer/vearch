import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

/**
 * Real Settings & Preferences Panel
 * User account management, preferences, and settings
 */

export default function Settings() {
  const [activeTab, setActiveTab] = useState("profile");

  // Get current user
  const { data: user } = trpc.auth.me.useQuery();

  // Get preferences
  const { data: preferences = {} } = trpc.auth.getPreferences.useQuery();

  // Mutations
  const updateProfile = trpc.auth.updateProfile.useMutation({
    onSuccess: () => {
      toast.success("Profile updated successfully");
    },
    onError: (error) => {
      toast.error(`Failed to update profile: ${error.message}`);
    },
  });

  const updatePreferences = trpc.auth.updatePreferences.useMutation({
    onSuccess: () => {
      toast.success("Preferences saved successfully");
    },
    onError: (error) => {
      toast.error(`Failed to save preferences: ${error.message}`);
    },
  });

  const logout = trpc.auth.logout.useMutation({
    onSuccess: () => {
      toast.success("Logged out successfully");
      // Redirect to home
      window.location.href = "/";
    },
  });

  // Form state
  const [profileForm, setProfileForm] = useState({
    name: user?.name || "",
    email: user?.email || "",
  });

  const [preferencesForm, setPreferencesForm] = useState({
    theme: preferences.theme || "dark",
    notifications: preferences.notifications !== false,
    defaultCurrency: preferences.defaultCurrency || "USD",
    language: preferences.language || "en",
  });

  // Update form when user data loads
  useEffect(() => {
    if (user) {
      setProfileForm({
        name: user.name || "",
        email: user.email || "",
      });
    }
  }, [user]);

  useEffect(() => {
    setPreferencesForm({
      theme: preferences.theme || "dark",
      notifications: preferences.notifications !== false,
      defaultCurrency: preferences.defaultCurrency || "USD",
      language: preferences.language || "en",
    });
  }, [preferences]);

  const handleUpdateProfile = () => {
    updateProfile.mutate({
      name: profileForm.name,
      email: profileForm.email,
    });
  };

  const handleUpdatePreferences = () => {
    updatePreferences.mutate({
      theme: preferencesForm.theme as any,
      notifications: preferencesForm.notifications,
      defaultCurrency: preferencesForm.defaultCurrency,
      language: preferencesForm.language,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Settings</h1>
          <p className="text-slate-400">Manage your account and preferences</p>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800 border border-slate-700">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700 p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Profile Information</h2>

              <div className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Full Name</label>
                  <Input
                    type="text"
                    value={profileForm.name}
                    onChange={(e) =>
                      setProfileForm({ ...profileForm, name: e.target.value })
                    }
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Email</label>
                  <Input
                    type="email"
                    value={profileForm.email}
                    onChange={(e) =>
                      setProfileForm({ ...profileForm, email: e.target.value })
                    }
                    className="bg-slate-700 border-slate-600 text-white"
                  />
                </div>

                {/* Member Since */}
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Member Since</label>
                  <p className="text-white">
                    {user?.createdAt
                      ? new Date(user.createdAt).toLocaleDateString()
                      : "Unknown"}
                  </p>
                </div>

                {/* Save Button */}
                <Button
                  onClick={handleUpdateProfile}
                  disabled={updateProfile.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {updateProfile.isPending ? "Saving..." : "Save Profile"}
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Preferences Tab */}
          <TabsContent value="preferences" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700 p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Preferences</h2>

              <div className="space-y-4">
                {/* Theme */}
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Theme</label>
                  <select
                    value={preferencesForm.theme}
                    onChange={(e) =>
                      setPreferencesForm({ ...preferencesForm, theme: e.target.value })
                    }
                    className="w-full bg-slate-700 border border-slate-600 text-white px-3 py-2 rounded-md"
                  >
                    <option value="light">Light</option>
                    <option value="dark">Dark</option>
                  </select>
                </div>

                {/* Currency */}
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Default Currency</label>
                  <select
                    value={preferencesForm.defaultCurrency}
                    onChange={(e) =>
                      setPreferencesForm({
                        ...preferencesForm,
                        defaultCurrency: e.target.value,
                      })
                    }
                    className="w-full bg-slate-700 border border-slate-600 text-white px-3 py-2 rounded-md"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                    <option value="CAD">CAD (C$)</option>
                  </select>
                </div>

                {/* Language */}
                <div>
                  <label className="block text-sm text-slate-300 mb-2">Language</label>
                  <select
                    value={preferencesForm.language}
                    onChange={(e) =>
                      setPreferencesForm({ ...preferencesForm, language: e.target.value })
                    }
                    className="w-full bg-slate-700 border border-slate-600 text-white px-3 py-2 rounded-md"
                  >
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="fr">Français</option>
                    <option value="de">Deutsch</option>
                  </select>
                </div>

                {/* Notifications */}
                <div className="flex items-center">
                  <label className="flex items-center text-slate-300">
                    <input
                      type="checkbox"
                      checked={preferencesForm.notifications}
                      onChange={(e) =>
                        setPreferencesForm({
                          ...preferencesForm,
                          notifications: e.target.checked,
                        })
                      }
                      className="mr-2"
                    />
                    Enable Notifications
                  </label>
                </div>

                {/* Save Button */}
                <Button
                  onClick={handleUpdatePreferences}
                  disabled={updatePreferences.isPending}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  {updatePreferences.isPending ? "Saving..." : "Save Preferences"}
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Security Tab */}
          <TabsContent value="security" className="space-y-6">
            <Card className="bg-slate-800 border-slate-700 p-6">
              <h2 className="text-xl font-semibold text-white mb-4">Security</h2>

              <div className="space-y-4">
                {/* Session Info */}
                <div className="bg-slate-700 rounded-lg p-4 mb-4">
                  <p className="text-sm text-slate-400 mb-2">Active Session</p>
                  <p className="text-white font-semibold">{user?.email}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    Role: {user?.role || "user"}
                  </p>
                </div>

                {/* Logout Button */}
                <Button
                  onClick={() => logout.mutate()}
                  disabled={logout.isPending}
                  variant="outline"
                  className="w-full text-red-500 border-red-500 hover:bg-red-500/10"
                >
                  {logout.isPending ? "Logging out..." : "Logout"}
                </Button>

                {/* Delete Account */}
                <div className="pt-4 border-t border-slate-700">
                  <p className="text-sm text-slate-400 mb-3">Danger Zone</p>
                  <Button
                    variant="outline"
                    className="w-full text-red-500 border-red-500 hover:bg-red-500/10"
                    onClick={() => {
                      if (
                        confirm(
                          "Are you sure? This action cannot be undone. All your data will be permanently deleted."
                        )
                      ) {
                        // TODO: Implement delete account
                        toast.error("Delete account not yet implemented");
                      }
                    }}
                  >
                    Delete Account
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
