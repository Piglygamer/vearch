import {
  int,
  varchar,
  text,
  timestamp,
  boolean,
  decimal,
  mysqlEnum,
  mysqlTable,
  uniqueIndex,
  index,
} from "drizzle-orm/mysql-core";

// ============================================================================
// USERS TABLE
// ============================================================================
export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    name: varchar("name", { length: 255 }),
    openId: varchar("openId", { length: 64 }).unique(),
    stripeCustomerId: varchar("stripe_customer_id", { length: 255 }),
    defaultPaymentMethodId: varchar("default_payment_method_id", { length: 255 }),
    role: mysqlEnum("role", ["user", "admin", "merchant"]).default("user"),
    createdAt: timestamp("created_at").defaultNow(),
    updatedAt: timestamp("updated_at").defaultNow().onUpdateNow(),
  },
  (table) => ({
    emailIdx: uniqueIndex("email_idx").on(table.email),
    openIdIdx: index("openId_idx").on(table.openId),
  })
);

// ============================================================================
// IMPLANTS TABLE
// ============================================================================
export const implants = mysqlTable(
  "implants",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id").notNull(),
    uid: varchar("uid", { length: 64 }).notNull().unique(),
    type: mysqlEnum("type", ["spark2", "magic", "apex", "other"]).default("other"),
    name: varchar("name", { length: 100 }),
    status: mysqlEnum("status", ["active", "inactive", "paired", "connected"]).default("inactive"),
    battery: int("battery").default(100),
    upgrades: int("upgrades").default(0),
    linkedAt: timestamp("linked_at").defaultNow(),
    lastUsed: timestamp("last_used"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("user_id_idx").on(table.userId),
    uidIdx: uniqueIndex("uid_idx").on(table.uid),
  })
);

// ============================================================================
// PAYMENT METHODS TABLE
// ============================================================================
export const paymentMethods = mysqlTable(
  "payment_methods",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id").notNull(),
    stripePaymentMethodId: varchar("stripe_payment_method_id", { length: 255 }).notNull().unique(),
    brand: varchar("brand", { length: 50 }),
    last4: varchar("last4", { length: 4 }),
    expMonth: int("exp_month"),
    expYear: int("exp_year"),
    isDefault: boolean("is_default").default(false),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("user_id_idx").on(table.userId),
  })
);

// ============================================================================
// MERCHANTS TABLE
// ============================================================================
export const merchants = mysqlTable(
  "merchants",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    stripeAccountId: varchar("stripe_account_id", { length: 255 }).notNull().unique(),
    apiKeyHash: varchar("api_key_hash", { length: 255 }).notNull(),
    apiKeyPrefix: varchar("api_key_prefix", { length: 10 }).notNull(),
    category: varchar("category", { length: 100 }),
    location: varchar("location", { length: 255 }),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    stripeAccountIdIdx: uniqueIndex("stripe_account_id_idx").on(table.stripeAccountId),
  })
);

// ============================================================================
// TRANSACTIONS TABLE
// ============================================================================
export const transactions = mysqlTable(
  "transactions",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id").notNull(),
    implantId: int("implant_id"),
    merchantId: int("merchant_id"),
    amountCents: int("amount_cents").notNull(),
    currency: varchar("currency", { length: 3 }).default("usd"),
    status: mysqlEnum("status", ["pending", "completed", "failed", "declined"]).default("pending"),
    stripePaymentIntentId: varchar("stripe_payment_intent_id", { length: 255 }),
    declineCode: varchar("decline_code", { length: 100 }),
    description: text("description"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("user_id_idx").on(table.userId),
    implantIdIdx: index("implant_id_idx").on(table.implantId),
    merchantIdIdx: index("merchant_id_idx").on(table.merchantId),
    statusIdx: index("status_idx").on(table.status),
  })
);

// ============================================================================
// IMPLANT UPGRADES TABLE
// ============================================================================
export const implantUpgrades = mysqlTable(
  "implant_upgrades",
  {
    id: int("id").autoincrement().primaryKey(),
    implantId: int("implant_id").notNull(),
    upgradeType: mysqlEnum("upgrade_type", [
      "authentication",
      "payment",
      "identity",
      "storage",
      "biometric",
      "iot",
    ]).notNull(),
    status: mysqlEnum("status", ["active", "inactive", "pending"]).default("active"),
    uid: varchar("uid", { length: 64 }),
    metadata: text("metadata"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    implantIdIdx: index("implant_id_idx").on(table.implantId),
  })
);

// ============================================================================
// APPLETS TABLE (for Apex Flex)
// ============================================================================
export const applets = mysqlTable(
  "applets",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    version: varchar("version", { length: 50 }).notNull(),
    description: text("description"),
    bytecode: text("bytecode").notNull(),
    fidesmoServiceId: varchar("fidesmo_service_id", { length: 255 }),
    type: mysqlEnum("type", ["payment", "identity", "custom"]).default("custom"),
    createdAt: timestamp("created_at").defaultNow(),
  }
);

// ============================================================================
// IMPLANT APPLETS TABLE
// ============================================================================
export const implantApplets = mysqlTable(
  "implant_applets",
  {
    id: int("id").autoincrement().primaryKey(),
    implantId: int("implant_id").notNull(),
    appletId: int("applet_id").notNull(),
    status: mysqlEnum("status", ["installed", "pending", "failed"]).default("pending"),
    deploymentId: varchar("deployment_id", { length: 255 }),
    installedAt: timestamp("installed_at"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    implantIdIdx: index("implant_id_idx").on(table.implantId),
    appletIdIdx: index("applet_id_idx").on(table.appletId),
  })
);

// ============================================================================
// OPERATION LOGS TABLE
// ============================================================================
export const operationLogs = mysqlTable(
  "operation_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("user_id").notNull(),
    implantId: int("implant_id"),
    operation: varchar("operation", { length: 100 }).notNull(),
    status: mysqlEnum("status", ["success", "failed"]).default("success"),
    details: text("details"),
    createdAt: timestamp("created_at").defaultNow(),
  },
  (table) => ({
    userIdIdx: index("user_id_idx").on(table.userId),
    implantIdIdx: index("implant_id_idx").on(table.implantId),
  })
);

// ============================================================================
// TYPE EXPORTS
// ============================================================================
export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type Implant = typeof implants.$inferSelect;
export type InsertImplant = typeof implants.$inferInsert;

export type PaymentMethod = typeof paymentMethods.$inferSelect;
export type InsertPaymentMethod = typeof paymentMethods.$inferInsert;

export type Merchant = typeof merchants.$inferSelect;
export type InsertMerchant = typeof merchants.$inferInsert;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

export type ImplantUpgrade = typeof implantUpgrades.$inferSelect;
export type InsertImplantUpgrade = typeof implantUpgrades.$inferInsert;

export type Applet = typeof applets.$inferSelect;
export type InsertApplet = typeof applets.$inferInsert;

export type ImplantApplet = typeof implantApplets.$inferSelect;
export type InsertImplantApplet = typeof implantApplets.$inferInsert;

export type OperationLog = typeof operationLogs.$inferSelect;
export type InsertOperationLog = typeof operationLogs.$inferInsert;
