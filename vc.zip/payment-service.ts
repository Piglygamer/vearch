import Stripe from "stripe";
import { eq, and } from "drizzle-orm";
import {
  userWallets,
  walletBalances,
  transactions,
  paymentMethods,
  cryptoWallets,
  recurringPayments,
  InsertTransaction,
  InsertUserWallet,
} from "../drizzle/payment-schema";
import { getDb } from "./db";
import { ENV } from "./_core/env";

const stripe = new Stripe(ENV.stripeSecretKey || "", {
  apiVersion: "2024-04-10",
});

/**
 * WALLET MANAGEMENT
 */

export async function createWallet(
  userId: number,
  chipId: number,
  walletName: string,
  walletType: "fiat" | "cryptocurrency" | "hybrid"
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Create Stripe customer if not exists
  const stripeCustomer = await stripe.customers.create({
    metadata: {
      userId: userId.toString(),
      chipId: chipId.toString(),
    },
  });

  const wallet = await db.insert(userWallets).values({
    userId,
    chipId,
    walletName,
    walletType,
    stripeCustomerId: stripeCustomer.id,
    isActive: true,
  });

  // Initialize balance
  await db.insert(walletBalances).values({
    walletId: Number(wallet[0].insertId),
    currency: walletType === "cryptocurrency" ? "BTC" : "USD",
    balance: 0,
  });

  return wallet;
}

export async function getUserWallets(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.query.userWallets.findMany({
    where: eq(userWallets.userId, userId),
  });
}

export async function getWalletBalance(walletId: number, currency: string) {
  const db = await getDb();
  if (!db) return null;

  return db.query.walletBalances.findFirst({
    where: and(
      eq(walletBalances.walletId, walletId),
      eq(walletBalances.currency, currency)
    ),
  });
}

/**
 * PAYMENT PROCESSING
 */

export async function createPaymentIntent(
  userId: number,
  walletId: number,
  amount: number,
  currency: string = "USD",
  description: string = ""
): Promise<Stripe.PaymentIntent> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await db.query.userWallets.findFirst({
    where: eq(userWallets.id, walletId),
  });

  if (!wallet || wallet.userId !== userId) {
    throw new Error("Wallet not found or not owned by user");
  }

  // Create Stripe payment intent
  const paymentIntent = await stripe.paymentIntents.create({
    amount: Math.round(amount * 100), // Convert to cents
    currency: currency.toLowerCase(),
    customer: wallet.stripeCustomerId || undefined,
    metadata: {
      userId: userId.toString(),
      walletId: walletId.toString(),
      chipId: wallet.chipId.toString(),
    },
    description,
  });

  // Record transaction in database
  await db.insert(transactions).values({
    walletId,
    transactionType: "payment",
    amount: amount.toString(),
    currency,
    status: "pending",
    stripePaymentIntentId: paymentIntent.id,
    description,
  });

  return paymentIntent;
}

export async function confirmPayment(
  paymentIntentId: string,
  paymentMethodId: string
): Promise<Stripe.PaymentIntent> {
  // Confirm payment with Stripe
  const paymentIntent = await stripe.paymentIntents.confirm(paymentIntentId, {
    payment_method: paymentMethodId,
  });

  // Update transaction status
  const db = await getDb();
  if (db) {
    await db
      .update(transactions)
      .set({
        status: paymentIntent.status === "succeeded" ? "completed" : "failed",
        stripeChargeId: paymentIntent.charges.data[0]?.id,
        completedAt: new Date(),
      })
      .where(eq(transactions.stripePaymentIntentId, paymentIntentId));
  }

  return paymentIntent;
}

export async function processTransaction(
  walletId: number,
  amount: number,
  currency: string,
  transactionType: "payment" | "transfer" | "deposit" | "withdrawal" | "refund" | "fee",
  description: string = ""
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Record transaction
  const transaction = await db.insert(transactions).values({
    walletId,
    transactionType,
    amount: amount.toString(),
    currency,
    status: "completed",
    description,
    completedAt: new Date(),
  });

  // Update wallet balance
  const balance = await getWalletBalance(walletId, currency);
  if (balance) {
    const newBalance =
      transactionType === "withdrawal" || transactionType === "payment"
        ? Number(balance.balance) - amount
        : Number(balance.balance) + amount;

    await db
      .update(walletBalances)
      .set({ balance: newBalance.toString() })
      .where(
        and(
          eq(walletBalances.walletId, walletId),
          eq(walletBalances.currency, currency)
        )
      );
  }

  return transaction;
}

/**
 * PAYMENT METHODS
 */

export async function addPaymentMethod(
  userId: number,
  stripePaymentMethodId: string,
  methodType: "card" | "bank_account" | "wallet" | "cryptocurrency"
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Fetch payment method details from Stripe
  const paymentMethod = await stripe.paymentMethods.retrieve(
    stripePaymentMethodId
  );

  const displayName =
    methodType === "card"
      ? `${paymentMethod.card?.brand} ****${paymentMethod.card?.last4}`
      : `${methodType}`;

  return db.insert(paymentMethods).values({
    userId,
    methodType,
    stripePaymentMethodId,
    displayName,
    lastFourDigits: paymentMethod.card?.last4 || "",
    brand: paymentMethod.card?.brand || "",
    isDefault: false,
  });
}

export async function getUserPaymentMethods(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.query.paymentMethods.findMany({
    where: eq(paymentMethods.userId, userId),
  });
}

export async function setDefaultPaymentMethod(userId: number, methodId: number) {
  const db = await getDb();
  if (!db) return;

  // Clear other defaults
  await db
    .update(paymentMethods)
    .set({ isDefault: false })
    .where(eq(paymentMethods.userId, userId));

  // Set this one as default
  await db
    .update(paymentMethods)
    .set({ isDefault: true })
    .where(eq(paymentMethods.id, methodId));
}

/**
 * CRYPTOCURRENCY SUPPORT
 */

export async function createCryptoWallet(
  userId: number,
  chipId: number,
  cryptocurrency: string,
  publicAddress: string,
  encryptedPrivateKey: string,
  derivationPath: string = ""
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(cryptoWallets).values({
    userId,
    chipId,
    cryptocurrency,
    publicAddress,
    encryptedPrivateKey,
    derivationPath,
    balance: 0,
    isActive: true,
  });
}

export async function getUserCryptoWallets(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.query.cryptoWallets.findMany({
    where: eq(cryptoWallets.userId, userId),
  });
}

export async function updateCryptoBalance(
  walletId: number,
  balance: number,
  balanceUsd: number
) {
  const db = await getDb();
  if (!db) return;

  await db
    .update(cryptoWallets)
    .set({
      balance: balance.toString(),
      balanceUsd: balanceUsd.toString(),
      updatedAt: new Date(),
    })
    .where(eq(cryptoWallets.id, walletId));
}

/**
 * RECURRING PAYMENTS
 */

export async function createRecurringPayment(
  userId: number,
  walletId: number,
  amount: number,
  currency: string,
  frequency: "daily" | "weekly" | "biweekly" | "monthly" | "quarterly" | "yearly"
): Promise<any> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await db.query.userWallets.findFirst({
    where: eq(userWallets.id, walletId),
  });

  if (!wallet) throw new Error("Wallet not found");

  // Create Stripe subscription
  const subscription = await stripe.subscriptions.create({
    customer: wallet.stripeCustomerId || undefined,
    items: [
      {
        price_data: {
          currency: currency.toLowerCase(),
          product_data: {
            name: `Recurring Payment - ${frequency}`,
          },
          recurring: {
            interval: mapFrequencyToStripeInterval(frequency),
            interval_count: 1,
          },
          unit_amount: Math.round(amount * 100),
        },
      },
    ],
    metadata: {
      userId: userId.toString(),
      walletId: walletId.toString(),
    },
  });

  return db.insert(recurringPayments).values({
    userId,
    walletId,
    amount: amount.toString(),
    currency,
    frequency,
    stripeSubscriptionId: subscription.id,
    status: "active",
    startDate: new Date(),
    nextChargeDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
  });
}

function mapFrequencyToStripeInterval(
  frequency: string
): "day" | "week" | "month" | "year" {
  const map: Record<string, "day" | "week" | "month" | "year"> = {
    daily: "day",
    weekly: "week",
    biweekly: "week",
    monthly: "month",
    quarterly: "month",
    yearly: "year",
  };
  return map[frequency] || "month";
}

export async function getUserRecurringPayments(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db.query.recurringPayments.findMany({
    where: eq(recurringPayments.userId, userId),
  });
}

export async function cancelRecurringPayment(subscriptionId: string) {
  // Cancel in Stripe
  await stripe.subscriptions.cancel(subscriptionId);

  // Update in database
  const db = await getDb();
  if (db) {
    await db
      .update(recurringPayments)
      .set({ status: "cancelled", endDate: new Date() })
      .where(eq(recurringPayments.stripeSubscriptionId, subscriptionId));
  }
}

/**
 * TRANSACTION HISTORY
 */

export async function getWalletTransactions(
  walletId: number,
  limit: number = 50,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) return [];

  return db.query.transactions.findMany({
    where: eq(transactions.walletId, walletId),
    limit,
    offset,
    orderBy: (transactions, { desc }) => desc(transactions.initiatedAt),
  });
}

export async function getTransactionById(transactionId: number) {
  const db = await getDb();
  if (!db) return null;

  return db.query.transactions.findFirst({
    where: eq(transactions.id, transactionId),
  });
}

/**
 * WEBHOOK HANDLING
 */

export async function handleStripeWebhook(event: Stripe.Event) {
  const db = await getDb();
  if (!db) return;

  switch (event.type) {
    case "payment_intent.succeeded": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      await db
        .update(transactions)
        .set({ status: "completed", completedAt: new Date() })
        .where(eq(transactions.stripePaymentIntentId, paymentIntent.id));
      break;
    }

    case "payment_intent.payment_failed": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      await db
        .update(transactions)
        .set({
          status: "failed",
          errorMessage: paymentIntent.last_payment_error?.message,
          completedAt: new Date(),
        })
        .where(eq(transactions.stripePaymentIntentId, paymentIntent.id));
      break;
    }

    case "charge.refunded": {
      const charge = event.data.object as Stripe.Charge;
      // Process refund
      if (charge.payment_intent) {
        const transaction = await db.query.transactions.findFirst({
          where: eq(
            transactions.stripePaymentIntentId,
            charge.payment_intent as string
          ),
        });

        if (transaction) {
          const refundAmount = charge.amount_refunded / 100;
          await processTransaction(
            transaction.walletId,
            refundAmount,
            transaction.currency,
            "refund",
            `Refund for payment ${charge.id}`
          );
        }
      }
      break;
    }

    case "customer.subscription.updated": {
      const subscription = event.data.object as Stripe.Subscription;
      await db
        .update(recurringPayments)
        .set({
          status: subscription.status as any,
          nextChargeDate: new Date(subscription.current_period_end * 1000),
        })
        .where(eq(recurringPayments.stripeSubscriptionId, subscription.id));
      break;
    }

    case "customer.subscription.deleted": {
      const subscription = event.data.object as Stripe.Subscription;
      await db
        .update(recurringPayments)
        .set({
          status: "cancelled",
          endDate: new Date(),
        })
        .where(eq(recurringPayments.stripeSubscriptionId, subscription.id));
      break;
    }
  }
}
