import crypto from "crypto";

/**
 * Magic Chips (xM1 gen2) Manager
 * CUID-based chip management for magic Mifare chips
 * UID modification, cloning, sector management
 */

export interface MagicChip {
  cuid: string; // Changeable UID
  originalUid?: string;
  chipType: "magic_xm1_gen2";
  generation: "gen2";
  memorySize: number;
  isConnected: boolean;
  lastConnected: Date;
  backdoorOpen: boolean;
}

export interface MagicSector {
  sectorNumber: number;
  data: Buffer;
  isLocked: boolean;
  accessBits: string;
  keyA?: Buffer;
  keyB?: Buffer;
}

export interface CloneOperation {
  sourceChip: string;
  targetChip: string;
  sectorsCloned: number[];
  timestamp: Date;
  success: boolean;
  error?: string;
}

export interface UidChangeOperation {
  chipCuid: string;
  oldUid: string;
  newUid: string;
  timestamp: Date;
  success: boolean;
  error?: string;
}

/**
 * Magic Chips Manager Class
 */
export class MagicChipManager {
  private connectedChips: Map<string, MagicChip> = new Map();
  private cloneHistory: CloneOperation[] = [];
  private uidChangeHistory: UidChangeOperation[] = [];

  /**
   * Discover and connect to magic chip
   */
  async discoverChip(cuid: string): Promise<MagicChip | null> {
    try {
      console.log(`[MAGIC] Discovering magic chip: ${cuid}`);

      // Verify CUID format (8 hex characters)
      if (!/^[0-9a-fA-F]{8}$/.test(cuid)) {
        throw new Error("Invalid CUID format");
      }

      const chip: MagicChip = {
        cuid,
        originalUid: cuid,
        chipType: "magic_xm1_gen2",
        generation: "gen2",
        memorySize: 1024, // 1KB
        isConnected: true,
        lastConnected: new Date(),
        backdoorOpen: false,
      };

      this.connectedChips.set(cuid, chip);
      console.log(`[MAGIC] Magic chip discovered: ${cuid}`);

      return chip;
    } catch (error) {
      console.error("[MAGIC] Discovery failed:", error);
      return null;
    }
  }

  /**
   * Read sector from magic chip
   */
  async readSector(cuid: string, sectorNumber: number): Promise<MagicSector | null> {
    try {
      const chip = this.connectedChips.get(cuid);
      if (!chip) {
        throw new Error("Chip not connected");
      }

      console.log(`[MAGIC] Reading sector ${sectorNumber} from ${cuid}`);

      // Validate sector number
      if (sectorNumber < 0 || sectorNumber > 63) {
        throw new Error("Invalid sector number");
      }

      // Simulate sector read
      const sectorData = this.generateSectorData(sectorNumber, cuid);

      const sector: MagicSector = {
        sectorNumber,
        data: sectorData,
        isLocked: false, // Magic chips can write all sectors
        accessBits: "FF0780",
        keyA: Buffer.from("FFFFFFFFFFFF", "hex"),
        keyB: Buffer.from("FFFFFFFFFFFF", "hex"),
      };

      console.log(`[MAGIC] Sector ${sectorNumber} read successfully`);

      return sector;
    } catch (error) {
      console.error("[MAGIC] Read failed:", error);
      return null;
    }
  }

  /**
   * Write sector to magic chip
   */
  async writeSector(
    cuid: string,
    sectorNumber: number,
    data: Buffer
  ): Promise<boolean> {
    try {
      const chip = this.connectedChips.get(cuid);
      if (!chip) {
        throw new Error("Chip not connected");
      }

      console.log(`[MAGIC] Writing sector ${sectorNumber} to ${cuid}`);

      // Validate sector number
      if (sectorNumber < 0 || sectorNumber > 63) {
        throw new Error("Invalid sector number");
      }

      // Validate data size
      if (data.length !== 16) {
        throw new Error("Sector data must be 16 bytes");
      }

      // Magic chips allow writing sector 0 (unlike real Mifare)
      console.log(`[MAGIC] Sector ${sectorNumber} written successfully`);

      return true;
    } catch (error) {
      console.error("[MAGIC] Write failed:", error);
      return false;
    }
  }

  /**
   * Change UID on magic chip
   */
  async changeUid(cuid: string, newUid: string): Promise<boolean> {
    const operation: UidChangeOperation = {
      chipCuid: cuid,
      oldUid: cuid,
      newUid,
      timestamp: new Date(),
      success: false,
    };

    try {
      const chip = this.connectedChips.get(cuid);
      if (!chip) {
        throw new Error("Chip not connected");
      }

      console.log(`[MAGIC] Changing UID from ${cuid} to ${newUid}`);

      // Verify new UID format
      if (!/^[0-9a-fA-F]{8}$/.test(newUid)) {
        throw new Error("Invalid new UID format");
      }

      // Write new UID to sector 0
      const sector0Data = Buffer.alloc(16);
      const uidBuffer = Buffer.from(newUid, "hex");
      uidBuffer.copy(sector0Data, 0);

      // Calculate BCC (Block Check Character)
      const bcc = this.calculateBCC(uidBuffer);
      sector0Data[4] = bcc;

      // Write sector 0
      const writeSuccess = await this.writeSector(cuid, 0, sector0Data);

      if (!writeSuccess) {
        throw new Error("Failed to write new UID to sector 0");
      }

      // Update chip record
      const newChip = { ...chip, cuid: newUid };
      this.connectedChips.delete(cuid);
      this.connectedChips.set(newUid, newChip);

      operation.success = true;
      this.uidChangeHistory.push(operation);

      console.log(`[MAGIC] UID changed successfully to ${newUid}`);

      return true;
    } catch (error) {
      operation.error = error instanceof Error ? error.message : "Unknown error";
      this.uidChangeHistory.push(operation);
      console.error("[MAGIC] UID change failed:", error);
      return false;
    }
  }

  /**
   * Clone card data from source to target
   */
  async cloneCard(sourceCuid: string, targetCuid: string): Promise<boolean> {
    const operation: CloneOperation = {
      sourceChip: sourceCuid,
      targetChip: targetCuid,
      sectorsCloned: [],
      timestamp: new Date(),
      success: false,
    };

    try {
      const sourceChip = this.connectedChips.get(sourceCuid);
      const targetChip = this.connectedChips.get(targetCuid);

      if (!sourceChip || !targetChip) {
        throw new Error("Source or target chip not connected");
      }

      console.log(`[MAGIC] Cloning from ${sourceCuid} to ${targetCuid}`);

      // Read all sectors from source
      const sectors: MagicSector[] = [];
      for (let i = 0; i < 64; i++) {
        const sector = await this.readSector(sourceCuid, i);
        if (sector) {
          sectors.push(sector);
        }
      }

      // Write all sectors to target
      for (const sector of sectors) {
        const writeSuccess = await this.writeSector(
          targetCuid,
          sector.sectorNumber,
          sector.data
        );

        if (writeSuccess) {
          operation.sectorsCloned.push(sector.sectorNumber);
        }
      }

      // Change target UID to match source
      const uidChangeSuccess = await this.changeUid(targetCuid, sourceCuid);

      if (!uidChangeSuccess) {
        throw new Error("Failed to change target UID");
      }

      operation.success = true;
      this.cloneHistory.push(operation);

      console.log(
        `[MAGIC] Card cloned successfully: ${operation.sectorsCloned.length} sectors`
      );

      return true;
    } catch (error) {
      operation.error = error instanceof Error ? error.message : "Unknown error";
      this.cloneHistory.push(operation);
      console.error("[MAGIC] Clone failed:", error);
      return false;
    }
  }

  /**
   * Read all sectors from chip
   */
  async readAllSectors(cuid: string): Promise<MagicSector[] | null> {
    try {
      const chip = this.connectedChips.get(cuid);
      if (!chip) {
        throw new Error("Chip not connected");
      }

      console.log(`[MAGIC] Reading all sectors from ${cuid}`);

      const sectors: MagicSector[] = [];

      for (let i = 0; i < 64; i++) {
        const sector = await this.readSector(cuid, i);
        if (sector) {
          sectors.push(sector);
        }
      }

      console.log(`[MAGIC] Read ${sectors.length} sectors`);

      return sectors;
    } catch (error) {
      console.error("[MAGIC] Read all sectors failed:", error);
      return null;
    }
  }

  /**
   * Backup chip data
   */
  async backupChip(cuid: string): Promise<Buffer | null> {
    try {
      const sectors = await this.readAllSectors(cuid);
      if (!sectors) {
        throw new Error("Failed to read sectors");
      }

      // Combine all sectors into single buffer
      const backup = Buffer.alloc(1024);
      for (const sector of sectors) {
        sector.data.copy(backup, sector.sectorNumber * 16);
      }

      console.log(`[MAGIC] Chip backed up: ${cuid}`);

      return backup;
    } catch (error) {
      console.error("[MAGIC] Backup failed:", error);
      return null;
    }
  }

  /**
   * Restore chip data from backup
   */
  async restoreChip(cuid: string, backup: Buffer): Promise<boolean> {
    try {
      if (backup.length !== 1024) {
        throw new Error("Backup size must be 1024 bytes");
      }

      console.log(`[MAGIC] Restoring chip: ${cuid}`);

      // Write all sectors from backup
      for (let i = 0; i < 64; i++) {
        const sectorData = backup.slice(i * 16, (i + 1) * 16);
        const writeSuccess = await this.writeSector(cuid, i, sectorData);

        if (!writeSuccess) {
          throw new Error(`Failed to write sector ${i}`);
        }
      }

      console.log(`[MAGIC] Chip restored successfully`);

      return true;
    } catch (error) {
      console.error("[MAGIC] Restore failed:", error);
      return false;
    }
  }

  /**
   * Get chip info
   */
  getChipInfo(cuid: string): MagicChip | null {
    return this.connectedChips.get(cuid) || null;
  }

  /**
   * Get clone history
   */
  getCloneHistory(cuid?: string): CloneOperation[] {
    if (cuid) {
      return this.cloneHistory.filter(
        (op) => op.sourceChip === cuid || op.targetChip === cuid
      );
    }
    return this.cloneHistory;
  }

  /**
   * Get UID change history
   */
  getUidChangeHistory(cuid?: string): UidChangeOperation[] {
    if (cuid) {
      return this.uidChangeHistory.filter((op) => op.chipCuid === cuid);
    }
    return this.uidChangeHistory;
  }

  /**
   * Disconnect chip
   */
  disconnectChip(cuid: string): boolean {
    const chip = this.connectedChips.get(cuid);
    if (chip) {
      chip.isConnected = false;
      console.log(`[MAGIC] Chip disconnected: ${cuid}`);
      return true;
    }
    return false;
  }

  /**
   * Calculate BCC (Block Check Character)
   */
  private calculateBCC(data: Buffer): number {
    let bcc = 0;
    for (let i = 0; i < data.length; i++) {
      bcc ^= data[i];
    }
    return bcc;
  }

  /**
   * Generate sector data (for simulation)
   */
  private generateSectorData(sectorNumber: number, cuid: string): Buffer {
    const data = Buffer.alloc(16);

    if (sectorNumber === 0) {
      // UID block
      const uidBuffer = Buffer.from(cuid, "hex");
      uidBuffer.copy(data, 0);

      // BCC
      data[4] = this.calculateBCC(uidBuffer);

      // SAK
      data[5] = 0x08;

      // ATQA
      data[6] = 0x04;
      data[7] = 0x00;
    } else {
      // Random data
      crypto.randomFillSync(data);
    }

    return data;
  }
}

/**
 * Export singleton instance
 */
export const magicChipManager = new MagicChipManager();
