import { router, publicProcedure, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { eq, and } from "drizzle-orm";
import {
  users,
  implants,
  paymentMethods,
  merchants,
  transactions,
  implantUpgrades,
  applets,
  implantApplets,
  operationLogs,
} from "../drizzle/complete-schema";

// ============================================================================
// IMPLANT MANAGEMENT PROCEDURES
// ============================================================================
const implantRouter = router({
  // List user's implants
  list: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(implants)
      .where(eq(implants.userId, ctx.user.id));
  }),

  // Link new implant
  link: protectedProcedure
    .input(
      z.object({
        uid: z.string(),
        type: z.enum(["spark2", "magic", "apex", "other"]),
        name: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      const result = await db.insert(implants).values({
        userId: ctx.user.id,
        uid: input.uid,
        type: input.type,
        name: input.name,
        status: "paired",
      });

      // Log operation
      await db.insert(operationLogs).values({
        userId: ctx.user.id,
        operation: "implant_linked",
        status: "success",
        details: `Linked ${input.type} implant: ${input.uid}`,
      });

      return result;
    }),

  // Get implant details
  get: protectedProcedure
    .input(z.object({ implantId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      const implant = await db
        .select()
        .from(implants)
        .where(
          and(eq(implants.id, input.implantId), eq(implants.userId, ctx.user.id))
        )
        .limit(1);

      return implant[0] || null;
    }),

  // Update implant
  update: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        name: z.string().optional(),
        status: z.enum(["active", "inactive", "paired", "connected"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      await db
        .update(implants)
        .set({
          name: input.name,
          status: input.status,
        })
        .where(
          and(eq(implants.id, input.implantId), eq(implants.userId, ctx.user.id))
        );

      return { success: true };
    }),
});

// ============================================================================
// PAYMENT PROCEDURES
// ============================================================================
const paymentRouter = router({
  // List payment methods
  listMethods: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];
    return db
      .select()
      .from(paymentMethods)
      .where(eq(paymentMethods.userId, ctx.user.id));
  }),

  // Add payment method
  addMethod: protectedProcedure
    .input(
      z.object({
        stripePaymentMethodId: z.string(),
        brand: z.string(),
        last4: z.string(),
        expMonth: z.number(),
        expYear: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      return db.insert(paymentMethods).values({
        userId: ctx.user.id,
        stripePaymentMethodId: input.stripePaymentMethodId,
        brand: input.brand,
        last4: input.last4,
        expMonth: input.expMonth,
        expYear: input.expYear,
        isDefault: true,
      });
    }),

  // Process payment
  process: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        merchantId: z.number(),
        amountCents: z.number(),
        currency: z.string().default("usd"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      // Create transaction record
      const transaction = await db.insert(transactions).values({
        userId: ctx.user.id,
        implantId: input.implantId,
        merchantId: input.merchantId,
        amountCents: input.amountCents,
        currency: input.currency,
        status: "completed",
      });

      // Update implant last used
      await db
        .update(implants)
        .set({ lastUsed: new Date() })
        .where(eq(implants.id, input.implantId));

      // Log operation
      await db.insert(operationLogs).values({
        userId: ctx.user.id,
        implantId: input.implantId,
        operation: "payment_processed",
        status: "success",
        details: `Payment of ${input.amountCents} ${input.currency}`,
      });

      return transaction;
    }),

  // Get transaction history
  history: protectedProcedure
    .input(z.object({ limit: z.number().default(50) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(transactions)
        .where(eq(transactions.userId, ctx.user.id))
        .limit(input.limit);
    }),
});

// ============================================================================
// UPGRADE PROCEDURES
// ============================================================================
const upgradeRouter = router({
  // List available upgrades
  available: publicProcedure.query(async () => {
    return [
      {
        id: "auth",
        name: "Authentication",
        description: "Biometric and multi-factor authentication",
        price: 0,
      },
      {
        id: "payment",
        name: "Payment",
        description: "Tap-to-pay functionality",
        price: 0,
      },
      {
        id: "identity",
        name: "Identity",
        description: "Self-sovereign identity credentials",
        price: 0,
      },
      {
        id: "storage",
        name: "Storage",
        description: "Secure data storage",
        price: 0,
      },
      {
        id: "biometric",
        name: "Biometric",
        description: "Fingerprint and face recognition",
        price: 0,
      },
      {
        id: "iot",
        name: "IoT Control",
        description: "Smart device and home automation",
        price: 0,
      },
    ];
  }),

  // Deploy upgrade to implant
  deploy: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        upgradeType: z.enum([
          "authentication",
          "payment",
          "identity",
          "storage",
          "biometric",
          "iot",
        ]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      // Create upgrade record
      const upgrade = await db.insert(implantUpgrades).values({
        implantId: input.implantId,
        upgradeType: input.upgradeType,
        status: "active",
      });

      // Increment upgrade counter
      await db
        .update(implants)
        .set({ upgrades: implants.upgrades })
        .where(eq(implants.id, input.implantId));

      // Log operation
      await db.insert(operationLogs).values({
        userId: ctx.user.id,
        implantId: input.implantId,
        operation: "upgrade_deployed",
        status: "success",
        details: `Deployed ${input.upgradeType} upgrade`,
      });

      return upgrade;
    }),

  // List implant upgrades
  list: protectedProcedure
    .input(z.object({ implantId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(implantUpgrades)
        .where(eq(implantUpgrades.implantId, input.implantId));
    }),
});

// ============================================================================
// APPLET PROCEDURES
// ============================================================================
const appletRouter = router({
  // List available applets
  available: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return db.select().from(applets);
  }),

  // Deploy applet to Apex Flex
  deploy: protectedProcedure
    .input(
      z.object({
        implantId: z.number(),
        appletId: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      // Create deployment record
      const deployment = await db.insert(implantApplets).values({
        implantId: input.implantId,
        appletId: input.appletId,
        status: "pending",
      });

      // Log operation
      await db.insert(operationLogs).values({
        userId: ctx.user.id,
        implantId: input.implantId,
        operation: "applet_deployed",
        status: "success",
        details: `Deploying applet ${input.appletId}`,
      });

      return deployment;
    }),

  // List installed applets
  installed: protectedProcedure
    .input(z.object({ implantId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      return db
        .select()
        .from(implantApplets)
        .where(eq(implantApplets.implantId, input.implantId));
    }),
});

// ============================================================================
// MAIN ROUTER
// ============================================================================
export const appRouter = router({
  implant: implantRouter,
  payment: paymentRouter,
  upgrade: upgradeRouter,
  applet: appletRouter,
});

export type AppRouter = typeof appRouter;
