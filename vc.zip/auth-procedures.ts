import { router, protectedProcedure, publicProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { users } from "../drizzle/complete-schema";
import { eq } from "drizzle-orm";

/**
 * Real Authentication Procedures
 * Handles user authentication, profile management, and session handling
 */

export const authProcedures = router({
  /**
   * Get current user info
   */
  me: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    try {
      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (!user[0]) {
        throw new Error("User not found");
      }

      return {
        id: user[0].id,
        email: user[0].email,
        name: user[0].name,
        role: user[0].role,
        createdAt: user[0].createdAt,
        preferences: user[0].preferences ? JSON.parse(user[0].preferences) : {},
      };
    } catch (error) {
      console.error("[Auth] Failed to get current user:", error);
      throw error;
    }
  }),

  /**
   * Update user profile
   */
  updateProfile: protectedProcedure
    .input(
      z.object({
        name: z.string().optional(),
        email: z.string().email().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        const updateData: any = {};

        if (input.name) updateData.name = input.name;
        if (input.email) updateData.email = input.email;

        if (Object.keys(updateData).length === 0) {
          throw new Error("No fields to update");
        }

        await db.update(users).set(updateData).where(eq(users.id, ctx.user.id));

        console.log(`[Auth] User profile updated: ${ctx.user.id}`);

        return {
          success: true,
          message: "Profile updated successfully",
        };
      } catch (error) {
        console.error("[Auth] Profile update failed:", error);
        throw error;
      }
    }),

  /**
   * Update user preferences
   */
  updatePreferences: protectedProcedure
    .input(
      z.object({
        theme: z.enum(["light", "dark"]).optional(),
        notifications: z.boolean().optional(),
        defaultCurrency: z.string().optional(),
        language: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        // Get current preferences
        const user = await db
          .select()
          .from(users)
          .where(eq(users.id, ctx.user.id))
          .limit(1);

        if (!user[0]) {
          throw new Error("User not found");
        }

        const currentPreferences = user[0].preferences
          ? JSON.parse(user[0].preferences)
          : {};

        // Merge with new preferences
        const updatedPreferences = {
          ...currentPreferences,
          ...input,
        };

        await db
          .update(users)
          .set({ preferences: JSON.stringify(updatedPreferences) })
          .where(eq(users.id, ctx.user.id));

        console.log(`[Auth] User preferences updated: ${ctx.user.id}`);

        return {
          success: true,
          preferences: updatedPreferences,
        };
      } catch (error) {
        console.error("[Auth] Preferences update failed:", error);
        throw error;
      }
    }),

  /**
   * Get user preferences
   */
  getPreferences: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");

    try {
      const user = await db
        .select()
        .from(users)
        .where(eq(users.id, ctx.user.id))
        .limit(1);

      if (!user[0]) {
        throw new Error("User not found");
      }

      return user[0].preferences ? JSON.parse(user[0].preferences) : {};
    } catch (error) {
      console.error("[Auth] Failed to get preferences:", error);
      throw error;
    }
  }),

  /**
   * Logout (client-side session cleanup)
   */
  logout: protectedProcedure.mutation(async ({ ctx }) => {
    console.log(`[Auth] User logged out: ${ctx.user.id}`);

    return {
      success: true,
      message: "Logged out successfully",
    };
  }),

  /**
   * Delete user account
   */
  deleteAccount: protectedProcedure
    .input(
      z.object({
        password: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database unavailable");

      try {
        // In production, verify password before deletion

        // Delete user and all related data
        await db.delete(users).where(eq(users.id, ctx.user.id));

        console.log(`[Auth] User account deleted: ${ctx.user.id}`);

        return {
          success: true,
          message: "Account deleted successfully",
        };
      } catch (error) {
        console.error("[Auth] Account deletion failed:", error);
        throw error;
      }
    }),
});

export type AuthProcedures = typeof authProcedures;
