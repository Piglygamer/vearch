/**
 * Comprehensive Biohacking Chip Registry
 * Complete database of all historical and current biohacking chips
 * 
 * This is the definitive source for chip specifications, capabilities,
 * and compatibility information.
 */

export interface ChipSpecification {
  id: string;
  name: string;
  manufacturer: string;
  type: string;
  protocol: string;
  memorySize: number;
  sectors?: number;
  uid: string;
  capabilities: string[];
  price: number;
  releaseDate: string;
  status: "active" | "discontinued" | "prototype" | "experimental";
  successRate: number; // 0-100%
  implantable: boolean;
  paymentCapable: boolean;
  description: string;
  pros: string[];
  cons: string[];
  compatibility: {
    android: boolean;
    ios: boolean;
    desktop: boolean;
  };
}

/**
 * Complete Biohacking Chip Registry
 */
export const CHIP_REGISTRY: Record<string, ChipSpecification> = {
  // ============================================================================
  // CURRENT GENERATION CHIPS
  // ============================================================================

  xm1_gen2: {
    id: "xm1_gen2",
    name: "xM1 gen2 (Magic Chip)",
    manufacturer: "Dangerous Things",
    type: "Mifare Classic",
    protocol: "ISO 14443 Type A",
    memorySize: 1024,
    sectors: 16,
    uid: "4-byte UID",
    capabilities: ["read_sector", "write_sector", "clone", "uid_change", "backup_restore"],
    price: 99,
    releaseDate: "2019-01-01",
    status: "active",
    successRate: 98,
    implantable: true,
    paymentCapable: false,
    description:
      "The most popular biohacking chip. Affordable, reliable, and well-documented. Sector-based read/write with full cloning support.",
    pros: [
      "Affordable ($99)",
      "Excellent documentation",
      "Large community support",
      "Full read/write capability",
      "Sector cloning",
      "UID modification",
    ],
    cons: [
      "No payment capability",
      "Mifare Classic vulnerabilities",
      "Limited memory (1KB)",
      "Older technology",
    ],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  vivokey_spark2: {
    id: "vivokey_spark2",
    name: "VivoKey Spark 2",
    manufacturer: "Dangerous Things",
    type: "UID-Based",
    protocol: "ISO 14443 Type A",
    memorySize: 2048,
    uid: "10-byte UID",
    capabilities: ["uid_upgrades", "applet_deployment", "payment"],
    price: 199,
    releaseDate: "2020-06-01",
    status: "active",
    successRate: 96,
    implantable: true,
    paymentCapable: true,
    description:
      "Next-generation implant with permanent UID-based capability upgrades. Supports Fidesmo applet deployment for payment.",
    pros: [
      "Permanent capability upgrades via UID",
      "Payment support via Fidesmo",
      "Larger memory (2KB)",
      "Better security",
      "Applet deployment",
    ],
    cons: [
      "Higher cost ($199)",
      "Requires Fidesmo for payments",
      "UID-based (not sector-based)",
    ],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  apex_flex: {
    id: "apex_flex",
    name: "Apex Flex",
    manufacturer: "Dangerous Things",
    type: "Java Card",
    protocol: "ISO 7816-4 APDU",
    memorySize: 32768,
    uid: "10-byte UID",
    capabilities: ["applet_deploy", "applet_execute", "applet_uninstall", "payment", "crypto"],
    price: 299,
    releaseDate: "2021-03-01",
    status: "active",
    successRate: 94,
    implantable: true,
    paymentCapable: true,
    description:
      "Premium Java Card implant. Full applet deployment, cryptographic operations, and advanced payment capabilities.",
    pros: [
      "Full Java Card support",
      "32KB memory",
      "Cryptographic operations",
      "Advanced applet deployment",
      "Payment support",
      "Flexible architecture",
    ],
    cons: [
      "Highest cost ($299)",
      "Requires Fidesmo for applets",
      "Complex setup",
      "Smaller community",
    ],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  zinc: {
    id: "zinc",
    name: "Zinc",
    manufacturer: "Dangerous Things",
    type: "Mifare Plus",
    protocol: "ISO 14443 Type A",
    memorySize: 2048,
    sectors: 32,
    uid: "4-byte UID",
    capabilities: ["read_sector", "write_sector", "clone", "uid_change", "encryption"],
    price: 149,
    releaseDate: "2022-06-01",
    status: "active",
    successRate: 97,
    implantable: true,
    paymentCapable: false,
    description:
      "Enhanced version of xM1 gen2 with Mifare Plus encryption. Better security than Classic with same affordability.",
    pros: [
      "Affordable ($149)",
      "Mifare Plus encryption",
      "32 sectors (2x xM1)",
      "Better security than Classic",
      "Full read/write",
      "Sector cloning",
    ],
    cons: [
      "No payment capability",
      "Requires Mifare Plus support",
      "Slightly higher cost than xM1",
    ],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  // ============================================================================
  // LEGACY CHIPS
  // ============================================================================

  xm1_gen1: {
    id: "xm1_gen1",
    name: "xM1 gen1",
    manufacturer: "Dangerous Things",
    type: "Mifare Classic",
    protocol: "ISO 14443 Type A",
    memorySize: 1024,
    sectors: 16,
    uid: "4-byte UID",
    capabilities: ["read_sector", "write_sector", "clone", "uid_change"],
    price: 79,
    releaseDate: "2013-01-01",
    status: "discontinued",
    successRate: 95,
    implantable: true,
    paymentCapable: false,
    description: "Original Magic Chip. Still functional but superseded by xM1 gen2.",
    pros: ["Very affordable", "Proven design", "Good documentation"],
    cons: ["Older technology", "Limited support", "Mifare Classic vulnerabilities"],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  next: {
    id: "next",
    name: "NExT",
    manufacturer: "Dangerous Things",
    type: "Dual Interface",
    protocol: "ISO 14443 Type A + LF",
    memorySize: 2048,
    uid: "4-byte UID (NFC) + 64-bit (LF)",
    capabilities: ["read_sector", "write_sector", "clone", "uid_change", "lf_read", "lf_write"],
    price: 249,
    releaseDate: "2015-06-01",
    status: "active",
    successRate: 93,
    implantable: true,
    paymentCapable: false,
    description: "Dual-interface chip with both NFC (Mifare Classic) and Low Frequency (LF) capabilities.",
    pros: ["Dual interface (NFC + LF)", "Access control support", "Versatile"],
    cons: ["Higher cost", "Larger implant", "Complex setup"],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  titan: {
    id: "titan",
    name: "Titan",
    manufacturer: "Dangerous Things",
    type: "Mifare Classic",
    protocol: "ISO 14443 Type A",
    memorySize: 1024,
    sectors: 16,
    uid: "4-byte UID",
    capabilities: ["read_sector", "write_sector", "clone", "uid_change"],
    price: 179,
    releaseDate: "2016-03-01",
    status: "active",
    successRate: 96,
    implantable: true,
    paymentCapable: false,
    description: "Titanium-encapsulated xM1 for maximum biocompatibility and durability.",
    pros: ["Titanium encapsulation", "Excellent biocompatibility", "Durable"],
    cons: ["Higher cost ($179)", "Larger implant", "Harder to program"],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  // ============================================================================
  // EXPERIMENTAL / PROTOTYPE CHIPS
  // ============================================================================

  vivokey_flex: {
    id: "vivokey_flex",
    name: "VivoKey Flex",
    manufacturer: "Dangerous Things",
    type: "Java Card",
    protocol: "ISO 7816-4 APDU",
    memorySize: 65536,
    uid: "10-byte UID",
    capabilities: ["applet_deploy", "applet_execute", "applet_uninstall", "payment", "crypto", "biometric"],
    price: 399,
    releaseDate: "2023-01-01",
    status: "active",
    successRate: 92,
    implantable: true,
    paymentCapable: true,
    description: "Premium Java Card with biometric support and advanced cryptography.",
    pros: [
      "64KB memory",
      "Biometric support",
      "Advanced crypto",
      "Payment capable",
      "Flexible architecture",
    ],
    cons: ["Highest cost ($399)", "Requires Fidesmo", "Complex setup", "Smaller community"],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },

  // ============================================================================
  // FUTURE / EXPERIMENTAL CHIPS
  // ============================================================================

  implantable_payment_chip: {
    id: "implantable_payment_chip",
    name: "Implantable Payment Chip (Prototype)",
    manufacturer: "Dangerous Things",
    type: "EMV",
    protocol: "ISO 7816-4 APDU",
    memorySize: 131072,
    uid: "16-byte UID",
    capabilities: ["payment", "crypto", "biometric", "nfc", "lf"],
    price: 599,
    releaseDate: "2024-06-01",
    status: "prototype",
    successRate: 85,
    implantable: true,
    paymentCapable: true,
    description: "Next-generation EMV payment chip with full cryptographic support and biometric authentication.",
    pros: [
      "Full EMV support",
      "128KB memory",
      "Biometric auth",
      "Dual interface",
      "Advanced payment",
    ],
    cons: [
      "Prototype status",
      "Very high cost",
      "Limited availability",
      "Regulatory uncertainty",
    ],
    compatibility: {
      android: true,
      ios: true,
      desktop: true,
    },
  },
};

/**
 * Get all active chips
 */
export function getActiveChips(): ChipSpecification[] {
  return Object.values(CHIP_REGISTRY).filter((chip) => chip.status === "active");
}

/**
 * Get all payment-capable chips
 */
export function getPaymentChips(): ChipSpecification[] {
  return Object.values(CHIP_REGISTRY).filter((chip) => chip.paymentCapable);
}

/**
 * Get chip by ID
 */
export function getChipById(id: string): ChipSpecification | undefined {
  return CHIP_REGISTRY[id];
}

/**
 * Search chips by name
 */
export function searchChips(query: string): ChipSpecification[] {
  const lowerQuery = query.toLowerCase();
  return Object.values(CHIP_REGISTRY).filter(
    (chip) =>
      chip.name.toLowerCase().includes(lowerQuery) ||
      chip.manufacturer.toLowerCase().includes(lowerQuery) ||
      chip.type.toLowerCase().includes(lowerQuery)
  );
}

/**
 * Get chips by capability
 */
export function getChipsByCapability(capability: string): ChipSpecification[] {
  return Object.values(CHIP_REGISTRY).filter((chip) => chip.capabilities.includes(capability));
}

/**
 * Get chips by status
 */
export function getChipsByStatus(status: string): ChipSpecification[] {
  return Object.values(CHIP_REGISTRY).filter((chip) => chip.status === status);
}

export default CHIP_REGISTRY;
