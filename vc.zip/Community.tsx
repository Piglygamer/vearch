import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, MessageCircle, Heart, Share2, User } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function Community() {
  const [, navigate] = useLocation();
  const [liked, setLiked] = useState<number[]>([]);

  const stories = [
    {
      id: 1,
      author: "Alex Chen",
      avatar: "AC",
      chip: "xM1 gen2",
      title: "My First Biohack: Access Control at Work",
      excerpt:
        "After 3 months with my xM1 gen2, I can now unlock my office building with a hand gesture. The installation was smooth and recovery was quick.",
      content:
        "I decided to get the xM1 gen2 implanted after researching biohacking for over a year. My main goal was to streamline access control at my workplace. The installation process was professional and painless thanks to the local anesthetic. Within two weeks, I was fully healed and could test the chip with our building's NFC readers. Now I can unlock doors with just a wave of my hand. The convenience factor is incredible, and my colleagues are fascinated by the technology.",
      likes: 234,
      comments: 45,
      date: "2024-03-10",
      tags: ["xM1 gen2", "Access Control", "Beginner"],
    },
    {
      id: 2,
      author: "Jordan Lee",
      avatar: "JL",
      chip: "Apex Flex",
      title: "Building a Crypto Wallet with Apex Flex",
      excerpt:
        "Using Java applets on my Apex Flex, I've created a secure cryptocurrency wallet. Here's how I did it and what I learned.",
      content:
        "The Apex Flex opened up possibilities I never imagined. With Java Card support and 83KB of EEPROM, I was able to deploy a custom applet for cryptocurrency operations. The process involved learning Java Card development, working with Fidesmo for applet deployment, and extensive testing. The result is a hardware wallet that's always with me, literally under my skin. Security is paramount, and the EAL 6+ certification gives me confidence in the platform.",
      likes: 567,
      comments: 89,
      date: "2024-02-28",
      tags: ["Apex Flex", "Cryptocurrency", "Advanced"],
    },
    {
      id: 3,
      author: "Morgan Smith",
      avatar: "MS",
      chip: "VivoKey Spark 2",
      title: "Spark 2 for Two-Factor Authentication",
      excerpt:
        "Combining Spark 2's AES128 encryption with my existing security infrastructure has significantly improved my digital security posture.",
      content:
        "I chose the Spark 2 for its FIPS 197 compliance and AES128 encryption. My use case was implementing a second factor for authentication across multiple systems. The plug-and-play nature of the Spark 2 made integration straightforward. I'm now using it as a cryptographic key for various applications. The healing process was quick, and I've had zero complications after 6 months.",
      likes: 189,
      comments: 32,
      date: "2024-02-15",
      tags: ["Spark 2", "Security", "Authentication"],
    },
  ];

  const discussions = [
    {
      id: 1,
      title: "Best practices for chip placement?",
      author: "Taylor Brown",
      replies: 24,
      views: 1203,
      category: "Installation",
      lastActive: "2 hours ago",
    },
    {
      id: 2,
      title: "Comparing read range: xM1 vs Apex",
      author: "Casey Wilson",
      replies: 18,
      views: 856,
      category: "Technical",
      lastActive: "4 hours ago",
    },
    {
      id: 3,
      title: "Recovery timeline for Apex Flex",
      author: "Riley Martinez",
      replies: 31,
      views: 2104,
      category: "Aftercare",
      lastActive: "6 hours ago",
    },
    {
      id: 4,
      title: "Custom applet development resources",
      author: "Jordan Lee",
      replies: 12,
      views: 743,
      category: "Development",
      lastActive: "1 day ago",
    },
  ];

  const toggleLike = (id: number) => {
    setLiked((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container py-4 flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">Community</h1>
            <p className="text-sm text-slate-400">
              Connect with biohackers worldwide
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-12">
        <Tabs defaultValue="stories" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-700/50 mb-8">
            <TabsTrigger value="stories">User Stories</TabsTrigger>
            <TabsTrigger value="discussions">Discussions</TabsTrigger>
          </TabsList>

          {/* User Stories Tab */}
          <TabsContent value="stories" className="space-y-6">
            <div className="mb-8">
              <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
                <MessageCircle className="w-4 h-4" />
                Share Your Story
              </Button>
            </div>

            {stories.map((story) => (
              <Card
                key={story.id}
                className="border-slate-700 bg-slate-800/50 hover:border-slate-600 transition-colors"
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-semibold">
                        {story.avatar}
                      </div>
                      <div>
                        <p className="font-semibold text-white">{story.author}</p>
                        <p className="text-xs text-slate-400">{story.date}</p>
                      </div>
                    </div>
                    <Badge className="bg-blue-900/50 text-blue-300 border-blue-700">
                      {story.chip}
                    </Badge>
                  </div>
                  <CardTitle className="text-white text-lg">{story.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-300">{story.content}</p>

                  <div className="flex flex-wrap gap-2">
                    {story.tags.map((tag, idx) => (
                      <Badge
                        key={idx}
                        variant="outline"
                        className="border-slate-600 text-slate-300"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center gap-6 pt-4 border-t border-slate-700 text-slate-400">
                    <button
                      onClick={() => toggleLike(story.id)}
                      className="flex items-center gap-2 hover:text-red-400 transition-colors"
                    >
                      <Heart
                        className={`w-4 h-4 ${
                          liked.includes(story.id)
                            ? "fill-red-400 text-red-400"
                            : ""
                        }`}
                      />
                      <span className="text-sm">
                        {story.likes + (liked.includes(story.id) ? 1 : 0)}
                      </span>
                    </button>
                    <button className="flex items-center gap-2 hover:text-blue-400 transition-colors">
                      <MessageCircle className="w-4 h-4" />
                      <span className="text-sm">{story.comments}</span>
                    </button>
                    <button className="flex items-center gap-2 hover:text-green-400 transition-colors">
                      <Share2 className="w-4 h-4" />
                      <span className="text-sm">Share</span>
                    </button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Discussions Tab */}
          <TabsContent value="discussions" className="space-y-4">
            <div className="mb-8">
              <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
                <MessageCircle className="w-4 h-4" />
                Start Discussion
              </Button>
            </div>

            {discussions.map((discussion) => (
              <Card
                key={discussion.id}
                className="border-slate-700 bg-slate-800/50 hover:border-slate-600 transition-colors cursor-pointer"
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          variant="outline"
                          className="border-slate-600 text-slate-300 text-xs"
                        >
                          {discussion.category}
                        </Badge>
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {discussion.title}
                      </h3>
                      <p className="text-sm text-slate-400">
                        Started by <span className="text-slate-300">{discussion.author}</span>
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-blue-400">
                        {discussion.replies}
                      </div>
                      <p className="text-xs text-slate-400">replies</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 mt-4 pt-4 border-t border-slate-700 text-slate-400 text-sm">
                    <span>{discussion.views} views</span>
                    <span>Active {discussion.lastActive}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>

        {/* Community Stats */}
        <section className="grid md:grid-cols-4 gap-6 mt-12">
          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-blue-400">2,847</div>
              <p className="text-slate-400 mt-2">Active Members</p>
            </CardContent>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-emerald-400">1,203</div>
              <p className="text-slate-400 mt-2">Stories Shared</p>
            </CardContent>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-purple-400">5,621</div>
              <p className="text-slate-400 mt-2">Discussions</p>
            </CardContent>
          </Card>

          <Card className="border-slate-700 bg-slate-800/50">
            <CardContent className="pt-6 text-center">
              <div className="text-3xl font-bold text-cyan-400">98%</div>
              <p className="text-slate-400 mt-2">Satisfaction Rate</p>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  );
}
