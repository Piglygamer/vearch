/**
 * iOS NFC Manager
 * Provides NFC support for all biohacking chips on iOS
 * 
 * iOS limitations:
 * - Read-only for most chips (Apple restricts write access)
 * - Requires user interaction for each read
 * - Works with ISO 14443 Type A and Type B
 * - Supports NDEF reading
 * 
 * Supported chips on iOS:
 * - xM1 gen2 (Magic Chip) - Read UID
 * - VivoKey Spark 2 - Read UID
 * - Apex Flex - Read UID
 * - Zinc - Read UID
 * - All Mifare chips - Read UID
 * - All Java Card chips - Read UID
 */

export interface NFCTagInfo {
  uid: string;
  type: string;
  atr?: string;
  ndefMessages?: NFCNDEFMessage[];
  isWritable: boolean;
}

export interface NFCNDEFMessage {
  records: NFCNDEFRecord[];
}

export interface NFCNDEFRecord {
  recordType: string;
  payload: string;
  mediaType?: string;
}

export interface NFCReadResult {
  success: boolean;
  tag?: NFCTagInfo;
  error?: string;
}

/**
 * iOS NFC Manager
 * Handles NFC communication on iOS devices
 */
export class iOSNFCManager {
  private isSupported: boolean = false;
  private isReading: boolean = false;

  constructor() {
    this.checkSupport();
  }

  /**
   * Check if Web NFC API is supported on iOS
   * Note: iOS support is limited compared to Android
   */
  private checkSupport(): void {
    // Check for Web NFC API
    if ("NDEFReader" in window) {
      this.isSupported = true;
      console.log("[iOS NFC] Web NFC API supported");
    } else {
      console.warn("[iOS NFC] Web NFC API not supported on this device");
      this.isSupported = false;
    }
  }

  /**
   * Read NFC tag (works on iOS 13.1+)
   * Returns tag UID and NDEF messages if available
   */
  async readTag(): Promise<NFCReadResult> {
    if (!this.isSupported) {
      return {
        success: false,
        error: "NFC not supported on this device",
      };
    }

    if (this.isReading) {
      return {
        success: false,
        error: "NFC read already in progress",
      };
    }

    try {
      this.isReading = true;
      console.log("[iOS NFC] Starting tag read...");

      const ndef = new (window as any).NDEFReader();

      // Request NFC read
      await ndef.scan();

      return new Promise((resolve) => {
        ndef.addEventListener("reading", (event: any) => {
          try {
            const { serialNumber, records } = event.message;

            console.log(`[iOS NFC] Tag read: UID=${serialNumber}`);

            // Parse NDEF records
            const ndefMessages: NFCNDEFMessage[] = [];
            if (records && records.length > 0) {
              const ndefRecords: NFCNDEFRecord[] = records.map((record: any) => ({
                recordType: record.recordType,
                payload: this.decodePayload(record.data),
                mediaType: record.mediaType,
              }));

              ndefMessages.push({ records: ndefRecords });
            }

            const tagInfo: NFCTagInfo = {
              uid: serialNumber || "",
              type: this.detectChipType(serialNumber),
              ndefMessages: ndefMessages.length > 0 ? ndefMessages : undefined,
              isWritable: false, // iOS restricts write access
            };

            this.isReading = false;
            resolve({
              success: true,
              tag: tagInfo,
            });
          } catch (error) {
            console.error("[iOS NFC] Error parsing tag:", error);
            this.isReading = false;
            resolve({
              success: false,
              error: String(error),
            });
          }
        });

        ndef.addEventListener("error", (event: any) => {
          console.error("[iOS NFC] Read error:", event);
          this.isReading = false;
          resolve({
            success: false,
            error: event.message || "NFC read failed",
          });
        });

        // Timeout after 30 seconds
        setTimeout(() => {
          if (this.isReading) {
            this.isReading = false;
            resolve({
              success: false,
              error: "NFC read timeout",
            });
          }
        }, 30000);
      });
    } catch (error) {
      console.error("[iOS NFC] Read failed:", error);
      this.isReading = false;
      return {
        success: false,
        error: String(error),
      };
    }
  }

  /**
   * Write NDEF message to tag (limited iOS support)
   * Most iOS devices don't support writing
   */
  async writeTag(message: NFCNDEFMessage): Promise<boolean> {
    console.warn("[iOS NFC] Writing is not supported on iOS");
    return false;
  }

  /**
   * Detect chip type from UID
   */
  private detectChipType(uid: string): string {
    if (!uid) return "unknown";

    const uidLength = uid.length / 2; // Convert hex to bytes

    // 4-byte UID = Mifare Classic or Plus
    if (uidLength === 4) {
      // Check first byte for Mifare Plus
      if (uid.startsWith("04")) {
        return "mifare_plus_zinc";
      }
      return "mifare_classic";
    }

    // 7-byte UID = Mifare Classic Extended
    if (uidLength === 7) {
      return "mifare_classic_extended";
    }

    // 10-byte UID = Java Card or VivoKey
    if (uidLength === 10) {
      return "java_card_vivokey";
    }

    return "unknown";
  }

  /**
   * Decode NDEF payload
   */
  private decodePayload(data: Uint8Array): string {
    try {
      const decoder = new TextDecoder();
      return decoder.decode(data);
    } catch {
      // Return as hex if not text
      return Array.from(data)
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
    }
  }

  /**
   * Check if device is iOS
   */
  static isIOSDevice(): boolean {
    const userAgent = navigator.userAgent.toLowerCase();
    return /iphone|ipad|ipod/.test(userAgent);
  }

  /**
   * Get iOS version
   */
  static getIOSVersion(): string | null {
    const match = navigator.userAgent.match(/OS (\d+)_(\d+)_?(\d+)?/);
    if (match) {
      return `${match[1]}.${match[2]}${match[3] ? "." + match[3] : ""}`;
    }
    return null;
  }

  /**
   * Check if iOS version supports NFC
   * iOS 13.1+ supports Web NFC
   */
  static supportsNFC(): boolean {
    if (!this.isIOSDevice()) return false;

    const version = this.getIOSVersion();
    if (!version) return false;

    const [major, minor] = version.split(".").map(Number);
    return major > 13 || (major === 13 && minor >= 1);
  }
}

/**
 * iOS-specific NFC utilities
 */
export const iOSNFCUtils = {
  /**
   * Format UID for display
   */
  formatUID(uid: string): string {
    return uid
      .match(/.{1,2}/g)
      ?.join(" ")
      .toUpperCase() || uid;
  },

  /**
   * Get chip name from UID
   */
  getChipName(uid: string): string {
    const type = new iOSNFCManager().detectChipType(uid);

    const chipNames: Record<string, string> = {
      mifare_classic: "Magic Chip (xM1 gen2)",
      mifare_plus_zinc: "Zinc (Mifare Plus)",
      mifare_classic_extended: "Magic Chip Extended",
      java_card_vivokey: "VivoKey / Apex Flex",
      unknown: "Unknown Chip",
    };

    return chipNames[type] || "Unknown";
  },

  /**
   * Check if chip supports payment
   */
  supportsPayment(uid: string): boolean {
    const type = new iOSNFCManager().detectChipType(uid);
    return ["java_card_vivokey"].includes(type);
  },

  /**
   * Get supported operations for chip
   */
  getSupportedOperations(uid: string): string[] {
    const type = new iOSNFCManager().detectChipType(uid);

    const operations: Record<string, string[]> = {
      mifare_classic: ["read_uid", "detect_type"],
      mifare_plus_zinc: ["read_uid", "detect_type"],
      mifare_classic_extended: ["read_uid", "detect_type"],
      java_card_vivokey: ["read_uid", "detect_type", "payment"],
      unknown: [],
    };

    return operations[type] || [];
  },
};

export default new iOSNFCManager();
