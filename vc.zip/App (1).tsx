import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Comparison from "./pages/Comparison";
import ChipRegistry from "./pages/ChipRegistry";
import InstallationGuide from "./pages/InstallationGuide";
import Community from "./pages/Community";
import Dashboard from "./pages/Dashboard";
import Spark2Manager from "./pages/Spark2Manager";
import Professionals from "./pages/Professionals";

/**
 * VEARCH CHIP - Production-Ready Biohacking Implant Platform
 * 
 * Routes:
 * / - Home & hero
 * /comparison - Detailed three-chip comparison
 * /registry - Chip registry & management
 * /installation - Installation guides & aftercare
 * /community - Community forum & stories
 * /dashboard - User dashboard
 * /professionals - Professional installer directory
 */

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/comparison"} component={Comparison} />
      <Route path={"/registry"} component={ChipRegistry} />
      <Route path={"/installation"} component={InstallationGuide} />
      <Route path={"/community"} component={Community} />
      <Route path={"/dashboard"} component={Dashboard} />
      <Route path={"/spark2"} component={Spark2Manager} />
      <Route path={"/professionals"} component={Professionals} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
