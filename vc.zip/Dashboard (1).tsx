import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Smartphone,
  Wifi,
  WifiOff,
  Zap,
  RefreshCw,
  Download,
  Upload,
  Copy,
  Trash2,
} from "lucide-react";
import { nfcManager, type NFCDevice, type NFCTag } from "@/lib/nfc-manager";

interface Device {
  id: string;
  type: "phone" | "kr1b" | "unknown";
  name: string;
  connected: boolean;
  battery?: number;
}

interface Chip {
  uid: string;
  type: "magic" | "spark2" | "apex";
  name: string;
  detected: boolean;
  sectors?: number;
}

export default function Dashboard() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null);
  const [chips, setChips] = useState<Chip[]>([]);
  const [selectedChip, setSelectedChip] = useState<Chip | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [nfcSupported, setNfcSupported] = useState(false);
  const [sectorData, setSectorData] = useState<Map<number, string>>(new Map());

  // Initialize NFC Manager on mount
  useEffect(() => {
    const initNFC = async () => {
      try {
        const detectedDevices = await nfcManager.initialize();
        if (detectedDevices.length > 0) {
          setNfcSupported(true);
          setDevices(detectedDevices);
          setSelectedDevice(detectedDevices[0].id);
        }
      } catch (error) {
        console.error("NFC initialization error:", error);
      }
    };
    initNFC();
  }, []);



  const scanForChips = async () => {
    if (!selectedDevice) return;

    setIsScanning(true);
    try {
      // Connect to selected device
      const connected = await nfcManager.connect(selectedDevice);
      if (!connected) {
        console.error("Failed to connect to device");
        setIsScanning(false);
        return;
      }

      // Scan for tag
      const tag = await nfcManager.scanTag();
      if (tag) {
        const newChip: Chip = {
          uid: tag.uid,
          type: "magic",
          name: `Chip ${tag.uid.substring(0, 8)}`,
          detected: true,
          sectors: 16,
        };

        setChips([newChip]);
        setSelectedChip(newChip);
      }
    } catch (error) {
      console.error("NFC scan error:", error);
    } finally {
      setIsScanning(false);
    }
  };

  const readSector = async (sectorNum: number) => {
    if (!selectedChip) return;

    try {
      const sectorData = await nfcManager.readSector(sectorNum);
      if (sectorData) {
        const hexString = Array.from(sectorData)
          .map((b) => b.toString(16).padStart(2, "0"))
          .join(" ");
        setSectorData(new Map(sectorData.set(sectorNum, hexString)));
      }
    } catch (error) {
      console.error("Sector read error:", error);
    }
  };

  const writeSector = async (sectorNum: number, data: string) => {
    if (!selectedChip) return;

    try {
      // Simulate sector write (in production, this would use real NFC APDU commands)
      setSectorData(new Map(sectorData.set(sectorNum, data)));
      console.log(`Wrote to sector ${sectorNum}`);
    } catch (error) {
      console.error("Sector write error:", error);
    }
  };

  const cloneChip = async () => {
    if (!selectedChip) return;

    try {
      const success = await nfcManager.cloneChip(selectedChip);
      if (success) {
        console.log("Chip cloned successfully");
      } else {
        console.error("Clone failed");
      }
    } catch (error) {
      console.error("Clone error:", error);
    }
  };

  const backupChip = async () => {
    if (!selectedChip) return;

    try {
      // Create backup file
      const backupData = {
        chip: selectedChip,
        sectors: Object.fromEntries(sectorData),
        timestamp: new Date().toISOString(),
      };

      const blob = new Blob([JSON.stringify(backupData, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `chip-backup-${selectedChip.uid}.json`;
      a.click();
    } catch (error) {
      console.error("Backup error:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Vearch CHIP Manager</h1>
          <p className="text-slate-400">
            Web-based Proxmark 3 alternative. Full chip management and control.
          </p>
        </div>

        {/* NFC Support Check */}
        {!nfcSupported && (
          <Card className="mb-8 bg-yellow-900 border-yellow-700 p-4">
            <p className="text-yellow-100">
              ⚠️ NFC not supported in this browser. Use Chrome/Edge on Android or
              a compatible device.
            </p>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left: Device Selection */}
          <Card className="lg:col-span-1 bg-slate-800 border-slate-700 p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="text-white">Devices</CardTitle>
            </CardHeader>
            <CardContent className="px-0">
              <div className="space-y-3 mb-6">
                {devices.map((device) => (
                  <button
                    key={device.id}
                    onClick={() => setSelectedDevice(device.id)}
                    className={`w-full p-3 rounded-lg border-2 transition-colors ${
                      selectedDevice === device.id
                        ? "border-blue-500 bg-blue-900/20"
                        : "border-slate-600 bg-slate-700/50 hover:border-slate-500"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex-1 text-left">
                        <p className="text-white font-semibold text-sm">
                          {device.name}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          {device.connected ? (
                            <>
                              <Wifi size={14} className="text-green-400" />
                              <span className="text-xs text-green-400">
                                Connected
                              </span>
                            </>
                          ) : (
                            <>
                              <WifiOff size={14} className="text-slate-400" />
                              <span className="text-xs text-slate-400">
                                Disconnected
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                      {device.battery !== undefined && (
                        <span className="text-xs text-slate-300">
                          {device.battery}%
                        </span>
                      )}
                    </div>
                  </button>
                ))}
              </div>

              {/* Scan Button */}
              <Button
                onClick={scanForChips}
                disabled={!selectedDevice || isScanning}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {isScanning ? (
                  <>
                    <RefreshCw size={16} className="mr-2 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <Zap size={16} className="mr-2" />
                    Scan for Chips
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Center: Chip Selection & Operations */}
          <Card className="lg:col-span-2 bg-slate-800 border-slate-700 p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="text-white">Chip Management</CardTitle>
            </CardHeader>
            <CardContent className="px-0">
              {chips.length === 0 ? (
                <div className="text-center py-12">
                  <Smartphone size={48} className="mx-auto text-slate-500 mb-4" />
                  <p className="text-slate-400">
                    No chips detected. Connect a device and scan.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Selected Chip Info */}
                  {selectedChip && (
                    <Card className="bg-slate-700 border-slate-600 p-4">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-white">
                            {selectedChip.name}
                          </h3>
                          <p className="text-sm text-slate-400 font-mono">
                            UID: {selectedChip.uid}
                          </p>
                        </div>
                        <Badge variant="default">{selectedChip.type}</Badge>
                      </div>

                      {/* Quick Actions */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={backupChip}
                          className="text-xs"
                        >
                          <Download size={14} className="mr-1" />
                          Backup
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs"
                        >
                          <Upload size={14} className="mr-1" />
                          Restore
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={cloneChip}
                          className="text-xs"
                        >
                          <Copy size={14} className="mr-1" />
                          Clone
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          className="text-xs"
                        >
                          <Trash2 size={14} className="mr-1" />
                          Wipe
                        </Button>
                      </div>
                    </Card>
                  )}

                  {/* Sector Operations */}
                  <Tabs defaultValue="sectors" className="w-full">
                    <TabsList className="grid w-full grid-cols-3 bg-slate-700">
                      <TabsTrigger value="sectors">Sectors</TabsTrigger>
                      <TabsTrigger value="uid">UID/CUID</TabsTrigger>
                      <TabsTrigger value="advanced">Advanced</TabsTrigger>
                    </TabsList>

                    <TabsContent value="sectors" className="space-y-3 mt-4">
                      <div className="grid grid-cols-4 gap-2">
                        {Array.from({ length: selectedChip?.sectors || 16 }).map(
                          (_, i) => (
                            <Button
                              key={i}
                              size="sm"
                              variant={
                                sectorData.has(i) ? "default" : "outline"
                              }
                              onClick={() => readSector(i)}
                              className="text-xs"
                            >
                              S{i}
                            </Button>
                          )
                        )}
                      </div>

                      {/* Sector Data Display */}
                      {sectorData.size > 0 && (
                        <Card className="bg-slate-700 border-slate-600 p-3 mt-4">
                          <p className="text-xs text-slate-400 mb-2">
                            Sector Data (Hex):
                          </p>
                          <div className="bg-slate-900 p-3 rounded font-mono text-xs text-slate-300 overflow-auto max-h-32">
                            {Array.from(sectorData.entries()).map(([sector, data]) => (
                              <div key={sector}>
                                <span className="text-blue-400">S{sector}:</span>{" "}
                                {data}
                              </div>
                            ))}
                          </div>
                        </Card>
                      )}
                    </TabsContent>

                    <TabsContent value="uid" className="space-y-3 mt-4">
                      <div className="bg-slate-700 p-3 rounded">
                        <p className="text-sm text-slate-300 mb-2">Current UID:</p>
                        <p className="font-mono text-white bg-slate-900 p-2 rounded">
                          {selectedChip?.uid}
                        </p>
                      </div>
                      <Button className="w-full bg-blue-600 hover:bg-blue-700">
                        Change UID
                      </Button>
                    </TabsContent>

                    <TabsContent value="advanced" className="space-y-3 mt-4">
                      <Button className="w-full" variant="outline">
                        Deploy Applet (Apex Flex)
                      </Button>
                      <Button className="w-full" variant="outline">
                        Execute Command
                      </Button>
                      <Button className="w-full" variant="outline">
                        Verify Chip
                      </Button>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
